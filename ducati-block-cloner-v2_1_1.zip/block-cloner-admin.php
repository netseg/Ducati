<?php
/**
 * Ducati Block Cloner - Painel de Administração + Motor de Scraping
 *
 * @package    DucatiBlockCloner
 * @author     Eng. Fernando Condeço - Netseg.ai
 * @copyright  2024-2026 Netseg.ai
 * @version    1.2.2
 */

// Impedir acesso direto
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Constantes já definidas no ficheiro principal ducati-block-cloner.php

// =============================================
// MENU DE ADMINISTRAÇÃO
// =============================================
add_action( 'admin_menu', function () {
    add_menu_page(
        'Ducati Block Cloner',
        'Ducati Block Cloner',
        'manage_options',
        'block-cloner',
        'blkcloner_admin_page',
        'dashicons-download',
        30
    );
});

// =============================================
// REGISTAR SCRIPTS E ESTILOS ADMIN
// =============================================
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( $hook !== 'toplevel_page_block-cloner' ) {
        return;
    }

    // CSS inline para a página admin
    wp_add_inline_style( 'wp-admin', blkcloner_admin_css() );

    // CSS do Preview Cloner (ficheiro externo)
    ob_start();
    do_action( 'blkcloner_preview_css' );
    $preview_css = ob_get_clean();
    if ( $preview_css ) {
        wp_add_inline_style( 'wp-admin', $preview_css );
    }
});

// =============================================
// AJAX: EXTRAIR BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_extract', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $url      = esc_url_raw( isset( $_POST['url'] ) ? $_POST['url'] : '' );
    $selector = sanitize_text_field( isset( $_POST['selector'] ) ? $_POST['selector'] : '' );
    $force    = ! empty( $_POST['force_refresh'] );

    if ( empty( $url ) || empty( $selector ) ) {
        wp_send_json_error( 'URL e seletor CSS são obrigatórios.' );
    }

    // Limpar cache se forçar refresh
    if ( $force ) {
        delete_transient( BLKCLONER_TRANSIENT_PREFIX . md5( $url ) );
    }

    $result = blkcloner_extract_block( $url, $selector );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
});

// =============================================
// AJAX: GUARDAR BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_save', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_key( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );
    $name     = sanitize_text_field( isset( $_POST['name'] ) ? $_POST['name'] : 'Bloco sem nome' );

    // CRÍTICO: wp_unslash() para remover magic quotes do WordPress
    // Sem isto, " torna-se \" e quebra o JS e atributos HTML
    $raw_html = wp_unslash( isset( $_POST['html'] ) ? $_POST['html'] : '' );
    $css      = wp_unslash( isset( $_POST['css'] ) ? $_POST['css'] : '' );
    $js       = wp_unslash( isset( $_POST['js'] ) ? $_POST['js'] : '' );

    // Extrair <style> tags do HTML (mover para CSS separado)
    if ( preg_match_all( '/<style[^>]*>(.*?)<\/style>/is', $raw_html, $style_matches ) ) {
        foreach ( $style_matches[1] as $inline_css ) {
            $css .= "\n" . $inline_css;
        }
        $raw_html = preg_replace( '/<style[^>]*>.*?<\/style>/is', '', $raw_html );
    }

    // Extrair <script> inline do HTML (mover para JS separado)
    // Apenas scripts SEM src (inline) — scripts com src são carregados pelo shortcode
    if ( preg_match_all( '/<script(?![^>]*\bsrc\b)[^>]*>(.*?)<\/script>/is', $raw_html, $script_matches ) ) {
        foreach ( $script_matches[1] as $inline_js ) {
            $trimmed = trim( $inline_js );
            if ( ! empty( $trimmed ) ) {
                $js .= "\n" . $trimmed;
            }
        }
    }
    // Remover TODOS os script tags do HTML (inline e externos)
    $html = preg_replace( '/<script[^>]*>.*?<\/script>/is', '', $raw_html );
    // Sanitize CSS: remove <script> tags (security) but preserve other content
    // NOT using wp_strip_all_tags() which breaks SVG data URIs and valid CSS
    $css  = preg_replace( '/<script[^>]*>.*?<\/script>/is', '', $css );

    // Filter oversized CSS at save time: keep only rules relevant to block HTML
    if ( strlen( $css ) > 50000 && function_exists( 'blkcloner_filter_relevant_css' ) ) {
        $css = blkcloner_filter_relevant_css( $css, $html );
    }

    $images   = json_decode( wp_unslash( isset( $_POST['images'] ) ? $_POST['images'] : '[]' ), true );
    $source   = esc_url_raw( isset( $_POST['source_url'] ) ? $_POST['source_url'] : '' );

    // Dimensões da extração
    $container_width = sanitize_text_field( isset( $_POST['container_width'] ) ? $_POST['container_width'] : '1100px' );
    $sprite_width    = intval( isset( $_POST['sprite_width'] ) ? $_POST['sprite_width'] : 1920 );
    $sprite_height   = intval( isset( $_POST['sprite_height'] ) ? $_POST['sprite_height'] : 1080 );

    if ( empty( $block_id ) ) {
        $block_id = 'blk_' . strtolower( wp_generate_password( 8, false ) );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    $saved[ $block_id ] = array(
        'id'              => $block_id,
        'name'            => $name,
        'html'            => $html,
        'css'             => $css,
        'js'              => $js,
        'images'          => $images,
        'source_url'      => $source,
        'shortcode'       => '[cloned_block id="' . $block_id . '"]',
        'container_width' => $container_width,
        'sprite_width'    => $sprite_width,
        'sprite_height'   => $sprite_height,
        'created_at'      => current_time( 'mysql' ),
        'updated_at'      => current_time( 'mysql' ),
    );

    update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );

    wp_send_json_success( array(
        'block_id'  => $block_id,
        'shortcode' => '[cloned_block id="' . $block_id . '"]',
        'message'   => 'Bloco guardado com sucesso!',
    ));
});

// =============================================
// AJAX: ELIMINAR BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_delete', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );

    if ( empty( $block_id ) ) {
        wp_send_json_error( 'ID do bloco está vazio. Recarregue a página e tente novamente.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    if ( ! is_array( $saved ) || empty( $saved ) ) {
        wp_send_json_error( 'Nenhum bloco guardado encontrado.' );
    }

    // Procurar bloco: primeiro tentativa exata, depois case-insensitive, depois por campo 'id'
    $found_key = null;
    if ( isset( $saved[ $block_id ] ) ) {
        $found_key = $block_id;
    } else {
        $block_id_lower = strtolower( $block_id );
        foreach ( $saved as $key => $b ) {
            if ( strtolower( $key ) === $block_id_lower ) {
                $found_key = $key;
                break;
            }
            // Fallback: procurar pelo campo 'id' dentro do bloco
            if ( isset( $b['id'] ) && strtolower( $b['id'] ) === $block_id_lower ) {
                $found_key = $key;
                break;
            }
        }
    }

    if ( $found_key ) {
        // Apagar imagens individuais em cache
        if ( ! empty( $saved[ $found_key ]['images'] ) ) {
            foreach ( $saved[ $found_key ]['images'] as $img ) {
                $local = isset( $img['local_path'] ) ? $img['local_path'] : '';
                if ( $local && file_exists( $local ) ) {
                    wp_delete_file( $local );
                }
            }
        }
        // Apagar pasta do bloco no banco de imagens
        $block_img_dir = BLKCLONER_CACHE_DIR . $found_key . '/';
        if ( is_dir( $block_img_dir ) ) {
            $files = glob( $block_img_dir . '*' );
            foreach ( $files as $f ) {
                if ( is_file( $f ) ) {
                    wp_delete_file( $f );
                }
            }
            @rmdir( $block_img_dir );
        }
        unset( $saved[ $found_key ] );
        update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );
        wp_send_json_success( 'Bloco "' . esc_html( $block_id ) . '" eliminado com sucesso.' );
    } else {
        $keys = array_keys( $saved );
        wp_send_json_error( 'Bloco "' . esc_html( $block_id ) . '" não encontrado. Blocos existentes: ' . implode( ', ', array_map( 'esc_html', $keys ) ) );
    }
});

// =============================================
// AJAX: LIMPAR CACHE
// =============================================
add_action( 'wp_ajax_blkcloner_clear_cache', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $files = glob( BLKCLONER_CACHE_DIR . '*' );
    $count = 0;
    foreach ( $files as $file ) {
        if ( is_file( $file ) && basename( $file ) !== '.htaccess' && basename( $file ) !== 'index.php' ) {
            wp_delete_file( $file );
            $count++;
        }
    }

    // Limpar transients
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_blkcloner_%' OR option_name LIKE '_transient_timeout_blkcloner_%'"
    );

    wp_send_json_success( "Cache limpo: {$count} ficheiros removidos." );
});

// =============================================
// AJAX: RENOMEAR BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_rename', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );
    $new_name = sanitize_text_field( isset( $_POST['new_name'] ) ? $_POST['new_name'] : '' );

    if ( empty( $block_id ) || empty( $new_name ) ) {
        wp_send_json_error( 'ID do bloco e novo nome são obrigatórios.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_send_json_error( 'Bloco não encontrado.' );
    }

    $saved[ $block_id ]['name'] = $new_name;
    $saved[ $block_id ]['updated_at'] = current_time( 'mysql' );
    update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );

    wp_send_json_success( array(
        'message' => 'Bloco renomeado com sucesso.',
        'name'    => $new_name,
    ));
});

// =============================================
// AJAX: DUPLICAR BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_duplicate', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );

    if ( empty( $block_id ) ) {
        wp_send_json_error( 'ID do bloco é obrigatório.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_send_json_error( 'Bloco não encontrado.' );
    }

    $new_id = 'blk_' . strtolower( wp_generate_password( 8, false ) );
    $clone = $saved[ $block_id ];
    $clone['id'] = $new_id;
    $clone['name'] = $clone['name'] . ' (cópia)';
    $clone['shortcode'] = '[cloned_block id="' . $new_id . '"]';
    $clone['created_at'] = current_time( 'mysql' );
    $clone['updated_at'] = current_time( 'mysql' );

    $saved[ $new_id ] = $clone;
    update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );

    wp_send_json_success( array(
        'message'   => 'Bloco duplicado com sucesso.',
        'block_id'  => $new_id,
        'shortcode' => $clone['shortcode'],
        'name'      => $clone['name'],
    ));
});

// =============================================
// AJAX: EXPORTAR BLOCOS (JSON)
// =============================================
add_action( 'wp_ajax_blkcloner_export', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_ids = isset( $_POST['block_ids'] ) ? $_POST['block_ids'] : 'all';
    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    if ( empty( $saved ) ) {
        wp_send_json_error( 'Nenhum bloco para exportar.' );
    }

    $export = array();
    if ( $block_ids === 'all' ) {
        $export = $saved;
    } else {
        $ids = is_array( $block_ids ) ? $block_ids : explode( ',', $block_ids );
        foreach ( $ids as $id ) {
            $id = sanitize_text_field( trim( $id ) );
            if ( isset( $saved[ $id ] ) ) {
                $export[ $id ] = $saved[ $id ];
            }
        }
    }

    if ( empty( $export ) ) {
        wp_send_json_error( 'Nenhum bloco válido para exportar.' );
    }

    wp_send_json_success( array(
        'version' => BLKCLONER_VERSION,
        'site'    => home_url(),
        'date'    => current_time( 'mysql' ),
        'count'   => count( $export ),
        'blocks'  => $export,
    ));
});

// =============================================
// AJAX: IMPORTAR BLOCOS (JSON)
// =============================================
add_action( 'wp_ajax_blkcloner_import', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $json_data = isset( $_POST['import_data'] ) ? stripslashes( $_POST['import_data'] ) : '';

    if ( empty( $json_data ) ) {
        wp_send_json_error( 'Dados de importação vazios.' );
    }

    $import = json_decode( $json_data, true );

    if ( json_last_error() !== JSON_ERROR_NONE ) {
        wp_send_json_error( 'JSON inválido: ' . json_last_error_msg() );
    }

    // Suportar formato com wrapper (exportação do plugin) ou array direto
    $blocks = isset( $import['blocks'] ) ? $import['blocks'] : $import;

    if ( ! is_array( $blocks ) || empty( $blocks ) ) {
        wp_send_json_error( 'Nenhum bloco encontrado no ficheiro de importação.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    $imported = 0;
    $skipped = 0;

    foreach ( $blocks as $id => $block ) {
        // Validar campos mínimos
        if ( empty( $block['html'] ) && empty( $block['name'] ) ) {
            $skipped++;
            continue;
        }

        // Se já existe, gerar novo ID
        if ( isset( $saved[ $id ] ) ) {
            $id = 'blk_' . strtolower( wp_generate_password( 8, false ) );
            $block['id'] = $id;
            $block['shortcode'] = '[cloned_block id="' . $id . '"]';
        }

        // Sanitizar dados importados
        $block['name'] = sanitize_text_field( isset( $block['name'] ) ? $block['name'] : 'Bloco importado' );
        $block['html'] = wp_kses_post( isset( $block['html'] ) ? $block['html'] : '' );
        $block['css']  = wp_strip_all_tags( isset( $block['css'] ) ? $block['css'] : '' );
        $block['source_url'] = esc_url_raw( isset( $block['source_url'] ) ? $block['source_url'] : '' );
        $block['updated_at'] = current_time( 'mysql' );

        $saved[ $id ] = $block;
        $imported++;
    }

    update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );

    wp_send_json_success( array(
        'message'  => $imported . ' bloco(s) importado(s)' . ( $skipped > 0 ? ', ' . $skipped . ' ignorado(s)' : '' ) . '.',
        'imported' => $imported,
        'skipped'  => $skipped,
    ));
});

// =============================================
// AJAX: OBTER PREVIEW DE UM BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_preview', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );

    if ( empty( $block_id ) ) {
        wp_send_json_error( 'ID do bloco é obrigatório.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_send_json_error( 'Bloco não encontrado.' );
    }

    $block = $saved[ $block_id ];

    wp_send_json_success( array(
        'html' => $block['html'],
        'css'  => $block['css'],
        'js'   => $block['js'],
    ));
});

// =============================================
// AJAX: OBTER CONFIGURAÇÃO DO BLOCO (imagens + config)
// =============================================
add_action( 'wp_ajax_blkcloner_get_config', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );
    if ( empty( $block_id ) ) {
        wp_send_json_error( 'ID do bloco é obrigatório.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_send_json_error( 'Bloco não encontrado.' );
    }

    $block  = $saved[ $block_id ];
    $config = isset( $block['config'] ) ? $block['config'] : array();

    // Recolher todas as imagens do bloco (array guardado + ficheiros na pasta)
    $all_images = array();

    // 1. Do array de imagens guardadas
    if ( ! empty( $block['images'] ) && is_array( $block['images'] ) ) {
        foreach ( $block['images'] as $idx => $img ) {
            $url = ! empty( $img['local_url'] ) ? $img['local_url'] : ( ! empty( $img['original'] ) ? $img['original'] : '' );
            if ( $url ) {
                $all_images[] = array(
                    'idx'      => $idx,
                    'url'      => $url,
                    'filename' => basename( wp_parse_url( $url, PHP_URL_PATH ) ?: 'image_' . $idx ),
                );
            }
        }
    }

    // 2. Ficheiros na pasta do bloco
    $block_img_dir = BLKCLONER_CACHE_DIR . $block_id . '/';
    if ( is_dir( $block_img_dir ) ) {
        $files = glob( $block_img_dir . '*.{jpg,jpeg,png,gif,svg,webp,avif}', GLOB_BRACE );
        if ( $files ) {
            foreach ( $files as $f ) {
                $fname = basename( $f );
                $furl  = content_url( 'cache/block-cloner/' . $block_id . '/' . $fname );
                // Evitar duplicados
                $already = false;
                foreach ( $all_images as $ai ) {
                    if ( $ai['url'] === $furl ) {
                        $already = true;
                        break;
                    }
                }
                if ( ! $already ) {
                    $all_images[] = array(
                        'idx'      => count( $all_images ),
                        'url'      => $furl,
                        'filename' => $fname,
                    );
                }
            }
        }
    }

    // Detetar cores/variantes existentes no JS do bloco (bikeData)
    $detected_colors = 0;
    $color_details   = array(); // array de { key, name, thumbnail, image_count }
    $js  = $block['js'] ?? '';
    $htm = $block['html'] ?? '';

    // Extrair chaves do bikeData e primeira imagem de cada
    if ( preg_match( '/bikeData\s*=\s*(\{[^;]+\});?/s', $js, $bd_match ) ) {
        $json_str = $bd_match[1];
        // Extrair cada chave e o primeiro URL do array
        if ( preg_match_all( '/["\']?(\w+)["\']?\s*:\s*\[/', $json_str, $key_matches ) ) {
            foreach ( $key_matches[1] as $color_key ) {
                // Obter primeira imagem deste array
                $thumb = '';
                $img_count = 0;
                $pattern = '/' . preg_quote( $color_key, '/' ) . '["\']?\s*:\s*\[(.*?)\]/s';
                if ( preg_match( $pattern, $json_str, $arr_match ) ) {
                    // Contar URLs no array
                    if ( preg_match_all( '/["\']([^"\']+)["\']/', $arr_match[1], $url_matches ) ) {
                        $img_count = count( $url_matches[1] );
                        $thumb = $url_matches[1][0]; // primeira imagem como thumbnail
                    }
                }
                // Nome da cor: procurar data-color="key" data-name="..." no HTML
                $color_name = ucwords( str_replace( '_', ' ', $color_key ) );
                if ( preg_match( '/data-color=["\']' . preg_quote( $color_key, '/' ) . '["\'][^>]*data-name=["\']([^"\']+)["\']/', $htm, $nm ) ) {
                    $color_name = $nm[1];
                } elseif ( preg_match( '/data-name=["\']([^"\']+)["\'][^>]*data-color=["\']' . preg_quote( $color_key, '/' ) . '["\']/', $htm, $nm ) ) {
                    $color_name = $nm[1];
                }

                $color_details[] = array(
                    'key'         => $color_key,
                    'name'        => $color_name,
                    'thumbnail'   => $thumb,
                    'image_count' => $img_count,
                );
            }
            $detected_colors = count( $key_matches[1] );
        }
    }
    if ( $detected_colors < 1 ) {
        // Fallback: Contar .color-btn no HTML e extrair dados deles
        if ( preg_match_all( '/class="color-btn[^"]*"[^>]*data-color="([^"]*)"[^>]*data-name="([^"]*)"/', $htm, $btn_matches, PREG_SET_ORDER ) ) {
            foreach ( $btn_matches as $bm ) {
                $thumb = '';
                // Tentar extrair background-image do style
                if ( preg_match( '/data-color="' . preg_quote( $bm[1], '/' ) . '"[^>]*style="[^"]*background-image:\s*url\([\'"]?([^\'")]+)[\'"]?\)/', $htm, $bg_m ) ) {
                    $thumb = $bg_m[1];
                }
                $color_details[] = array(
                    'key'         => $bm[1],
                    'name'        => $bm[2] ?: ucwords( str_replace( '_', ' ', $bm[1] ) ),
                    'thumbnail'   => $thumb,
                    'image_count' => 0,
                );
            }
            $detected_colors = count( $btn_matches );
        } else {
            $detected_colors = substr_count( $htm, 'color-btn' );
        }
    }

    wp_send_json_success( array(
        'block_id'        => $block_id,
        'name'            => $block['name'] ?? '',
        'images'          => $all_images,
        'detected_colors' => max( $detected_colors, 0 ),
        'color_details'   => $color_details,
        'config'          => $config,
        'html'            => $block['html'] ?? '',
        'css'             => $block['css'] ?? '',
        'js'              => $block['js'] ?? '',
    ));
});

// =============================================
// AJAX: GUARDAR CONFIGURAÇÃO DO BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_save_config', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );
    if ( empty( $block_id ) ) {
        wp_send_json_error( 'ID do bloco é obrigatório.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_send_json_error( 'Bloco não encontrado.' );
    }

    // Receber configuração
    $config_json = wp_unslash( isset( $_POST['config'] ) ? $_POST['config'] : '{}' );
    $config = json_decode( $config_json, true );
    if ( ! is_array( $config ) ) {
        wp_send_json_error( 'Configuração inválida.' );
    }

    // Sanitizar config
    $safe_config = array();
    if ( isset( $config['container_width'] ) ) {
        $safe_config['container_width'] = sanitize_text_field( $config['container_width'] );
    }
    if ( isset( $config['sprite_width'] ) ) {
        $safe_config['sprite_width'] = intval( $config['sprite_width'] );
    }
    if ( isset( $config['sprite_height'] ) ) {
        $safe_config['sprite_height'] = intval( $config['sprite_height'] );
    }
    if ( isset( $config['btn_size'] ) ) {
        $safe_config['btn_size'] = intval( $config['btn_size'] );
    }
    if ( isset( $config['active_color'] ) ) {
        $safe_config['active_color'] = sanitize_hex_color( $config['active_color'] ) ?: '#E32219';
    }
    if ( isset( $config['controls_position'] ) ) {
        $allowed_pos = array( 'top', 'bottom', 'left', 'right' );
        $safe_config['controls_position'] = in_array( $config['controls_position'], $allowed_pos, true ) ? $config['controls_position'] : 'bottom';
    }
    if ( isset( $config['controls_offset_x'] ) ) {
        $safe_config['controls_offset_x'] = intval( $config['controls_offset_x'] );
    }
    if ( isset( $config['controls_offset_y'] ) ) {
        $safe_config['controls_offset_y'] = intval( $config['controls_offset_y'] );
    }
    if ( isset( $config['show_single_color'] ) ) {
        $safe_config['show_single_color'] = (bool) $config['show_single_color'];
    }

    // Cores do seletor: array com key, url, nome, hex, image_count
    if ( isset( $config['footer_icons'] ) && is_array( $config['footer_icons'] ) ) {
        $safe_icons = array();
        foreach ( $config['footer_icons'] as $icon ) {
            $safe_icons[] = array(
                'key'         => sanitize_text_field( isset( $icon['key'] ) ? $icon['key'] : '' ),
                'url'         => esc_url_raw( isset( $icon['url'] ) ? $icon['url'] : '' ),
                'color_name'  => sanitize_text_field( isset( $icon['color_name'] ) ? $icon['color_name'] : '' ),
                'color_hex'   => sanitize_hex_color( isset( $icon['color_hex'] ) ? $icon['color_hex'] : '' ) ?: '',
                'image_count' => intval( isset( $icon['image_count'] ) ? $icon['image_count'] : 0 ),
            );
        }
        $safe_config['footer_icons'] = $safe_icons;
    }

    // Guardar config no bloco
    $saved[ $block_id ]['config']     = $safe_config;
    $saved[ $block_id ]['updated_at'] = current_time( 'mysql' );

    // Se cores foram definidas, reescrever os .color-btn no HTML e atualizar nomes no JS
    if ( ! empty( $safe_config['footer_icons'] ) ) {
        $block = $saved[ $block_id ];
        $html  = $block['html'] ?? '';
        $js    = $block['js'] ?? '';

        // 1. Reescrever os botões .color-btn no HTML
        if ( preg_match( '/<div class="ducati-selector">(?:\s*<div[^<]*<\/div>)*\s*<\/div>/s', $html, $sel_match ) ) {
            $new_selector = '<div class="ducati-selector">';

            foreach ( $safe_config['footer_icons'] as $fi_idx => $fi ) {
                $key    = ! empty( $fi['key'] ) ? $fi['key'] : 'color_' . $fi_idx;
                $name   = ! empty( $fi['color_name'] ) ? $fi['color_name'] : 'Cor ' . ( $fi_idx + 1 );
                $active = $fi_idx === 0 ? ' active' : '';
                $style  = '';
                if ( ! empty( $fi['url'] ) ) {
                    $style = "background-image: url('" . esc_url( $fi['url'] ) . "'); background-size: cover; background-position: center;";
                } elseif ( ! empty( $fi['color_hex'] ) ) {
                    $style = 'background: ' . esc_attr( $fi['color_hex'] );
                } else {
                    $style = 'background: #888';
                }
                $new_selector .= '<div class="color-btn' . $active . '" data-color="' . esc_attr( $key ) . '" data-name="' . esc_attr( $name ) . '" style="' . $style . '"></div>';
            }
            $new_selector .= '</div>';

            $html = str_replace( $sel_match[0], $new_selector, $html );
        }

        // 2. Atualizar o nome da cor ativa no display (primeiro item)
        if ( ! empty( $safe_config['footer_icons'][0]['color_name'] ) ) {
            $first_name = esc_html( $safe_config['footer_icons'][0]['color_name'] );
            $html = preg_replace(
                '/(<div class="color-name-display">[^<]*<span[^>]*>)[^<]*(<\/span>)/s',
                '${1}' . $first_name . '${2}',
                $html
            );
        }

        $saved[ $block_id ]['html'] = $html;
        $saved[ $block_id ]['js']   = $js;
    }

    update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );

    wp_send_json_success( array(
        'message' => 'Configuração guardada com sucesso!',
        'config'  => $safe_config,
    ));
});

// =============================================
// AJAX: ADICIONAR IMAGEM PERSONALIZADA AO BLOCO
// =============================================
add_action( 'wp_ajax_blkcloner_add_custom_image', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $block_id = sanitize_text_field( isset( $_POST['block_id'] ) ? $_POST['block_id'] : '' );
    if ( empty( $block_id ) || ! preg_match( '/^blk_[a-z0-9]+$/', $block_id ) ) {
        wp_send_json_error( 'ID do bloco inválido.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_send_json_error( 'Bloco não encontrado.' );
    }

    // Garantir que a pasta do bloco existe
    $block_dir = BLKCLONER_CACHE_DIR . $block_id . '/';
    if ( ! is_dir( $block_dir ) ) {
        wp_mkdir_p( $block_dir );
    }

    $added_images = array();

    // Opção 1: Upload de ficheiro
    if ( ! empty( $_FILES['custom_image'] ) && ! empty( $_FILES['custom_image']['name'] ) ) {
        $files = $_FILES['custom_image'];
        // Suportar upload múltiplo
        $file_count = is_array( $files['name'] ) ? count( $files['name'] ) : 1;

        for ( $i = 0; $i < $file_count; $i++ ) {
            $name     = is_array( $files['name'] ) ? $files['name'][ $i ] : $files['name'];
            $tmp_name = is_array( $files['tmp_name'] ) ? $files['tmp_name'][ $i ] : $files['tmp_name'];
            $error    = is_array( $files['error'] ) ? $files['error'][ $i ] : $files['error'];

            if ( $error !== UPLOAD_ERR_OK ) {
                continue;
            }

            // Validar tipo de ficheiro
            $allowed_types = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/avif' );
            $finfo = new finfo( FILEINFO_MIME_TYPE );
            $mime = $finfo->file( $tmp_name );
            if ( ! in_array( $mime, $allowed_types, true ) ) {
                continue;
            }

            // Sanitizar nome do ficheiro
            $safe_name = sanitize_file_name( $name );
            // Evitar colisões
            if ( file_exists( $block_dir . $safe_name ) ) {
                $ext = pathinfo( $safe_name, PATHINFO_EXTENSION );
                $base = pathinfo( $safe_name, PATHINFO_FILENAME );
                $safe_name = $base . '_' . uniqid() . '.' . $ext;
            }

            if ( move_uploaded_file( $tmp_name, $block_dir . $safe_name ) ) {
                $url = content_url( 'cache/block-cloner/' . $block_id . '/' . $safe_name );
                $added_images[] = array(
                    'url'      => $url,
                    'filename' => $safe_name,
                );

                // Adicionar ao array de imagens do bloco
                if ( ! isset( $saved[ $block_id ]['images'] ) || ! is_array( $saved[ $block_id ]['images'] ) ) {
                    $saved[ $block_id ]['images'] = array();
                }
                $saved[ $block_id ]['images'][] = array(
                    'original'  => $url,
                    'local_url' => $url,
                );
            }
        }
    }

    // Opção 2: URL externa
    if ( ! empty( $_POST['image_url'] ) ) {
        $url = esc_url_raw( $_POST['image_url'] );
        if ( filter_var( $url, FILTER_VALIDATE_URL ) ) {
            // Descarregar a imagem
            $response = wp_remote_get( $url, array( 'timeout' => 30 ) );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $body = wp_remote_retrieve_body( $response );
                $content_type = wp_remote_retrieve_header( $response, 'content-type' );

                // Validar que é imagem
                $allowed_mimes = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/avif' );
                if ( in_array( strtok( $content_type, ';' ), $allowed_mimes, true ) ) {
                    $ext_map = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp', 'image/svg+xml' => 'svg', 'image/avif' => 'avif' );
                    $ext = $ext_map[ strtok( $content_type, ';' ) ] ?? 'jpg';
                    $fname = 'custom_' . uniqid() . '.' . $ext;
                    $fpath = $block_dir . $fname;

                    if ( file_put_contents( $fpath, $body ) !== false ) {
                        $local_url = content_url( 'cache/block-cloner/' . $block_id . '/' . $fname );
                        $added_images[] = array(
                            'url'      => $local_url,
                            'filename' => $fname,
                        );

                        if ( ! isset( $saved[ $block_id ]['images'] ) || ! is_array( $saved[ $block_id ]['images'] ) ) {
                            $saved[ $block_id ]['images'] = array();
                        }
                        $saved[ $block_id ]['images'][] = array(
                            'original'  => $url,
                            'local_url' => $local_url,
                        );
                    }
                }
            }
        }
    }

    if ( empty( $added_images ) ) {
        wp_send_json_error( 'Nenhuma imagem válida foi adicionada.' );
    }

    // Guardar as imagens no bloco
    $saved[ $block_id ]['updated_at'] = current_time( 'mysql' );
    update_option( BLKCLONER_OPTION_KEY, $saved, 'no' );

    wp_send_json_success( array(
        'message' => count( $added_images ) . ' imagem(ns) adicionada(s) com sucesso!',
        'images'  => $added_images,
    ));
});

// =============================================
// EXPORTAR IMAGENS DO BLOCO COMO ZIP (download direto)
// =============================================
add_action( 'admin_post_blkcloner_export_images', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Permissões insuficientes.' );
    }

    check_admin_referer( 'blkcloner_export_images', '_wpnonce' );

    $block_id = sanitize_text_field( isset( $_GET['block_id'] ) ? $_GET['block_id'] : '' );
    if ( empty( $block_id ) ) {
        wp_die( 'ID do bloco é obrigatório.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    if ( ! isset( $saved[ $block_id ] ) ) {
        wp_die( 'Bloco não encontrado.' );
    }

    if ( ! class_exists( 'ZipArchive' ) ) {
        wp_die( 'A extensão ZipArchive do PHP não está disponível neste servidor.' );
    }

    $block = $saved[ $block_id ];
    $block_name = sanitize_file_name( ! empty( $block['name'] ) ? $block['name'] : $block_id );

    // Recolher todas as URLs de imagens
    $image_urls = array();

    // 1. Do array de imagens guardadas
    if ( ! empty( $block['images'] ) && is_array( $block['images'] ) ) {
        foreach ( $block['images'] as $img ) {
            if ( ! empty( $img['local_url'] ) ) {
                $image_urls[] = $img['local_url'];
            } elseif ( ! empty( $img['original_url'] ) ) {
                $image_urls[] = $img['original_url'];
            }
        }
    }

    // 2. Extrair URLs de imagens do HTML (src, data-src, background-image)
    $html = $block['html'] ?? '';
    if ( preg_match_all( '/(?:src|data-src)\s*=\s*["\']([^"\']+\.(?:jpg|jpeg|png|gif|svg|webp|avif|bmp|ico)(?:\?[^"\']*)?)["\']|url\(\s*["\']?([^"\')\s]+\.(?:jpg|jpeg|png|gif|svg|webp|avif|bmp)(?:\?[^"\')\s]*)?)["\']?\s*\)/i', $html, $matches ) ) {
        foreach ( $matches[1] as $m ) {
            if ( ! empty( $m ) ) {
                $image_urls[] = $m;
            }
        }
        foreach ( $matches[2] as $m ) {
            if ( ! empty( $m ) ) {
                $image_urls[] = $m;
            }
        }
    }

    // Remover duplicados
    $image_urls = array_unique( $image_urls );

    if ( empty( $image_urls ) ) {
        wp_die( 'Nenhuma imagem encontrada neste bloco.' );
    }

    // Criar ZIP temporário
    $tmp_file = wp_tempnam( $block_name . '.zip' );
    $zip = new ZipArchive();
    if ( $zip->open( $tmp_file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) !== true ) {
        wp_die( 'Não foi possível criar o ficheiro ZIP.' );
    }

    $added = 0;
    $cache_dir = WP_CONTENT_DIR . '/cache/block-cloner/';

    foreach ( $image_urls as $url ) {
        $parsed_path = wp_parse_url( $url, PHP_URL_PATH );
        $filename = $parsed_path ? basename( $parsed_path ) : 'image_' . $added . '.jpg';
        // Remover query strings do nome do ficheiro
        $filename = preg_replace( '/\?.*$/', '', $filename );

        // Evitar ficheiros com o mesmo nome
        $name_in_zip = $filename;
        $counter = 1;
        while ( $zip->locateName( $name_in_zip ) !== false ) {
            $ext = pathinfo( $filename, PATHINFO_EXTENSION );
            $base = pathinfo( $filename, PATHINFO_FILENAME );
            $name_in_zip = $base . '_' . $counter . '.' . $ext;
            $counter++;
        }

        $content = false;

        // Tentar ficheiro na pasta do bloco (nova estrutura)
        $block_cache_dir = $cache_dir . $block_id . '/';
        if ( is_dir( $block_cache_dir ) ) {
            foreach ( glob( $block_cache_dir . '*' ) as $bf ) {
                if ( is_file( $bf ) && basename( $bf ) !== 'index.php' ) {
                    $bf_url = content_url( 'cache/block-cloner/' . $block_id . '/' . basename( $bf ) );
                    if ( $url === $bf_url ) {
                        $content = file_get_contents( $bf );
                        break;
                    }
                }
            }
        }

        // Tentar ficheiro local no cache flat antigo (MD5)
        if ( ! $content ) {
            $local_hash = md5( $url );
            $ext = strtolower( pathinfo( $parsed_path ?: '', PATHINFO_EXTENSION ) );
            $cache_file = $cache_dir . $local_hash . '.' . ( $ext ?: 'jpg' );
            if ( file_exists( $cache_file ) ) {
                $content = file_get_contents( $cache_file );
            }
        }

        // Tentar caminho direto local (se URL aponta para cache)
        if ( ! $content && strpos( $url, content_url( 'cache/block-cloner/' ) ) === 0 ) {
            $relative = str_replace( content_url( 'cache/block-cloner/' ), '', $url );
            $direct_path = BLKCLONER_CACHE_DIR . $relative;
            if ( file_exists( $direct_path ) ) {
                $content = file_get_contents( $direct_path );
            }
        }

        // Tentar caminho local WordPress
        if ( ! $content ) {
            $site_url = site_url();
            if ( strpos( $url, $site_url ) === 0 ) {
                $local_path = ABSPATH . ltrim( str_replace( $site_url, '', $url ), '/' );
                if ( file_exists( $local_path ) ) {
                    $content = file_get_contents( $local_path );
                }
            }
        }

        // Tentar content_url (wp-content)
        if ( ! $content ) {
            $content_url = content_url();
            if ( strpos( $url, $content_url ) === 0 ) {
                $local_path = WP_CONTENT_DIR . ltrim( str_replace( $content_url, '', $url ), '/' );
                if ( file_exists( $local_path ) ) {
                    $content = file_get_contents( $local_path );
                }
            }
        }

        // Descarregar remotamente como último recurso
        if ( ! $content && filter_var( $url, FILTER_VALIDATE_URL ) ) {
            $response = wp_remote_get( $url, array(
                'timeout'    => 15,
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'sslverify'  => false,
            ));
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $content = wp_remote_retrieve_body( $response );
            }
        }

        if ( $content && strlen( $content ) > 0 ) {
            $zip->addFromString( $name_in_zip, $content );
            $added++;
        }
    }

    $zip->close();

    if ( $added === 0 ) {
        wp_delete_file( $tmp_file );
        wp_die( 'Não foi possível descarregar nenhuma imagem.' );
    }

    // Enviar ZIP para download
    $zip_filename = $block_name . '-imagens.zip';
    header( 'Content-Type: application/zip' );
    header( 'Content-Disposition: attachment; filename="' . $zip_filename . '"' );
    header( 'Content-Length: ' . filesize( $tmp_file ) );
    header( 'Cache-Control: no-cache, must-revalidate' );
    header( 'Pragma: no-cache' );
    readfile( $tmp_file );
    wp_delete_file( $tmp_file );
    exit;
});

// =============================================
// AJAX: APAGAR TODOS OS BLOCOS
// =============================================
add_action( 'wp_ajax_blkcloner_delete_all_blocks', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    $count = count( $saved );

    // Apagar imagens em cache e pastas de cada bloco
    foreach ( $saved as $bid => $block ) {
        if ( ! empty( $block['images'] ) ) {
            foreach ( $block['images'] as $img ) {
                $local = isset( $img['local_path'] ) ? $img['local_path'] : '';
                if ( $local && file_exists( $local ) ) {
                    wp_delete_file( $local );
                }
            }
        }
        // Apagar pasta organizada do bloco
        $block_img_dir = BLKCLONER_CACHE_DIR . $bid . '/';
        if ( is_dir( $block_img_dir ) ) {
            $files = glob( $block_img_dir . '*' );
            foreach ( $files as $f ) {
                if ( is_file( $f ) ) {
                    wp_delete_file( $f );
                }
            }
            @rmdir( $block_img_dir );
        }
    }

    update_option( BLKCLONER_OPTION_KEY, array() );
    wp_send_json_success( $count . ' blocos eliminados.' );
});

// =============================================
// AJAX: LIMPEZA TOTAL (DESINSTALAÇÃO)
// =============================================
add_action( 'wp_ajax_blkcloner_full_uninstall', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $errors = array();

    // 1. Apagar todos os blocos guardados
    $saved = get_option( BLKCLONER_OPTION_KEY, array() );
    if ( is_array( $saved ) ) {
        foreach ( $saved as $block ) {
            if ( ! empty( $block['images'] ) && is_array( $block['images'] ) ) {
                foreach ( $block['images'] as $img ) {
                    $local = isset( $img['local_path'] ) ? $img['local_path'] : '';
                    if ( $local && file_exists( $local ) ) {
                        wp_delete_file( $local );
                    }
                }
            }
        }
    }
    delete_option( BLKCLONER_OPTION_KEY );

    // 2. Limpar cache dir (todos ficheiros e subpastas)
    $cache_dir = defined( 'BLKCLONER_CACHE_DIR' ) ? BLKCLONER_CACHE_DIR : WP_CONTENT_DIR . '/cache/block-cloner/';
    if ( is_dir( $cache_dir ) ) {
        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator( $cache_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ( $iterator as $item ) {
                if ( $item->isDir() ) {
                    @rmdir( $item->getRealPath() );
                } else {
                    @unlink( $item->getRealPath() );
                }
            }
            @rmdir( $cache_dir );
        } catch ( Exception $e ) {
            $errors[] = 'Cache: ' . $e->getMessage();
        }
    }

    // 3. Limpar transients
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_blkcloner_%' OR option_name LIKE '_transient_timeout_blkcloner_%'"
    );

    // 4. Limpar opções adicionais
    delete_option( 'blkcloner_version' );
    delete_option( 'blkcloner_language' );
    delete_option( 'blkcloner_license' );

    // 5. Limpar registo de uninstall hooks órfãos
    $uninstall_plugins = get_option( 'uninstall_plugins', array() );
    $changed = false;
    foreach ( $uninstall_plugins as $key => $val ) {
        if ( strpos( $key, 'ducati-block-cloner' ) !== false || strpos( $key, 'block-cloner' ) !== false ) {
            unset( $uninstall_plugins[ $key ] );
            $changed = true;
        }
    }
    if ( $changed ) {
        update_option( 'uninstall_plugins', $uninstall_plugins );
    }

    // 6. Desativar o plugin automaticamente
    $plugin_file = defined( 'BLKCLONER_PLUGIN_FILE' ) ? plugin_basename( BLKCLONER_PLUGIN_FILE ) : 'ducati-block-cloner/ducati-block-cloner.php';
    deactivate_plugins( $plugin_file );

    $msg = 'Limpeza total concluída. O plugin foi desativado. Pode agora apagá-lo em Plugins.';
    if ( ! empty( $errors ) ) {
        $msg .= ' (Avisos: ' . implode( '; ', $errors ) . ')';
    }

    wp_send_json_success( $msg );
});

// =============================================
// AJAX: GUARDAR IDIOMA
// =============================================
add_action( 'wp_ajax_blkcloner_save_language', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }

    $lang = sanitize_text_field( isset( $_POST['lang'] ) ? $_POST['lang'] : 'pt' );
    $allowed = array( 'pt', 'en', 'es', 'fr', 'de', 'it' );
    if ( ! in_array( $lang, $allowed, true ) ) {
        $lang = 'pt';
    }

    update_option( 'blkcloner_language', $lang );
    wp_send_json_success( $lang );
});


// =============================================
// MOTOR DE EXTRAÇÃO
// =============================================
if ( ! function_exists( 'blkcloner_extract_block' ) ) :
function blkcloner_extract_block( $url, $selector ) {
    // Verificar cache
    $cache_key = BLKCLONER_TRANSIENT_PREFIX . md5( $url );
    $cached_html = get_transient( $cache_key );

    if ( false === $cached_html ) {
        // Limpar transient antigo de tentativas falhadas
        delete_transient( $cache_key );

        // Extrair domínio para o Referer e Origin
        $parsed_url = wp_parse_url( $url );
        $origin = $parsed_url['scheme'] . '://' . $parsed_url['host'];

        // Perfis de browser para rotação (reduz detecção de bot)
        $browser_profiles = array(
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                'sec-ch-ua'  => '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                'sec-ch-ua-platform' => '"Windows"',
            ),
            array(
                'user-agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                'sec-ch-ua'  => '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                'sec-ch-ua-platform' => '"macOS"',
            ),
            array(
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0',
                'sec-ch-ua'  => '',
                'sec-ch-ua-platform' => '',
            ),
        );

        $last_error = '';
        $response = null;

        // Tentar com diferentes perfis de browser
        foreach ( $browser_profiles as $profile ) {
            $headers = array(
                'Accept'             => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'Accept-Language'    => 'en-US,en;q=0.9,pt;q=0.8',
                'Accept-Encoding'    => 'gzip, deflate',
                'Cache-Control'      => 'max-age=0',
                'Connection'         => 'keep-alive',
                'Referer'            => $origin . '/',
                'Sec-Fetch-Dest'     => 'document',
                'Sec-Fetch-Mode'     => 'navigate',
                'Sec-Fetch-Site'     => 'same-origin',
                'Sec-Fetch-User'     => '?1',
                'Upgrade-Insecure-Requests' => '1',
            );

            // Adicionar Client Hints (Chrome)
            if ( ! empty( $profile['sec-ch-ua'] ) ) {
                $headers['Sec-CH-UA']          = $profile['sec-ch-ua'];
                $headers['Sec-CH-UA-Mobile']   = '?0';
                $headers['Sec-CH-UA-Platform'] = $profile['sec-ch-ua-platform'];
            }

            $response = wp_remote_get( $url, array(
                'timeout'     => 30,
                'user-agent'  => $profile['user-agent'],
                'headers'     => $headers,
                'sslverify'   => false,
                'redirection' => 5,
            ));

            if ( is_wp_error( $response ) ) {
                $last_error = $response->get_error_message();
                continue;
            }

            $status = wp_remote_retrieve_response_code( $response );

            // Sucesso ou redirect - parar de tentar
            if ( $status < 400 ) {
                break;
            }

            // 403/429 - tentar próximo perfil
            if ( $status === 403 || $status === 429 ) {
                $last_error = "HTTP {$status}";
                $response = null;
                // Pequena pausa entre tentativas
                usleep( 500000 ); // 0.5s
                continue;
            }

            // Outros erros HTTP - não vale a pena retry
            $last_error = "HTTP {$status}";
            break;
        }

        if ( is_wp_error( $response ) || $response === null ) {
            $hint = '';
            if ( strpos( $last_error, '403' ) !== false ) {
                $hint = ' Este site usa proteção anti-bot (Cloudflare/Akamai). Tente o Snippet 3 (Scanner Visual) que usa o browser real.';
            }
            return new WP_Error( 'fetch_error', 'Não foi possível aceder à página (' . $last_error . ').' . $hint );
        }

        $status = wp_remote_retrieve_response_code( $response );
        if ( $status >= 400 ) {
            $hint = '';
            if ( $status === 403 ) {
                $hint = ' O site bloqueia scraping server-side. Use o Snippet 3 (Scanner Visual) para extrair via browser.';
            }
            return new WP_Error( 'http_error', "A página devolveu erro HTTP {$status}." . $hint );
        }

        $cached_html = wp_remote_retrieve_body( $response );
        if ( empty( $cached_html ) ) {
            return new WP_Error( 'empty_response', 'A página devolveu conteúdo vazio.' );
        }

        // Verificar se é uma página de challenge (Cloudflare, etc.)
        if ( strpos( $cached_html, 'cf-browser-verification' ) !== false
            || strpos( $cached_html, 'challenge-platform' ) !== false
            || ( strlen( $cached_html ) < 2000 && strpos( $cached_html, 'Just a moment' ) !== false ) ) {
            return new WP_Error( 'challenge_page',
                'O site apresentou uma página de verificação (Cloudflare). ' .
                'Use o Snippet 3 (Scanner Visual) para extrair via browser real.'
            );
        }

        // Cache por 1 hora
        set_transient( $cache_key, $cached_html, HOUR_IN_SECONDS );
    }

    // Parse o HTML
    $parsed = blkcloner_parse_html( $cached_html, $selector, $url );

    if ( is_wp_error( $parsed ) ) {
        return $parsed;
    }

    // SEMPRE tentar detetar 360/cores do HTML raw da página completa.
    // Isto garante que as cores do veículo são sempre detetadas e incluídas no clone,
    // mesmo quando o DOM parser encontra o bloco mas sem dados de cor (carregados via JS).
    $raw_360 = blkcloner_extract_360_from_raw_html( $cached_html, $url );
    if ( ! is_wp_error( $raw_360 ) ) {
        $block_is_empty = ( strlen( $parsed['block_html'] ) < 100 && empty( $parsed['image_urls'] ) );
        $block_has_no_360 = ( strpos( $parsed['js'], 'spritespin' ) === false
            && strpos( $parsed['js'], 'SpriteSpin' ) === false
            && strpos( $parsed['block_html'], 'blk-360-spritespin' ) === false );

        if ( $block_is_empty || $block_has_no_360 ) {
            // Usar o viewer SpriteSpin gerado com cores detetadas
            $parsed['block_html'] = $raw_360['block_html'];
            $parsed['image_urls'] = $raw_360['image_urls'];
            $parsed['js']  = $raw_360['js'];
            $parsed['css'] = ( $parsed['css'] ?? '' ) . "\n" . $raw_360['css'];
        }
    }

    // Gerar block_id antecipado para organizar imagens na pasta do bloco
    $block_id = 'blk_' . strtolower( wp_generate_password( 8, false ) );

    // Descarregar imagens para a pasta do bloco
    $parsed['images'] = blkcloner_download_images( $parsed['image_urls'], $url, $block_id );

    // Reescrever URLs das imagens no HTML
    $final_html = $parsed['block_html'];
    foreach ( $parsed['images'] as $img ) {
        if ( ! empty( $img['local_url'] ) && $img['local_url'] !== $img['original'] ) {
            $final_html = str_replace( $img['original'], $img['local_url'], $final_html );
        }
    }

    // Reescrever URLs nas CSS
    $final_css = $parsed['css'];
    foreach ( $parsed['images'] as $img ) {
        if ( ! empty( $img['local_url'] ) && $img['local_url'] !== $img['original'] ) {
            $final_css = str_replace( $img['original'], $img['local_url'], $final_css );
        }
    }

    // Reescrever URLs no JavaScript (crítico para SpriteSpin/bikeData)
    // Nota: wp_json_encode pode escapar / como \/ — tratar ambas variantes
    $final_js = $parsed['js'];
    foreach ( $parsed['images'] as $img ) {
        if ( ! empty( $img['local_url'] ) && $img['local_url'] !== $img['original'] ) {
            $final_js = str_replace( $img['original'], $img['local_url'], $final_js );
            // Também substituir versão com barras escaped (JSON encoding)
            $escaped_orig  = str_replace( '/', '\\/', $img['original'] );
            $escaped_local = str_replace( '/', '\\/', $img['local_url'] );
            $final_js = str_replace( $escaped_orig, $escaped_local, $final_js );
        }
    }

    return array(
        'html'       => $final_html,
        'css'        => $final_css,
        'js'         => $final_js,
        'images'     => $parsed['images'],
        'block_id'   => $block_id,
        'source_url' => $url,
        'selector'   => $selector,
        'stats'      => array(
            'images_found'    => count( $parsed['image_urls'] ),
            'images_cached'   => count( array_filter( $parsed['images'], function( $i ) { return ! empty( $i['local_url'] ); } ) ),
            'css_rules'       => substr_count( $final_css, '{' ),
            'js_length'       => strlen( $final_js ),
            'html_length'     => strlen( $final_html ),
        ),
    );
}
endif;

// =============================================
// PARSER HTML COM DOMDOCUMENT
// =============================================
if ( ! function_exists( 'blkcloner_parse_html' ) ) :
function blkcloner_parse_html( $html, $selector, $base_url ) {
    // Suprimir avisos de HTML malformado
    libxml_use_internal_errors( true );

    $doc = new DOMDocument( '1.0', 'UTF-8' );
    // Compatível com PHP 8.2+ (HTML-ENTITIES foi removido em 8.2)
    $wrapped = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body>' . $html . '</body></html>';
    $doc->loadHTML( $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NOERROR );

    libxml_clear_errors();

    $xpath = new DOMXPath( $doc );

    // Converter seletor CSS para XPath
    $xpath_query = blkcloner_css_to_xpath( $selector );

    $nodes = $xpath->query( $xpath_query );

    if ( $nodes === false || $nodes->length === 0 ) {
        // Tentar seletores alternativos
        $alt_selectors = blkcloner_generate_alt_selectors( $selector );
        foreach ( $alt_selectors as $alt ) {
            $alt_xpath = blkcloner_css_to_xpath( $alt );
            $nodes = $xpath->query( $alt_xpath );
            if ( $nodes !== false && $nodes->length > 0 ) {
                break;
            }
        }

        if ( $nodes === false || $nodes->length === 0 ) {
            return new WP_Error(
                'selector_not_found',
                "Nenhum elemento encontrado com o seletor '{$selector}'. Tente um seletor diferente. " .
                "Dica: use o Inspetor do browser (F12) para encontrar o seletor correto."
            );
        }
    }

    // Usar o primeiro elemento encontrado
    $target_node = $nodes->item( 0 );

    // Inteligência: se o seletor aponta para um elemento de rotação/slider 360,
    // tentar subir ao pai que contenha também o seletor de cores (.color-switch, .navigation)
    // para capturar o bloco completo (rotação + cores juntos)
    $target_node = blkcloner_smart_parent_expand( $target_node, $xpath );

    // Extrair o HTML do bloco
    $block_html = $doc->saveHTML( $target_node );

    // Resolver URLs relativas
    $block_html = blkcloner_resolve_urls( $block_html, $base_url );

    // Extrair URLs de imagens
    $image_urls = blkcloner_extract_image_urls( $block_html, $base_url );

    // Extrair CSS relevante
    $css = blkcloner_extract_css( $doc, $xpath, $target_node, $base_url );

    // Extrair JS relevante
    $js = blkcloner_extract_js( $doc, $xpath, $target_node, $base_url );

    return array(
        'block_html' => $block_html,
        'css'        => $css,
        'js'         => $js,
        'image_urls' => $image_urls,
    );
}
endif;

// =============================================
// EXPANSÃO INTELIGENTE AO PAI (360 + CORES)
// =============================================
if ( ! function_exists( 'blkcloner_smart_parent_expand' ) ) :
function blkcloner_smart_parent_expand( $node, $xpath ) {
    // Verificar se o nó actual é um slider/360 sem seletor de cores
    $node_html = $node->ownerDocument->saveHTML( $node );
    $node_class = $node->getAttribute( 'class' );

    // Padrões que indicam que é um elemento de rotação 360
    $is_360 = ( strpos( $node_class, 'slider-360' ) !== false
        || strpos( $node_class, 'd-slider-360' ) !== false
        || strpos( $node_class, 'slide-360' ) !== false
        || strpos( $node_class, 'spin' ) !== false
        || strpos( $node_class, 'threesixty' ) !== false
        || strpos( $node_class, 'viewer-360' ) !== false
        || strpos( $node_class, 'product-360' ) !== false
        || $node->hasAttribute( 'data-js-slider-360' )
        || $node->hasAttribute( 'data-image-urls' )
        || $node->hasAttribute( 'data-spritespin' )
        || strpos( $node_class, 'model-preview__img' ) !== false
        || strpos( $node_class, 'model-preview' ) !== false );

    if ( ! $is_360 ) {
        return $node; // Não é um 360, retornar sem alteração
    }

    // Padrões que indicam seletores de cor no HTML
    $color_patterns = array(
        'color-switch', 'color-selector', 'color-picker',
        'color-chooser', 'variant-selector', 'variant-picker',
        'color-swatch', 'swatch-option', 'color-option',
        'data-type="color', 'data-variant', 'data-color',
        'color-btn', 'color-button', 'color-list',
        'model-preview__color', 'bike-color',
    );

    // Verificar se já contém seletores de cor
    $already_has_colors = false;
    foreach ( $color_patterns as $cp ) {
        if ( strpos( $node_html, $cp ) !== false ) {
            $already_has_colors = true;
            break;
        }
    }
    if ( $already_has_colors ) {
        return $node; // Já contém cores, não expandir
    }

    // Subir até 6 níveis para encontrar um pai que contenha tanto 360 como cores
    $current = $node;
    for ( $i = 0; $i < 6; $i++ ) {
        $parent = $current->parentNode;
        if ( ! $parent || $parent->nodeName === 'body' || $parent->nodeName === 'html' ) {
            break;
        }

        $parent_html = $parent->ownerDocument->saveHTML( $parent );

        // Verificar se este pai contém seletores de cor
        $has_colors = false;
        foreach ( $color_patterns as $cp ) {
            if ( strpos( $parent_html, $cp ) !== false ) {
                $has_colors = true;
                break;
            }
        }

        // Verificar se este pai contém o 360
        $has_360 = ( strpos( $parent_html, 'data-image-urls' ) !== false
            || strpos( $parent_html, 'slider-360' ) !== false
            || strpos( $parent_html, 'd-slider-360' ) !== false
            || strpos( $parent_html, 'spin' ) !== false
            || strpos( $parent_html, 'threesixty' ) !== false );

        if ( $has_colors && $has_360 ) {
            return $parent; // Encontrámos o pai completo
        }

        $current = $parent;
    }

    return $node; // Não encontrou pai melhor, retornar original
}
endif;

// =============================================
// ADIVINHAR HEX DE COR A PARTIR DO NOME
// =============================================
if ( ! function_exists( 'blkcloner_guess_color_hex' ) ) :
function blkcloner_guess_color_hex( $name ) {
    $known = array(
        'red'       => '#DC0000', 'rosso'       => '#DC0000', 'vermelho' => '#DC0000', 'rojo'  => '#DC0000',
        'black'     => '#000000', 'nero'        => '#000000', 'preto'    => '#000000', 'negro' => '#000000',
        'white'     => '#FFFFFF', 'bianco'      => '#FFFFFF', 'branco'   => '#FFFFFF', 'blanco' => '#FFFFFF',
        'grey'      => '#808080', 'gray'        => '#808080', 'grigio'   => '#808080', 'cinza'  => '#808080',
        'blue'      => '#0055BF', 'blu'         => '#0055BF', 'azul'     => '#0055BF',
        'green'     => '#008000', 'verde'       => '#008000',
        'yellow'    => '#FFD700', 'giallo'      => '#FFD700', 'amarelo'  => '#FFD700',
        'orange'    => '#FF8C00', 'arancione'   => '#FF8C00', 'laranja'  => '#FF8C00',
        'silver'    => '#C0C0C0', 'argento'     => '#C0C0C0', 'prata'    => '#C0C0C0',
        'gold'      => '#DAA520', 'oro'         => '#DAA520', 'dourado'  => '#DAA520',
        'dark'      => '#333333', 'scuro'       => '#333333', 'escuro'   => '#333333',
        'titanium'  => '#878681', 'titanio'     => '#878681',
        'sand'      => '#C2B280', 'sabbia'      => '#C2B280',
    );
    $lower = strtolower( trim( $name ) );
    foreach ( $known as $key => $hex ) {
        if ( strpos( $lower, $key ) !== false ) {
            return $hex;
        }
    }
    return '';
}
endif;

// =============================================
// AGRUPAR IMAGENS POR COR A PARTIR DO CAMINHO URL
// =============================================
if ( ! function_exists( 'blkcloner_group_images_by_color_path' ) ) :
function blkcloner_group_images_by_color_path( $image_urls ) {
    if ( count( $image_urls ) < 10 ) {
        return array();
    }

    // Palavras de cor conhecidas para regex
    $color_words = array(
        'red', 'rosso', 'vermelho', 'rojo',
        'black', 'nero', 'preto', 'negro',
        'white', 'bianco', 'branco', 'blanco',
        'grey', 'gray', 'grigio', 'cinza',
        'blue', 'blu', 'azul',
        'green', 'verde',
        'yellow', 'giallo', 'amarelo',
        'orange', 'arancione', 'laranja',
        'silver', 'argento', 'prata',
        'gold', 'oro', 'dourado',
        'dark', 'scuro', 'escuro',
        'light', 'chiaro', 'claro',
        'titanium', 'titanio',
        'matt', 'matte', 'fosco',
        'arctic', 'iceberg',
        'sand', 'sabbia',
    );

    // Tentar agrupar por segmento de cor no path da URL
    $groups = array();
    $color_regex = '/[\/\-_](' . implode( '|', $color_words ) . ')[\/\-_\.]/i';

    foreach ( $image_urls as $url ) {
        if ( preg_match( $color_regex, strtolower( $url ), $cm ) ) {
            $color_key = strtolower( $cm[1] );
            if ( ! isset( $groups[ $color_key ] ) ) {
                $groups[ $color_key ] = array();
            }
            $groups[ $color_key ][] = $url;
        }
    }

    // Filtrar: cada grupo deve ter pelo menos 5 imagens (sequência 360) e precisa de 2+ cores
    $valid_groups = array();
    foreach ( $groups as $color_key => $urls ) {
        if ( count( $urls ) >= 5 ) {
            sort( $urls );
            $hex = blkcloner_guess_color_hex( $color_key );
            $valid_groups[] = array(
                'name'   => ucfirst( $color_key ),
                'hex'    => $hex ?: '#888888',
                'images' => $urls,
            );
        }
    }

    if ( count( $valid_groups ) < 2 ) {
        // Tentar agrupamento alternativo: por diretório pai distinto
        $dir_groups = array();
        foreach ( $image_urls as $url ) {
            $path = wp_parse_url( $url, PHP_URL_PATH );
            if ( $path ) {
                $parts = explode( '/', trim( $path, '/' ) );
                if ( count( $parts ) >= 3 ) {
                    $dir_key = $parts[ count( $parts ) - 2 ];
                    if ( ! isset( $dir_groups[ $dir_key ] ) ) {
                        $dir_groups[ $dir_key ] = array();
                    }
                    $dir_groups[ $dir_key ][] = $url;
                }
            }
        }

        $valid_groups = array();
        foreach ( $dir_groups as $dir_key => $urls ) {
            if ( count( $urls ) >= 5 ) {
                sort( $urls );
                $hex  = blkcloner_guess_color_hex( $dir_key );
                $name = $hex ? ucfirst( $dir_key ) : ucfirst( str_replace( array( '-', '_' ), ' ', $dir_key ) );
                $valid_groups[] = array(
                    'name'   => $name,
                    'hex'    => $hex ?: '#888888',
                    'images' => $urls,
                );
            }
        }

        if ( count( $valid_groups ) < 2 ) {
            return array();
        }
    }

    return $valid_groups;
}
endif;

// =============================================
// FALLBACK: EXTRAIR 360 DO HTML RAW (conteúdo dinâmico)
// =============================================
if ( ! function_exists( 'blkcloner_extract_360_from_raw_html' ) ) :
function blkcloner_extract_360_from_raw_html( $html, $base_url ) {
    $all_image_urls = array();
    $color_sets     = array();
    $color_names    = array();
    $color_thumbs   = array();
    $color_hexes    = array();

    // ─── ESTRATÉGIA A: Detetar cores + imagens a partir de JavaScript ───
    // Procurar objetos JS com arrays de imagens agrupados por cor/variante
    // Ex: bikeData = { red: ["url1","url2",...], black: ["url1","url2",...] }
    // Ex: variants = [{ color: "Red", images: ["url1",...] }]
    // Ex: window.__CONFIG__ = { colors: { "Rosso Ducati": { images: [...] } } }
    if ( preg_match_all( '/<script[^>]*>(.*?)<\/script>/si', $html, $script_blocks ) ) {
        foreach ( $script_blocks[1] as $script_content ) {

            // A1. Objeto simples com chaves cor → array de URLs
            // Padrão: { red: ["url1","url2"], black: ["url1","url2"] }
            // Ou: { "Rosso Ducati": ["url1","url2"], "Nero": ["url1","url2"] }
            // Captura chaves com/sem aspas, seguidas de array com 5+ URLs de imagem
            if ( preg_match_all( '/(?:"([^"]+)"|\'([^\']+)\'|([\w]+))\s*:\s*\[\s*("(?:https?:)?\/\/[^"]+(?:\.(?:png|jpg|jpeg|webp|avif))[^"]*"(?:\s*,\s*"(?:https?:)?\/\/[^"]+(?:\.(?:png|jpg|jpeg|webp|avif))[^"]*"){4,})\s*\]/i', $script_content, $obj_matches, PREG_SET_ORDER ) ) {
                foreach ( $obj_matches as $om ) {
                    // Chave pode estar no grupo 1 (aspas duplas), 2 (aspas simples) ou 3 (sem aspas)
                    $key_name = ! empty( $om[1] ) ? $om[1] : ( ! empty( $om[2] ) ? $om[2] : $om[3] );
                    $key_name = trim( $key_name );
                    $url_str  = $om[4];

                    // Ignorar chaves que são claramente não-cores (source, width, etc.)
                    $ignore_keys = array( 'source', 'sources', 'images', 'frames', 'views', 'width', 'height', 'data', 'config', 'options', 'urls' );
                    if ( in_array( strtolower( $key_name ), $ignore_keys, true ) ) {
                        continue;
                    }

                    if ( preg_match_all( '/"((?:https?:)?\/\/[^"]+)"/i', $url_str, $url_arr ) ) {
                        $urls = $url_arr[1];
                        // Garantir URLs completas
                        $urls = array_map( function( $u ) {
                            return strpos( $u, '//' ) === 0 ? 'https:' . $u : $u;
                        }, $urls );
                        if ( count( $urls ) >= 5 ) {
                            $color_sets[]   = $urls;
                            $color_names[]  = ucfirst( $key_name );
                            $color_thumbs[] = $urls[0]; // 1ª imagem como thumb
                            $color_hexes[]  = blkcloner_guess_color_hex( $key_name );
                            $all_image_urls = array_merge( $all_image_urls, $urls );
                        }
                    }
                }
            }

            // A2. Array de variantes com estrutura: [{color:"Red", hex:"#DC0000", images:[...], thumb:"url"}]
            if ( empty( $color_sets ) && preg_match_all( '/\{\s*(?:"?color"?\s*:\s*"([^"]+)"[^}]*"?(?:images|frames|views|sources?)"?\s*:\s*\[([^\]]+)\]|"?(?:images|frames|views|sources?)"?\s*:\s*\[([^\]]+)\][^}]*"?color"?\s*:\s*"([^"]+)")/si', $script_content, $var_matches, PREG_SET_ORDER ) ) {
                foreach ( $var_matches as $vm ) {
                    $c_name  = ! empty( $vm[1] ) ? $vm[1] : ( ! empty( $vm[4] ) ? $vm[4] : '' );
                    $url_str = ! empty( $vm[2] ) ? $vm[2] : ( ! empty( $vm[3] ) ? $vm[3] : '' );
                    if ( $c_name && $url_str && preg_match_all( '/"(https?:\/\/[^"]+)"/i', $url_str, $url_arr ) ) {
                        $urls = $url_arr[1];
                        if ( count( $urls ) >= 5 ) {
                            $color_sets[]   = $urls;
                            $color_names[]  = $c_name;
                            $color_thumbs[] = $urls[0];
                            $color_hexes[]  = '';
                            $all_image_urls = array_merge( $all_image_urls, $urls );
                        }
                    }
                }
            }

            // A3. JSON genérico com imageUrls/images/frames/views (sem cor)
            if ( empty( $all_image_urls ) ) {
                if ( preg_match( '/"(?:image[_-]?urls|images|frames|views|gallery|slides|sources?)":\s*\[([^\]]+)\]/i', $script_content, $json_match ) ) {
                    if ( preg_match_all( '/"(https?:\/\/[^"]+)"/i', $json_match[1], $json_urls ) ) {
                        $all_image_urls = array_merge( $all_image_urls, $json_urls[1] );
                    }
                }
            }

            // A4. Procurar arrays soltos de URLs de imagem 360 (sem chave de cor)
            if ( empty( $all_image_urls ) ) {
                if ( preg_match_all( '/(https?:\/\/[^"\'\\s,]+?(?:360|spin|rotate|view|preview|gallery|model)[^"\'\\s,]*?\.(?:png|jpg|jpeg|webp|avif)[^"\'\\s,]*)/i', $script_content, $url_matches ) ) {
                    $all_image_urls = array_merge( $all_image_urls, $url_matches[1] );
                }
            }

            // A5. Padrão base_url + sequência
            if ( empty( $all_image_urls ) ) {
                if ( preg_match( '/(?:baseUrl|base_url|imagePath|imgPath|imgBase)\s*[:=]\s*["\']([^"\']+)["\']/', $script_content, $base_match ) ) {
                    $base = $base_match[1];
                    for ( $seq = 1; $seq <= 36; $seq++ ) {
                        $pad2 = str_pad( $seq, 2, '0', STR_PAD_LEFT );
                        foreach ( array( 'jpg', 'png', 'webp', 'avif' ) as $ext ) {
                            $test_url = $base . $pad2 . '.' . $ext;
                            if ( strpos( $script_content, $pad2 ) !== false ) {
                                $all_image_urls[] = $test_url;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    // ─── ESTRATÉGIA B: Detetar data-image-urls agrupados por cor (HTML) ───
    if ( empty( $color_sets ) ) {
        // B1. data-image-urls no HTML (formato Ducati)
        if ( preg_match_all( '/data-image-urls=["\']([^"\']+)["\']/i', $html, $matches ) ) {
            foreach ( $matches[1] as $idx => $url_list ) {
                $decoded = html_entity_decode( $url_list );
                $urls = array_filter( array_map( 'trim', explode( ',', $decoded ) ) );
                if ( ! empty( $urls ) ) {
                    $color_sets[] = $urls;
                    $all_image_urls = array_merge( $all_image_urls, $urls );
                }
            }
        }

        // B2. data-src/data-lazy com padrão numérico sequencial
        if ( empty( $all_image_urls ) ) {
            if ( preg_match_all( '/(?:data-src|data-lazy|data-original)=["\']([^"\']*?(?:360|spin|rotate|view|preview|model)[^"\']*?\.(?:png|jpg|jpeg|webp|avif))["\']|src=["\']([^"\']*?(?:_\d{2,3}|frame[_-]?\d+)[^"\']*?\.(?:png|jpg|jpeg|webp|avif))["\']/', $html, $img_matches ) ) {
                foreach ( $img_matches[0] as $match ) {
                    if ( preg_match( '/["\']([^"\']+)["\']/', $match, $url_match ) ) {
                        $all_image_urls[] = $url_match[1];
                    }
                }
            }
        }
    }

    // B3. Procurar sequência de imagens por padrão numérico no HTML completo
    if ( empty( $all_image_urls ) ) {
        if ( preg_match_all( '/(?:src|data-src|href)=["\']([^"\']+\.(?:png|jpg|jpeg|webp|avif))["\']/', $html, $all_imgs ) ) {
            $numbered = array();
            foreach ( $all_imgs[1] as $url ) {
                if ( preg_match( '/[\-_](\d{2,3})\.(?:png|jpg|jpeg|webp|avif)$/i', $url ) ) {
                    $numbered[] = $url;
                }
            }
            if ( count( $numbered ) >= 10 ) {
                $all_image_urls = $numbered;
            }
        }
    }

    // ─── ESTRATÉGIA C: Auto-agrupar imagens por cor a partir do caminho URL ───
    // Se temos imagens mas não temos color_sets, tentar agrupar pelo segmento
    // de cor na URL (ex: /red/img_01.jpg, /black/img_01.jpg)
    if ( ! empty( $all_image_urls ) && empty( $color_sets ) ) {
        $color_sets = blkcloner_group_images_by_color_path( $all_image_urls );
        if ( ! empty( $color_sets ) && count( $color_sets ) > 1 ) {
            // Extrair nomes de cor dos caminhos
            $color_names  = array();
            $color_thumbs = array();
            $color_hexes  = array();
            foreach ( $color_sets as $set_info ) {
                $color_names[]  = $set_info['name'];
                $color_thumbs[] = $set_info['images'][0]; // 1ª imagem como thumb
                $color_hexes[]  = $set_info['hex'] ?? '';
            }
            // Reformatar color_sets para apenas as imagens
            $color_sets = array_map( function( $s ) { return $s['images']; }, $color_sets );
        } else {
            $color_sets = array(); // Sem agrupamento por cor
        }
    }

    // ─── ESTRATÉGIA D: Detetar cores/variantes do HTML (seletores, botões) ───
    if ( empty( $color_names ) ) {

        // D1. Seletores de cor Ducati: <li class="color-switch__item" data-type="color">
        //     Com label/title/aria-label e background-image
        if ( preg_match_all( '/<(?:li|button|div|a|span)[^>]*(?:class="[^"]*(?:color|variant|swatch)[^"]*"|data-(?:type|role)="[^"]*color[^"]*")[^>]*>/si', $html, $color_els ) ) {
            foreach ( $color_els[0] as $el_tag ) {
                $name  = '';
                $thumb = '';
                $hex   = '';

                // Nome da cor: data-name, data-label, data-color-name, aria-label, title
                if ( preg_match( '/(?:data-(?:name|label|color-name|color|variant-name|value))\s*=\s*["\']([^"\']+)["\']/', $el_tag, $nm ) ) {
                    $name = trim( $nm[1] );
                }
                if ( empty( $name ) && preg_match( '/(?:aria-label|title)\s*=\s*["\']([^"\']+)["\']/', $el_tag, $nm ) ) {
                    $name = trim( $nm[1] );
                }

                // Thumbnail: background-image ou data-thumb
                if ( preg_match( '/background-image:\s*url\(["\']?([^"\')\s]+)["\']?\)/', $el_tag, $bg ) ) {
                    $thumb = trim( $bg[1] );
                }
                if ( empty( $thumb ) && preg_match( '/data-(?:thumb|thumbnail|image|src)\s*=\s*["\']([^"\']+)["\']/', $el_tag, $th ) ) {
                    $thumb = trim( $th[1] );
                }

                // Hex: data-hex, data-color-hex, style background-color
                if ( preg_match( '/data-(?:hex|color-hex|color-code)\s*=\s*["\']([^"\']+)["\']/', $el_tag, $hx ) ) {
                    $hex = trim( $hx[1] );
                }
                if ( empty( $hex ) && preg_match( '/background(?:-color)?:\s*(#[0-9a-fA-F]{3,8})/', $el_tag, $hx ) ) {
                    $hex = trim( $hx[1] );
                }

                if ( ! empty( $name ) || ! empty( $thumb ) ) {
                    $color_names[]  = $name ?: 'Cor ' . ( count( $color_names ) + 1 );
                    $color_thumbs[] = $thumb;
                    $color_hexes[]  = $hex;
                }
            }
        }

        // D2. Padrão Ducati: <li class="...color..." style="background-image:url(...)">
        //     Com <span class="label">Nome</span> dentro
        if ( empty( $color_names ) ) {
            if ( preg_match_all( '/<li[^>]*class="[^"]*color[^"]*"[^>]*>.*?<span[^>]*class="[^"]*label[^"]*"[^>]*>([^<]+)<\/span>/si', $html, $color_matches ) ) {
                $color_names = array_map( 'trim', $color_matches[1] );
            }
            if ( preg_match_all( '/<li[^>]*(?:style="[^"]*background-image:\s*url\(([^)]+)\)[^"]*"[^>]*class="[^"]*color[^"]*"|class="[^"]*color[^"]*"[^>]*style="[^"]*background-image:\s*url\(([^)]+)\)[^"]*")/si', $html, $thumb_matches ) ) {
                foreach ( $thumb_matches[0] as $idx => $tm ) {
                    $color_thumbs[] = ! empty( $thumb_matches[1][ $idx ] ) ? trim( $thumb_matches[1][ $idx ] ) : trim( $thumb_matches[2][ $idx ] );
                }
            }
        }

        // D3. Botões/links de cor com img dentro (thumbnail como <img>)
        if ( empty( $color_thumbs ) && ! empty( $color_names ) ) {
            if ( preg_match_all( '/<(?:li|button|div|a)[^>]*class="[^"]*(?:color|variant|swatch)[^"]*"[^>]*>.*?<img[^>]*src=["\']([^"\']+)["\'][^>]*>/si', $html, $img_thumbs ) ) {
                $color_thumbs = array_map( 'trim', $img_thumbs[1] );
            }
        }
    }

    // ─── ESTRATÉGIA E: Associar color_names a color_sets se não foram associados ───
    // Se temos nomes de cor E imagens separadas mas sem color_sets definidos,
    // tentar dividir as imagens equitativamente entre as cores
    if ( ! empty( $all_image_urls ) && ! empty( $color_names ) && empty( $color_sets ) && count( $color_names ) > 1 ) {
        $unique_urls = array_values( array_unique( $all_image_urls ) );
        $n_colors    = count( $color_names );
        $per_color   = (int) floor( count( $unique_urls ) / $n_colors );

        if ( $per_color >= 5 ) {
            for ( $ci = 0; $ci < $n_colors; $ci++ ) {
                $color_sets[] = array_slice( $unique_urls, $ci * $per_color, $per_color );
            }
        }
    }

    if ( empty( $all_image_urls ) ) {
        return new WP_Error( 'no_360_data', 'Não foi possível extrair dados de rotação 360 da página.' );
    }

    $all_image_urls = array_unique( $all_image_urls );

    // Construir HTML do viewer 360 com SpriteSpin
    // v1.5.2: Estrutura idêntica ao código de referência Ducati Lisboa
    // Usa renderer:canvas, SVG inline no drag indicator, nomes de cor reais como chaves
    $widget_id = 'blk360-' . wp_rand( 10000, 99999 );
    $viewer_id = 'moto-viewer-' . wp_rand( 10000, 99999 );
    $hint_id   = 'interact-hint-' . wp_rand( 10000, 99999 );
    $color_id  = 'current-color-name-' . wp_rand( 10000, 99999 );
    $has_colors = count( $color_sets ) > 1;

    // Preparar dados de cores usando nomes reais como chaves JS
    $js_color_data = array();
    if ( $has_colors ) {
        foreach ( $color_sets as $ci => $set ) {
            // Usar nome de cor como chave (sanitizado para JS)
            $key = isset( $color_names[ $ci ] ) ? strtolower( preg_replace( '/[^a-zA-Z0-9]/', '_', $color_names[ $ci ] ) ) : 'color_' . $ci;
            $js_color_data[ $key ] = $set;
        }
    } else {
        $js_color_data['default'] = array_values( array_slice( $all_image_urls, 0, 36 ) );
    }

    // HTML do viewer — estrutura idêntica ao código de referência
    $block_html = '<div class="ducati-lisboa-360-wrapper">';
    $block_html .= '<div class="moto-container">';
    $block_html .= '<div id="' . esc_attr( $viewer_id ) . '"></div>';

    // Overlay de rotação com SVG inline (idêntico ao código de referência)
    $block_html .= '<div class="rotation-overlay visible" id="' . esc_attr( $hint_id ) . '">';
    $block_html .= '<div class="drag-indicator">';
    $block_html .= '<svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">';
    $block_html .= '<path d="M7 6c2-1.5 4.5-2 7-1.5 2.5.5 4.5 2 6 4"></path>';
    $block_html .= '<polyline points="16 9 20 9 20 5"></polyline>';
    $block_html .= '<path d="M17 18c-2 1.5-4.5 2-7 1.5-2.5-.5-4.5-2-6-4"></path>';
    $block_html .= '<polyline points="8 15 4 15 4 19"></polyline>';
    $block_html .= '</svg>';
    $block_html .= '</div>';
    $block_html .= '</div>';

    $block_html .= '</div>'; // .moto-container

    // Controlos de cores
    $block_html .= '<div class="ducati-controls-area">';

    if ( $has_colors ) {
        $block_html .= '<div class="ducati-selector">';
        $color_keys = array_keys( $js_color_data );
        foreach ( $color_sets as $ci => $set ) {
            $name = isset( $color_names[ $ci ] ) ? $color_names[ $ci ] : 'Cor ' . ( $ci + 1 );
            $thumb = isset( $color_thumbs[ $ci ] ) ? $color_thumbs[ $ci ] : '';
            $hex   = isset( $color_hexes[ $ci ] ) ? $color_hexes[ $ci ] : '';
            $active = $ci === 0 ? ' active' : '';
            $color_key = isset( $color_keys[ $ci ] ) ? $color_keys[ $ci ] : 'color_' . $ci;
            $style = '';
            if ( $thumb ) {
                $style = "background-image: url('" . esc_url( $thumb ) . "')";
            } elseif ( $hex ) {
                $style = 'background:' . esc_attr( $hex );
            } else {
                $style = ! empty( $set[0] ) ? "background-image: url('" . esc_url( $set[0] ) . "')" : 'background:#888';
            }
            $block_html .= '<div class="color-btn' . $active . '" data-color="' . esc_attr( $color_key ) . '" data-name="' . esc_attr( $name ) . '" style="' . $style . '"></div>';
        }
        $block_html .= '</div>';

        // Nome da cor
        $first_name = isset( $color_names[0] ) ? $color_names[0] : 'Cor 1';
        $block_html .= '<div class="color-name-display">';
        $block_html .= 'COR: <span id="' . esc_attr( $color_id ) . '">' . esc_html( $first_name ) . '</span>';
        $block_html .= '</div>';
    }

    $block_html .= '</div>'; // .ducati-controls-area
    $block_html .= '</div>'; // .ducati-lisboa-360-wrapper

    // CSS — idêntico ao código de referência Ducati Lisboa
    $css = '
.ducati-lisboa-360-wrapper {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    z-index: 9999;
    font-family: Arial, sans-serif;
    overflow: visible;
}
.moto-container {
    width: 100%;
    max-width: 1100px;
    position: relative;
    z-index: 9999;
    cursor: grab;
    overflow: visible;
    min-height: 200px;
}
.moto-container:active { cursor: grabbing; }
.moto-container > div:not(.rotation-overlay) {
    width: 100% !important;
    max-width: 100% !important;
    z-index: 9999;
}
.moto-container img, .spritespin-stage img {
    -webkit-user-drag: none;
    user-select: none;
    -webkit-user-select: none;
}
.rotation-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 9999;
    pointer-events: none;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.4s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
}
.rotation-overlay.visible { opacity: 1; visibility: visible; }
.drag-indicator {
    background: rgba(0, 0, 0, 0.3);
    width: 70px;
    height: 70px;
    border-radius: 50%;
    border: 1px solid rgba(255, 255, 255, 0.4);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
}
.drag-indicator svg {
    width: 45px;
    height: 45px;
    filter: drop-shadow(0px 0px 3px rgba(0,0,0,0.8));
}
.ducati-controls-area {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
    margin-top: -20px;
    padding-bottom: 40px;
}
.ducati-selector { display: flex; gap: 20px; }
.color-btn {
    width: 45px;
    height: 45px;
    background-size: cover;
    border-radius: 50%;
    cursor: pointer;
    border: 2px solid #ddd;
    transition: 0.3s ease;
}
.color-btn.active { border-color: #E32219; transform: scale(1.1); }
.color-name-display {
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    color: #333;
}
#' . $color_id . ' { color: #E32219; margin-left: 5px; }
.ducati-lisboa-360-wrapper::after {
    content: "\00A9 Netseg Ib\00E9rica 2026 - C\00F3pia Proibida";
    display: block; font-size: 1px; color: transparent;
}
';

    // JS com SpriteSpin — renderer:image, sense:-1.5, responsive:true
    // v1.9.7: renderer:image + anti-ghost CSS (user-drag:none) para eliminar arrasto
    $first_key = ! empty( array_keys( $js_color_data ) ) ? array_keys( $js_color_data )[0] : 'default';
    $js = '$(function() {
    var bikeData = ' . wp_json_encode( $js_color_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ';
    var $viewer = $("#' . esc_js( $viewer_id ) . '");
    var $overlay = $("#' . esc_js( $hint_id ) . '");
    function load360(color) {
        var stopTimer;
        var imgs = bikeData[color];
        if (!imgs || !imgs.length) return;
        var probe = new Image();
        probe.onload = function() {
            var natW = probe.naturalWidth || 1920;
            var natH = probe.naturalHeight || 1080;
            $viewer.spritespin({
                source: imgs,
                width: natW,
                height: natH,
                responsive: true,
                animate: false,
                touch: true,
                sense: -1.5,
                renderer: "image",
                onInit: function() {
                    $overlay.addClass("visible");
                },
                onFrame: function() {
                    $overlay.removeClass("visible");
                    clearTimeout(stopTimer);
                    stopTimer = setTimeout(function() {
                        $overlay.addClass("visible");
                    }, 250);
                },
                onDragStart: function() {
                    $overlay.removeClass("visible");
                }
            });
        };
        probe.onerror = function() {
            $viewer.spritespin({
                source: imgs,
                width: 1920,
                height: 1080,
                responsive: true,
                animate: false,
                touch: true,
                sense: -1.5,
                renderer: "image",
                onInit: function() { $overlay.addClass("visible"); },
                onFrame: function() { $overlay.removeClass("visible"); clearTimeout(stopTimer); stopTimer = setTimeout(function() { $overlay.addClass("visible"); }, 250); },
                onDragStart: function() { $overlay.removeClass("visible"); }
            });
        };
        probe.src = imgs[0];
    }
    load360("' . esc_js( $first_key ) . '");
    $(".color-btn").on("click", function() {
        $(".color-btn").removeClass("active");
        $(this).addClass("active");
        var color = $(this).data("color");
        var name = $(this).data("name");
        $("#' . esc_js( $color_id ) . '").text(name);
        load360(color);
    });
});';

    // Incluir thumbnails dos botões de cor na lista de imagens para download
    $thumb_urls = array();
    if ( ! empty( $color_thumbs ) ) {
        foreach ( $color_thumbs as $thumb ) {
            if ( ! empty( $thumb ) && filter_var( $thumb, FILTER_VALIDATE_URL ) ) {
                $thumb_urls[] = $thumb;
            }
        }
    }
    $all_download_urls = array_values( array_unique( array_merge( $all_image_urls, $thumb_urls ) ) );

    return array(
        'block_html' => $block_html,
        'css'        => $css,
        'image_urls' => $all_download_urls,
        'js'         => $js,
    );
}
endif;

// =============================================
// CONVERSOR CSS SELETOR -> XPATH
// =============================================
if ( ! function_exists( 'blkcloner_css_to_xpath' ) ) :
function blkcloner_css_to_xpath( $selector ) {
    $selector = trim( $selector );

    // ID selector: #myId
    if ( preg_match( '/^#([\w-]+)$/', $selector, $m ) ) {
        return "//*[@id='{$m[1]}']";
    }

    // Class selector: .myClass
    if ( preg_match( '/^\.([\w-]+)$/', $selector, $m ) ) {
        return "//*[contains(concat(' ', normalize-space(@class), ' '), ' {$m[1]} ')]";
    }

    // Tag selector: div
    if ( preg_match( '/^(\w+)$/', $selector, $m ) ) {
        return "//{$m[1]}";
    }

    // Tag.class: div.myClass
    if ( preg_match( '/^(\w+)\.([\w-]+)$/', $selector, $m ) ) {
        return "//{$m[1]}[contains(concat(' ', normalize-space(@class), ' '), ' {$m[2]} ')]";
    }

    // Tag#id: div#myId
    if ( preg_match( '/^(\w+)#([\w-]+)$/', $selector, $m ) ) {
        return "//{$m[1]}[@id='{$m[2]}']";
    }

    // Attribute presence only: [data-image-urls] (sem valor)
    if ( preg_match( '/^\[([\w][\w-]*)\]$/', $selector, $m ) ) {
        return "//*[@{$m[1]}]";
    }

    // data-attribute exact: [data-component="name"]
    if ( preg_match( '/^\[(\w[\w-]*)=["\']?([^"\']*)["\']?\]$/', $selector, $m ) ) {
        return "//*[@{$m[1]}='{$m[2]}']";
    }

    // Attribute contains: [data-js-slider-360*="init"] ou [class*="slider-360"]
    if ( preg_match( '/^\[(\w[\w-]*)\*=["\']?([^"\']*)["\']?\]$/', $selector, $m ) ) {
        return "//*[contains(@{$m[1]}, '{$m[2]}')]";
    }

    // Attribute starts-with: [data-type^="color"]
    if ( preg_match( '/^\[(\w[\w-]*)\^=["\']?([^"\']*)["\']?\]$/', $selector, $m ) ) {
        return "//*[starts-with(@{$m[1]}, '{$m[2]}')]";
    }

    // Multi-class: .class1.class2 (2 classes)
    if ( preg_match( '/^\.([\w-]+)\.([\w-]+)$/', $selector, $m ) ) {
        return "//*[contains(concat(' ', normalize-space(@class), ' '), ' {$m[1]} ') and contains(concat(' ', normalize-space(@class), ' '), ' {$m[2]} ')]";
    }

    // Multi-class: .class1.class2.class3 (3 classes)
    if ( preg_match( '/^\.([\w-]+)\.([\w-]+)\.([\w-]+)$/', $selector, $m ) ) {
        return "//*[contains(concat(' ', normalize-space(@class), ' '), ' {$m[1]} ') and contains(concat(' ', normalize-space(@class), ' '), ' {$m[2]} ') and contains(concat(' ', normalize-space(@class), ' '), ' {$m[3]} ')]";
    }

    // Tag com multi-class: div.class1.class2
    if ( preg_match( '/^(\w+)\.([\w-]+)\.([\w-]+)$/', $selector, $m ) ) {
        return "//{$m[1]}[contains(concat(' ', normalize-space(@class), ' '), ' {$m[2]} ') and contains(concat(' ', normalize-space(@class), ' '), ' {$m[3]} ')]";
    }

    // Tag[attr] com valor: tag com atributo
    if ( preg_match( '/^(\w+)\[(\w[\w-]*)=["\']?([^"\']*)["\']?\]$/', $selector, $m ) ) {
        return "//{$m[1]}[@{$m[2]}='{$m[3]}']";
    }

    // Tag[attr] presença: div[data-image-urls]
    if ( preg_match( '/^(\w+)\[([\w][\w-]*)\]$/', $selector, $m ) ) {
        return "//{$m[1]}[@{$m[2]}]";
    }

    // Descendant: .parent .child (suporta classes com __ e --)
    if ( preg_match( '/^([\.\#\w][\w-]*(?:__[\w-]+)?(?:--[\w-]+)?)\s+([\.\#\w][\w-]*(?:__[\w-]+)?(?:--[\w-]+)?)$/', $selector, $m ) ) {
        $parent = blkcloner_css_to_xpath( $m[1] );
        $child_sel = $m[2];
        if ( $child_sel[0] === '.' ) {
            $class = substr( $child_sel, 1 );
            return $parent . "//*[contains(concat(' ', normalize-space(@class), ' '), ' {$class} ')]";
        } elseif ( $child_sel[0] === '#' ) {
            $id = substr( $child_sel, 1 );
            return $parent . "//*[@id='{$id}']";
        } else {
            return $parent . "//{$child_sel}";
        }
    }

    // Descendant com > (child direto): .parent > .child
    if ( preg_match( '/^([\.\#\w][\w-]*(?:__[\w-]+)?)\s*>\s*([\.\#\w][\w-]*(?:__[\w-]+)?)$/', $selector, $m ) ) {
        $parent = blkcloner_css_to_xpath( $m[1] );
        $child_sel = $m[2];
        if ( $child_sel[0] === '.' ) {
            $class = substr( $child_sel, 1 );
            return $parent . "/*[contains(concat(' ', normalize-space(@class), ' '), ' {$class} ')]";
        } elseif ( $child_sel[0] === '#' ) {
            $id = substr( $child_sel, 1 );
            return $parent . "/*[@id='{$id}']";
        } else {
            return $parent . "/{$child_sel}";
        }
    }

    // Fallback: tentar como classe (suporta nomes BEM com __ e --)
    $clean = str_replace( array( '.', '#' ), array( '', '' ), $selector );
    return "//*[contains(concat(' ', normalize-space(@class), ' '), ' {$clean} ') or @id='{$clean}' or contains(@data-component, '{$clean}') or @data-js-slider-360 or contains(@class, '{$clean}')]";
}
endif;

// =============================================
// SELETORES ALTERNATIVOS
// =============================================
if ( ! function_exists( 'blkcloner_generate_alt_selectors' ) ) :
function blkcloner_generate_alt_selectors( $selector ) {
    $alts = array();
    $clean = preg_replace( '/[.#\[\]="\']/', ' ', $selector );
    $words = array_filter( explode( ' ', $clean ) );

    foreach ( $words as $word ) {
        $alts[] = '.' . $word;
        $alts[] = '#' . $word;
        $alts[] = '[data-component="' . $word . '"]';
        $alts[] = '[data-module="' . $word . '"]';
        $alts[] = '[data-block="' . $word . '"]';
    }

    // Se contém "360", "rotator", "spin", "slider" - adicionar alternativas de rotação
    $sel_lower = strtolower( $selector );
    if ( strpos( $sel_lower, '360' ) !== false || strpos( $sel_lower, 'rotat' ) !== false
        || strpos( $sel_lower, 'spin' ) !== false || strpos( $sel_lower, 'slider' ) !== false ) {
        $alts[] = '.d-slider-360';
        $alts[] = '.model-preview__bike-carousel_360';
        $alts[] = '.slide-360';
        $alts[] = '.model-preview-content';
        $alts[] = '[data-js-slider-360]';
        $alts[] = '[data-image-urls]';
        $alts[] = '.threesixty';
        $alts[] = '.magic-360';
        $alts[] = '.spin-viewer';
        $alts[] = '.viewer-360';
        $alts[] = '.rotation-360';
    }

    // Se contém "color", "variant", "swatch" - adicionar alternativas de cor
    if ( strpos( $sel_lower, 'color' ) !== false || strpos( $sel_lower, 'variant' ) !== false
        || strpos( $sel_lower, 'swatch' ) !== false ) {
        $alts[] = '.color-switch';
        $alts[] = '.color-selector';
        $alts[] = '.color-picker';
        $alts[] = '.variant-selector';
        $alts[] = 'ul.color-switch';
        $alts[] = '[data-type*="color"]';
    }

    // Se contém "product", "bike", "model", "preview" - adicionar alternativas genéricas de produto
    if ( strpos( $sel_lower, 'product' ) !== false || strpos( $sel_lower, 'bike' ) !== false
        || strpos( $sel_lower, 'model' ) !== false || strpos( $sel_lower, 'preview' ) !== false ) {
        $alts[] = '.model-preview-content';
        $alts[] = '.model-preview__bike-carousel';
        $alts[] = '.product-gallery';
        $alts[] = '.product-viewer';
        $alts[] = '.bike-configurator';
    }

    // Sempre adicionar seletores genéricos de rotação/cor como último recurso
    $alts[] = '.model-preview-content';
    $alts[] = '[data-image-urls]';

    return array_unique( $alts );
}
endif;

// =============================================
// RESOLVER URLs RELATIVAS
// =============================================
if ( ! function_exists( 'blkcloner_resolve_urls' ) ) :
function blkcloner_resolve_urls( $html, $base_url ) {
    $parsed = wp_parse_url( $base_url );
    $origin = $parsed['scheme'] . '://' . $parsed['host'];
    $base_path = isset( $parsed['path'] ) ? dirname( $parsed['path'] ) : '/';

    // URLs que começam com //
    $html = preg_replace( '#(src|href|data-src|data-lazy|data-original|srcset|poster)=(["\'])//([^"\']+)(["\'])#i',
        '$1=$2https://$3$4', $html );

    // URLs que começam com /
    $html = preg_replace_callback(
        '#(src|href|data-src|data-lazy|data-original|poster)=(["\'])/([^/][^"\']*?)(["\'])#i',
        function ( $matches ) use ( $origin ) {
            return $matches[1] . '=' . $matches[2] . $origin . '/' . $matches[3] . $matches[4];
        },
        $html
    );

    // URLs relativas (sem / no início)
    $html = preg_replace_callback(
        '#(src|href|data-src|data-lazy|data-original|poster)=(["\'])(?!https?://|data:|javascript:|#|mailto:)([^"\']+?)(["\'])#i',
        function ( $matches ) use ( $origin, $base_path ) {
            return $matches[1] . '=' . $matches[2] . $origin . rtrim( $base_path, '/' ) . '/' . $matches[3] . $matches[4];
        },
        $html
    );

    // srcset com múltiplos URLs
    $html = preg_replace_callback(
        '#srcset=(["\'])([^"\']+)(["\'])#i',
        function ( $matches ) use ( $origin, $base_path ) {
            $srcset = $matches[2];
            $parts = explode( ',', $srcset );
            $resolved = array();
            foreach ( $parts as $part ) {
                $part = trim( $part );
                if ( preg_match( '#^/([^/])#', $part ) ) {
                    $part = preg_replace( '#^/#', $origin . '/', $part );
                } elseif ( ! preg_match( '#^https?://#', $part ) ) {
                    $part = $origin . rtrim( $base_path, '/' ) . '/' . $part;
                }
                $resolved[] = $part;
            }
            return 'srcset=' . $matches[1] . implode( ', ', $resolved ) . $matches[3];
        },
        $html
    );

    return $html;
}
endif;

// =============================================
// EXTRAIR URLs DE IMAGENS
// =============================================
if ( ! function_exists( 'blkcloner_extract_image_urls' ) ) :
function blkcloner_extract_image_urls( $html, $base_url ) {
    $urls = array();
    $parsed_base = wp_parse_url( $base_url );
    $origin = $parsed_base['scheme'] . '://' . $parsed_base['host'];

    // Padrões para encontrar imagens
    $patterns = array(
        '#(?:src|data-src|data-lazy|data-original|poster)=["\']([^"\']+\.(?:jpg|jpeg|png|gif|svg|webp|avif|bmp|ico)(?:\?[^"\']*)?)["\']#i',
        '#url\(["\']?([^"\')\s]+\.(?:jpg|jpeg|png|gif|svg|webp|avif)(?:\?[^"\')\s]*)?)["\']?\)#i',
        '#srcset=["\']([^"\']+)["\']#i',
    );

    foreach ( $patterns as $pattern ) {
        if ( preg_match_all( $pattern, $html, $matches ) ) {
            foreach ( $matches[1] as $url ) {
                // Processar srcset
                if ( strpos( $url, ',' ) !== false && strpos( $url, ' ' ) !== false ) {
                    $parts = explode( ',', $url );
                    foreach ( $parts as $part ) {
                        $part = trim( preg_replace( '/\s+\d+[wx]$/', '', trim( $part ) ) );
                        if ( ! empty( $part ) ) {
                            $urls[] = $part;
                        }
                    }
                } else {
                    $urls[] = $url;
                }
            }
        }
    }

    // Extrair também de data-attributes com JSON
    if ( preg_match_all( '#data-[\w-]+=["\'](\{[^"\']+\})["\']#i', $html, $json_matches ) ) {
        foreach ( $json_matches[1] as $json_str ) {
            $data = json_decode( html_entity_decode( $json_str ), true );
            if ( is_array( $data ) ) {
                array_walk_recursive( $data, function( $value ) use ( &$urls ) {
                    if ( is_string( $value ) && preg_match( '#\.(jpg|jpeg|png|gif|svg|webp|avif)(\?|$)#i', $value ) ) {
                        $urls[] = $value;
                    }
                });
            }
        }
    }

    // Extrair de data-image-urls (formato Ducati: URLs separadas por vírgula)
    if ( preg_match_all( '#data-image-urls=["\']([^"\']+)["\']#i', $html, $url_list_matches ) ) {
        foreach ( $url_list_matches[1] as $url_list ) {
            $decoded = html_entity_decode( $url_list );
            $img_urls = explode( ',', $decoded );
            foreach ( $img_urls as $img_url ) {
                $img_url = trim( $img_url );
                if ( ! empty( $img_url ) && filter_var( $img_url, FILTER_VALIDATE_URL ) ) {
                    $urls[] = $img_url;
                }
            }
        }
    }

    // Extrair de background-image em atributos style com URLs de imagem
    if ( preg_match_all( '#style=["\'][^"\']*background-image:\s*url\(["\']?([^"\')\s]+)["\']?\)[^"\']*["\']#i', $html, $bg_matches ) ) {
        foreach ( $bg_matches[1] as $bg_url ) {
            if ( preg_match( '#\.(jpg|jpeg|png|gif|svg|webp|avif)(\?|$)#i', $bg_url ) ) {
                $urls[] = $bg_url;
            }
        }
    }

    // Resolver e deduplificar
    $urls = array_unique( array_filter( $urls ) );

    return array_values( $urls );
}
endif;

// =============================================
// EXTRAIR CSS
// =============================================
if ( ! function_exists( 'blkcloner_extract_css' ) ) :
function blkcloner_extract_css( $doc, $xpath, $target_node, $base_url ) {
    $css = '';
    $parsed_base = wp_parse_url( $base_url );
    $origin = $parsed_base['scheme'] . '://' . $parsed_base['host'];

    // 1. Extrair <style> inline
    $styles = $xpath->query( '//style' );
    foreach ( $styles as $style ) {
        $css .= $style->textContent . "\n";
    }

    // 2. Extrair folhas de estilo externas (link[rel=stylesheet])
    $links = $xpath->query( '//link[@rel="stylesheet"]' );
    foreach ( $links as $link ) {
        $href = $link->getAttribute( 'href' );
        if ( empty( $href ) ) {
            continue;
        }

        // Resolver URL
        if ( strpos( $href, '//' ) === 0 ) {
            $href = 'https:' . $href;
        } elseif ( strpos( $href, 'http' ) !== 0 ) {
            $href = $origin . '/' . ltrim( $href, '/' );
        }

        // Descarregar CSS
        $response = wp_remote_get( $href, array(
            'timeout'    => 15,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'sslverify'  => false,
        ));

        if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
            $css_content = wp_remote_retrieve_body( $response );
            // Resolver URLs relativas no CSS
            $css_base = dirname( $href );
            $css_content = preg_replace_callback(
                '#url\(["\']?(?!data:|https?://|//)([^"\')\s]+)["\']?\)#i',
                function ( $m ) use ( $css_base ) {
                    return 'url(' . $css_base . '/' . $m[1] . ')';
                },
                $css_content
            );
            $css .= "\n/* Fonte: {$href} */\n" . $css_content . "\n";
        }
    }

    // 3. Extrair estilos inline do bloco e filhos
    $inline_styles = $xpath->query( './/*[@style]', $target_node );
    // (estilos inline são preservados no HTML, não precisam de extração separada)

    // 4. Filtrar CSS para incluir apenas regras relevantes ao bloco
    $block_html = $doc->saveHTML( $target_node );
    if ( ! empty( $block_html ) && function_exists( 'blkcloner_filter_relevant_css' ) ) {
        $relevant_css = blkcloner_filter_relevant_css( $css, $block_html );
        if ( ! empty( $relevant_css ) ) {
            $css = $relevant_css;
        }
    }

    return $css;
}
endif;

// =============================================
// EXTRAIR JS
// =============================================
if ( ! function_exists( 'blkcloner_extract_js' ) ) :
function blkcloner_extract_js( $doc, $xpath, $target_node, $base_url ) {
    $js = '';
    $parsed_base = wp_parse_url( $base_url );
    $origin = $parsed_base['scheme'] . '://' . $parsed_base['host'];

    // 1. JS inline dentro do bloco
    $scripts = $xpath->query( './/script', $target_node );
    foreach ( $scripts as $script ) {
        $src = $script->getAttribute( 'src' );
        if ( empty( $src ) ) {
            $js .= $script->textContent . "\n";
        }
    }

    // 2. Scripts com src dentro do bloco
    foreach ( $scripts as $script ) {
        $src = $script->getAttribute( 'src' );
        if ( ! empty( $src ) ) {
            if ( strpos( $src, '//' ) === 0 ) {
                $src = 'https:' . $src;
            } elseif ( strpos( $src, 'http' ) !== 0 ) {
                $src = $origin . '/' . ltrim( $src, '/' );
            }

            $response = wp_remote_get( $src, array(
                'timeout'    => 15,
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'sslverify'  => false,
            ));

            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $js .= "\n/* Fonte: {$src} */\n" . wp_remote_retrieve_body( $response ) . "\n";
            }
        }
    }

    // 3. Procurar data-attributes com configurações JS
    $data_nodes = $xpath->query( './/*[@*[starts-with(name(), "data-")]]', $target_node );
    $data_config = array();
    foreach ( $data_nodes as $node ) {
        foreach ( $node->attributes as $attr ) {
            if ( strpos( $attr->name, 'data-' ) === 0 && $attr->name !== 'data-src' ) {
                $val = $attr->value;
                $decoded = json_decode( $val, true );
                if ( is_array( $decoded ) ) {
                    $data_config[ $attr->name ] = $decoded;
                }
            }
        }
    }

    if ( ! empty( $data_config ) ) {
        $js = "/* Configurações de data-attributes extraídas */\n" .
              "var blockClonerConfig = " . wp_json_encode( $data_config, JSON_PRETTY_PRINT ) . ";\n\n" . $js;
    }

    return $js;
}
endif;

// =============================================
// OBTER CLASSES DE UM NÓ
// =============================================
if ( ! function_exists( 'blkcloner_get_classes_from_node' ) ) :
function blkcloner_get_classes_from_node( $node ) {
    $classes = array();

    if ( $node->hasAttribute( 'class' ) ) {
        $classes = array_merge( $classes, explode( ' ', $node->getAttribute( 'class' ) ) );
    }

    if ( $node->hasChildNodes() ) {
        foreach ( $node->childNodes as $child ) {
            if ( $child->nodeType === XML_ELEMENT_NODE ) {
                $classes = array_merge( $classes, blkcloner_get_classes_from_node( $child ) );
            }
        }
    }

    return array_unique( array_filter( $classes ) );
}
endif;

// =============================================
// OBTER IDS DE UM NÓ
// =============================================
if ( ! function_exists( 'blkcloner_get_ids_from_node' ) ) :
function blkcloner_get_ids_from_node( $node ) {
    $ids = array();

    if ( $node->hasAttribute( 'id' ) ) {
        $ids[] = $node->getAttribute( 'id' );
    }

    if ( $node->hasChildNodes() ) {
        foreach ( $node->childNodes as $child ) {
            if ( $child->nodeType === XML_ELEMENT_NODE ) {
                $ids = array_merge( $ids, blkcloner_get_ids_from_node( $child ) );
            }
        }
    }

    return array_unique( array_filter( $ids ) );
}
endif;

// =============================================
// FILTRAR CSS RELEVANTE
// =============================================
// Definição única em block-cloner-shortcode.php (assinatura: $css, $html)
// Removida versão antiga com assinatura ($css, $classes, $ids) que conflituava

// =============================================
// DESCARREGAR E GUARDAR IMAGENS EM PASTA DO BLOCO
// =============================================
if ( ! function_exists( 'blkcloner_download_images' ) ) :
/**
 * Descarrega imagens e organiza no banco local por bloco.
 * Estrutura: wp-content/cache/block-cloner/{block_id}/{block_id}_001.png
 *
 * @param array  $urls       Lista de URLs de imagens.
 * @param string $source_url URL da página de origem (para Referer).
 * @param string $block_id   ID do bloco para organizar as imagens.
 * @return array Lista de imagens com caminhos locais.
 */
function blkcloner_download_images( $urls, $source_url, $block_id = '' ) {
    $images = array();

    // Criar pasta do bloco
    if ( ! empty( $block_id ) ) {
        $block_dir = BLKCLONER_CACHE_DIR . $block_id . '/';
        $block_url = BLKCLONER_CACHE_URL . $block_id . '/';
        if ( ! file_exists( $block_dir ) ) {
            wp_mkdir_p( $block_dir );
            file_put_contents( $block_dir . 'index.php', '<?php // Silence is golden.' . "\n" );
        }
    } else {
        $block_dir = BLKCLONER_CACHE_DIR;
        $block_url = BLKCLONER_CACHE_URL;
    }

    $index = 1;
    foreach ( $urls as $url ) {
        $original = $url;

        // Extensão do ficheiro
        $ext = pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION );
        if ( empty( $ext ) || strlen( $ext ) > 5 ) {
            $ext = 'jpg';
        }

        // Nome sequencial: {block_id}_001.png
        $seq = str_pad( $index, 3, '0', STR_PAD_LEFT );
        $filename = ( $block_id ? $block_id . '_' : '' ) . $seq . '.' . $ext;
        $local_path = $block_dir . $filename;
        $local_url  = $block_url . $filename;

        // Verificar se já está em cache
        if ( file_exists( $local_path ) ) {
            $images[] = array(
                'original'   => $original,
                'local_url'  => $local_url,
                'local_path' => $local_path,
                'cached'     => true,
            );
            $index++;
            continue;
        }

        // Fallback: verificar cache flat antigo (md5)
        $old_cache = BLKCLONER_CACHE_DIR . md5( $url ) . '.' . $ext;
        if ( file_exists( $old_cache ) ) {
            // Mover para nova estrutura
            copy( $old_cache, $local_path );
            $images[] = array(
                'original'   => $original,
                'local_url'  => $local_url,
                'local_path' => $local_path,
                'cached'     => true,
            );
            $index++;
            continue;
        }

        // Descarregar
        $response = wp_remote_get( $url, array(
            'timeout'    => 20,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'sslverify'  => false,
            'headers'    => array(
                'Referer' => $source_url,
                'Accept'  => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            ),
        ));

        if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
            $body = wp_remote_retrieve_body( $response );
            if ( ! empty( $body ) ) {
                file_put_contents( $local_path, $body );
                $images[] = array(
                    'original'   => $original,
                    'local_url'  => $local_url,
                    'local_path' => $local_path,
                    'cached'     => false,
                );
                $index++;
                continue;
            }
        }

        // Se falhou, usar proxy URL para evitar hotlink blocking
        $proxy_url = home_url( '/?blkcloner_proxy=1&url=' . rawurlencode( $original ) );
        $images[] = array(
            'original'   => $original,
            'local_url'  => $proxy_url,
            'local_path' => '',
            'cached'     => false,
            'error'      => 'Não foi possível descarregar — a usar proxy',
        );
        $index++;
    }

    return $images;
}
endif;

// =============================================
// CSS DA PÁGINA ADMIN
// =============================================
if ( ! function_exists( 'blkcloner_admin_css' ) ) :
function blkcloner_admin_css() {
    return '
    .blkcloner-wrap { max-width: 1200px; margin: 20px auto; }
    .blkcloner-card { background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
    .blkcloner-card h2 { margin-top: 0; padding-bottom: 12px; border-bottom: 1px solid #eee; color: #1d2327; }
    .blkcloner-form-row { margin-bottom: 16px; }
    .blkcloner-form-row label { display: block; font-weight: 600; margin-bottom: 6px; color: #1d2327; }
    .blkcloner-form-row input[type="text"],
    .blkcloner-form-row input[type="url"],
    .blkcloner-form-row textarea { width: 100%; padding: 8px 12px; border: 1px solid #8c8f94; border-radius: 4px; font-size: 14px; }
    .blkcloner-form-row textarea { min-height: 80px; font-family: monospace; }
    .blkcloner-form-row .description { color: #646970; font-size: 13px; margin-top: 4px; }
    .blkcloner-btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 20px; border-radius: 4px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; transition: all 0.2s; }
    .blkcloner-btn-primary { background: #2271b1; color: #fff; }
    .blkcloner-btn-primary:hover { background: #135e96; }
    .blkcloner-btn-danger { background: #d63638; color: #fff; }
    .blkcloner-btn-danger:hover { background: #b32d2e; }
    .blkcloner-btn-secondary { background: #f0f0f1; color: #2c3338; border: 1px solid #8c8f94; }
    .blkcloner-btn-secondary:hover { background: #dcdcde; }
    .blkcloner-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    .blkcloner-spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid rgba(255,255,255,.3); border-top-color: #fff; border-radius: 50%; animation: blkcloner-spin 0.6s linear infinite; }
    @keyframes blkcloner-spin { to { transform: rotate(360deg); } }
    .blkcloner-saved-list { display: grid; gap: 12px; }
    .blkcloner-saved-item { display: flex; justify-content: space-between; align-items: center; padding: 16px; background: #f9f9f9; border-radius: 6px; border: 1px solid #e0e0e0; }
    .blkcloner-saved-item-info h4 { margin: 0 0 4px; }
    .blkcloner-saved-item-info code { background: #e8f0fe; padding: 2px 8px; border-radius: 3px; font-size: 13px; color: #1a73e8; }
    .blkcloner-saved-item-actions { display: flex; gap: 8px; }
    .blkcloner-tabs { display: flex; gap: 0; border-bottom: 2px solid #c3c4c7; margin-bottom: 16px; }
    .blkcloner-tab { padding: 10px 20px; cursor: pointer; border: none; background: none; font-size: 14px; color: #646970; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s; }
    .blkcloner-tab.active { color: #2271b1; border-bottom-color: #2271b1; font-weight: 600; }
    .blkcloner-tab-content { display: none; }
    .blkcloner-tab-content.active { display: block; }
    .blkcloner-notice { padding: 12px 16px; border-radius: 4px; margin: 12px 0; border-left: 4px solid; }
    .blkcloner-notice-success { background: #edfaef; border-color: #00a32a; color: #005c12; }
    .blkcloner-notice-error { background: #fcf0f1; border-color: #d63638; color: #8a2424; }
    .blkcloner-notice-info { background: #f0f6fc; border-color: #72aee6; color: #2c3338; }
    .blkcloner-code-block { background: #1d2327; color: #e0e0e0; padding: 16px; border-radius: 6px; font-family: "Fira Code", monospace; font-size: 13px; overflow-x: auto; max-height: 300px; white-space: pre-wrap; word-break: break-all; }
    .blkcloner-selector-hints { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
    .blkcloner-hint { background: #f0f0f1; padding: 4px 10px; border-radius: 12px; font-size: 12px; cursor: pointer; border: 1px solid #dcdcde; transition: all 0.2s; }
    .blkcloner-hint:hover { background: #2271b1; color: #fff; border-color: #2271b1; }
    .blkcloner-main-tab { display: none; }
    .blkcloner-main-tab.active { display: block; }
    .blkcloner-toast-container { position: fixed; top: 40px; right: 20px; z-index: 999999; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
    .blkcloner-toast { padding: 14px 20px; border-radius: 8px; color: #fff; font-size: 14px; font-weight: 500; box-shadow: 0 4px 12px rgba(0,0,0,0.15); pointer-events: auto; animation: blkcloner-toast-in 0.3s ease-out; max-width: 400px; display: flex; align-items: center; gap: 8px; }
    .blkcloner-toast-success { background: #00a32a; }
    .blkcloner-toast-error { background: #d63638; }
    .blkcloner-toast-info { background: #2271b1; }
    @keyframes blkcloner-toast-in { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes blkcloner-toast-out { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(40px); } }
    .blkcloner-preview-modal { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 999998; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; }
    .blkcloner-preview-modal-content { background: #fff; border-radius: 12px; width: 95%; max-width: 1100px; max-height: 90vh; overflow: auto; box-shadow: 0 8px 32px rgba(0,0,0,0.3); }
    .blkcloner-preview-modal-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid #e0e0e0; position: sticky; top: 0; background: #fff; z-index: 1; border-radius: 12px 12px 0 0; }
    .blkcloner-preview-modal-body { padding: 0; min-height: 300px; overflow: auto; }
    .blkcloner-preview-modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #646970; padding: 4px 8px; border-radius: 4px; }
    .blkcloner-preview-modal-close:hover { background: #f0f0f1; color: #d63638; }
    .blkcloner-inline-edit { display: inline-flex; align-items: center; gap: 6px; }
    .blkcloner-inline-edit input { padding: 4px 8px; border: 1px solid #2271b1; border-radius: 4px; font-size: 14px; font-weight: 600; }
    .blkcloner-inline-edit button { padding: 4px 8px; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
    .blkcloner-export-import-section { margin-top: 16px; padding: 20px; background: #f0f6fc; border: 1px solid #c3c4c7; border-radius: 8px; }
    .blkcloner-config-modal { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 999998; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; }
    .blkcloner-config-modal-content { background: #fff; border-radius: 12px; width: 95%; max-width: 900px; max-height: 90vh; overflow: auto; box-shadow: 0 8px 32px rgba(0,0,0,0.3); }
    .blkcloner-config-modal-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid #e0e0e0; position: sticky; top: 0; background: #fff; z-index: 1; border-radius: 12px 12px 0 0; }
    .blkcloner-config-modal-body { padding: 20px; }
    .blkcloner-config-section { margin-bottom: 24px; }
    .blkcloner-config-section h4 { margin: 0 0 12px; padding-bottom: 8px; border-bottom: 1px solid #eee; color: #1d2327; }
    .blkcloner-config-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
    .blkcloner-config-field { margin-bottom: 12px; }
    .blkcloner-config-field label { display: block; font-weight: 600; margin-bottom: 4px; font-size: 13px; color: #1d2327; }
    .blkcloner-config-field input { width: 100%; padding: 6px 10px; border: 1px solid #8c8f94; border-radius: 4px; font-size: 13px; }
    .blkcloner-icon-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 10px; max-height: 320px; overflow-y: auto; padding: 4px; }
    .blkcloner-icon-item { border: 2px solid #e0e0e0; border-radius: 8px; overflow: hidden; cursor: pointer; transition: all 0.2s; position: relative; }
    .blkcloner-icon-item:hover { border-color: #2271b1; transform: scale(1.03); }
    .blkcloner-icon-item.selected { border-color: #00a32a; border-width: 3px; box-shadow: 0 0 0 2px rgba(0,163,42,0.2); }
    .blkcloner-icon-item img { width: 100%; height: 80px; object-fit: contain; display: block; background: #f9f9f9; }
    .blkcloner-icon-item .blkcloner-icon-badge { position: absolute; top: 4px; right: 4px; background: #00a32a; color: #fff; width: 20px; height: 20px; border-radius: 50%; display: none; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; }
    .blkcloner-icon-item.selected .blkcloner-icon-badge { display: flex; }
    .blkcloner-icon-slot { border: 2px dashed #c3c4c7; border-radius: 8px; padding: 12px; margin-bottom: 12px; background: #f9f9f9; }
    .blkcloner-icon-slot-header { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
    .blkcloner-icon-slot-preview { width: 50px; height: 50px; border-radius: 50%; border: 2px solid #ddd; background-size: cover; background-position: center; background-color: #eee; }
    .blkcloner-icon-slot-preview.has-image { border-color: #00a32a; }
    ';
}
endif;

// =============================================
// PÁGINA DE ADMINISTRAÇÃO
// =============================================
if ( ! function_exists( 'blkcloner_admin_page' ) ) :
function blkcloner_admin_page() {
    $saved_blocks = get_option( BLKCLONER_OPTION_KEY, array() );
    $nonce = wp_create_nonce( 'blkcloner_nonce' );
    ?>
    <?php $blkcloner_lang = get_option( 'blkcloner_language', 'pt' ); ?>
    <div class="wrap blkcloner-wrap">
        <h1 style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
            <span class="dashicons dashicons-download" style="font-size:28px;"></span>
            Ducati Block Cloner
            <span style="font-size:12px;background:#f0f6fc;padding:4px 10px;border-radius:12px;color:#2271b1;">v<?php echo BLKCLONER_VERSION; ?></span>
            <span id="blkcloner-lang-selector" style="margin-left:auto;display:flex;gap:4px;align-items:center;">
                <span class="blkcloner-flag<?php echo $blkcloner_lang === 'pt' ? ' active' : ''; ?>" data-lang="pt" title="Português" style="cursor:pointer;font-size:20px;opacity:<?php echo $blkcloner_lang === 'pt' ? '1' : '0.4'; ?>;transition:opacity .2s;">&#127477;&#127481;</span>
                <span class="blkcloner-flag<?php echo $blkcloner_lang === 'en' ? ' active' : ''; ?>" data-lang="en" title="English" style="cursor:pointer;font-size:20px;opacity:<?php echo $blkcloner_lang === 'en' ? '1' : '0.4'; ?>;transition:opacity .2s;">&#127468;&#127463;</span>
                <span class="blkcloner-flag<?php echo $blkcloner_lang === 'es' ? ' active' : ''; ?>" data-lang="es" title="Español" style="cursor:pointer;font-size:20px;opacity:<?php echo $blkcloner_lang === 'es' ? '1' : '0.4'; ?>;transition:opacity .2s;">&#127466;&#127480;</span>
                <span class="blkcloner-flag<?php echo $blkcloner_lang === 'fr' ? ' active' : ''; ?>" data-lang="fr" title="Français" style="cursor:pointer;font-size:20px;opacity:<?php echo $blkcloner_lang === 'fr' ? '1' : '0.4'; ?>;transition:opacity .2s;">&#127467;&#127479;</span>
                <span class="blkcloner-flag<?php echo $blkcloner_lang === 'de' ? ' active' : ''; ?>" data-lang="de" title="Deutsch" style="cursor:pointer;font-size:20px;opacity:<?php echo $blkcloner_lang === 'de' ? '1' : '0.4'; ?>;transition:opacity .2s;">&#127465;&#127466;</span>
                <span class="blkcloner-flag<?php echo $blkcloner_lang === 'it' ? ' active' : ''; ?>" data-lang="it" title="Italiano" style="cursor:pointer;font-size:20px;opacity:<?php echo $blkcloner_lang === 'it' ? '1' : '0.4'; ?>;transition:opacity .2s;">&#127470;&#127481;</span>
            </span>
        </h1>

        <!-- NAVEGAÇÃO PRINCIPAL -->
        <nav class="nav-tab-wrapper" style="margin-bottom:20px;">
            <a href="#" class="nav-tab nav-tab-active" data-main-tab="extrair">Extrair Bloco</a>
            <a href="#" class="nav-tab" data-main-tab="blocos">Blocos Guardados <span class="count" style="background:#2271b1;color:#fff;padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px;"><?php echo count( $saved_blocks ); ?></span></a>
            <a href="#" class="nav-tab" data-main-tab="implementacao">Implementação</a>
            <a href="#" class="nav-tab" data-main-tab="sobre">Sobre</a>

            <a href="#" class="nav-tab" data-main-tab="licenca">Licença</a>
            <a href="#" class="nav-tab" data-main-tab="desinstalar" style="color:#d63638;">Desinstalar</a>
        </nav>

        <!-- TAB: EXTRAIR -->
        <div class="blkcloner-main-tab active" data-main-tab="extrair">
        <div class="blkcloner-card">
            <h2>Extrair Bloco</h2>

            <div class="blkcloner-form-row">
                <label for="blkcloner-url">URL da Página</label>
                <input type="url" id="blkcloner-url" placeholder="https://www.ducati.com/ww/en/bikes/diavel/diavel-v4" />
                <p class="description">Cole a URL completa da página que contém o bloco que quer clonar.</p>
            </div>

            <div class="blkcloner-form-row">
                <label for="blkcloner-selector">Seletor CSS do Bloco</label>
                <input type="text" id="blkcloner-selector" placeholder=".product-gallery, #configurator, [data-component='slider']" />
                <p class="description">
                    Use o Inspetor do browser (F12) para encontrar o seletor. Clique com botão direito no bloco &rarr; Inspecionar &rarr; copie a classe ou ID.
                </p>
                <div class="blkcloner-selector-hints">
                    <span class="blkcloner-hint" data-selector=".d-model-preview" title="Ducati Model Preview">360° Model Preview</span>
                    <span class="blkcloner-hint" data-selector="[data-image-urls]" title="Elementos com arrays de imagens de rotação">Rotação (data-image-urls)</span>
                    <span class="blkcloner-hint" data-selector=".color-switch, .color-selector, .color-btn" title="Seletores de cor">Seletor de Cores</span>
                    <span class="blkcloner-hint" data-selector=".spritespin, [data-spritespin]" title="SpriteSpin 360°">SpriteSpin</span>
                    <span class="blkcloner-hint" data-selector=".product-gallery" title="Galeria de produto">Galeria Produto</span>
                    <span class="blkcloner-hint" data-selector=".configurator, .product-configurator" title="Configurador">Configurador</span>
                    <span class="blkcloner-hint" data-selector=".hero-carousel, .slider-container" title="Carousel/Slider">Carousel</span>
                </div>
            </div>

            <div class="blkcloner-form-row">
                <label for="blkcloner-name">Nome do Bloco (opcional)</label>
                <input type="text" id="blkcloner-name" placeholder="Coloque aqui o nome do bloco..." />
            </div>

            <div class="blkcloner-form-row">
                <label>Dimensões (opcional)</label>
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;">
                    <div>
                        <label for="blkcloner-dim-width" style="font-size:12px;font-weight:400;color:#646970;">Largura Container</label>
                        <input type="text" id="blkcloner-dim-width" placeholder="1100px" value="1100px" style="width:100%;" />
                    </div>
                    <div>
                        <label for="blkcloner-dim-sprite-w" style="font-size:12px;font-weight:400;color:#646970;">Sprite Largura (px)</label>
                        <input type="number" id="blkcloner-dim-sprite-w" placeholder="1920" value="1920" min="100" max="4000" style="width:100%;" />
                    </div>
                    <div>
                        <label for="blkcloner-dim-sprite-h" style="font-size:12px;font-weight:400;color:#646970;">Sprite Altura (px)</label>
                        <input type="number" id="blkcloner-dim-sprite-h" placeholder="1080" value="1080" min="100" max="4000" style="width:100%;" />
                    </div>
                </div>
                <p class="description">Define as dimensões do container e das sprites 360°. As dimensões reais serão auto-detetadas se possível.</p>
            </div>

            <div style="display:flex;gap:10px;align-items:center;">
                <button type="button" id="blkcloner-extract-btn" class="blkcloner-btn blkcloner-btn-primary">
                    <span class="dashicons dashicons-search"></span> Extrair Bloco
                </button>
                <button type="button" id="blkcloner-save-btn" class="blkcloner-btn blkcloner-btn-secondary" disabled>
                    <span class="dashicons dashicons-saved"></span> Guardar Bloco
                </button>
                <span id="blkcloner-status" style="color:#646970;font-size:13px;"></span>
            </div>

            <!-- Resultado -->
            <div id="blkcloner-result" style="display:none;">

                <!-- Dimensões pós-extração com sliders -->
                <div id="blkcloner-post-dims" style="margin:16px 0;padding:16px;background:#f0f6fc;border:1px solid #c3c4c7;border-radius:8px;">
                    <h4 style="margin:0 0 12px;display:flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-image-crop" style="color:#2271b1;"></span>
                        Dimensões Detectadas
                    </h4>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;">
                        <div>
                            <label style="font-size:12px;font-weight:600;color:#1d2327;display:block;margin-bottom:4px;">Largura Container</label>
                            <input type="text" id="blkcloner-post-container-w" value="1100px" style="width:100%;margin-bottom:4px;" />
                            <input type="range" id="blkcloner-post-container-w-slider" min="300" max="1920" value="1100" style="width:100%;" />
                            <span id="blkcloner-post-container-w-val" style="font-size:11px;color:#646970;">1100px</span>
                        </div>
                        <div>
                            <label style="font-size:12px;font-weight:600;color:#1d2327;display:block;margin-bottom:4px;">Sprite Largura (px)</label>
                            <input type="number" id="blkcloner-post-sprite-w" value="1920" min="100" max="4000" style="width:100%;margin-bottom:4px;" />
                            <input type="range" id="blkcloner-post-sprite-w-slider" min="100" max="4000" value="1920" style="width:100%;" />
                            <span id="blkcloner-post-sprite-w-val" style="font-size:11px;color:#646970;">1920px</span>
                        </div>
                        <div>
                            <label style="font-size:12px;font-weight:600;color:#1d2327;display:block;margin-bottom:4px;">Sprite Altura (px)</label>
                            <input type="number" id="blkcloner-post-sprite-h" value="1080" min="100" max="4000" style="width:100%;margin-bottom:4px;" />
                            <input type="range" id="blkcloner-post-sprite-h-slider" min="100" max="4000" value="1080" style="width:100%;" />
                            <span id="blkcloner-post-sprite-h-val" style="font-size:11px;color:#646970;">1080px</span>
                        </div>
                    </div>
                    <p class="description" style="margin-top:8px;">Ajuste as dimensões com os cursores. As dimensões foram auto-detetadas a partir do bloco extraído.</p>
                </div>

                <div class="blkcloner-tabs">
                    <button class="blkcloner-tab active" data-tab="preview">Preview</button>
                    <button class="blkcloner-tab" data-tab="html">HTML</button>
                    <button class="blkcloner-tab" data-tab="css">CSS</button>
                    <button class="blkcloner-tab" data-tab="js">JavaScript</button>
                    <button class="blkcloner-tab" data-tab="images">Imagens</button>
                </div>

                <div class="blkcloner-tab-content active" data-tab="preview">
                    <?php do_action( 'blkcloner_preview_html' ); ?>
                </div>
                <div class="blkcloner-tab-content" data-tab="html">
                    <pre class="blkcloner-code-block" id="blkcloner-html-code"></pre>
                </div>
                <div class="blkcloner-tab-content" data-tab="css">
                    <pre class="blkcloner-code-block" id="blkcloner-css-code"></pre>
                </div>
                <div class="blkcloner-tab-content" data-tab="js">
                    <pre class="blkcloner-code-block" id="blkcloner-js-code"></pre>
                </div>
                <div class="blkcloner-tab-content" data-tab="images">
                    <div id="blkcloner-images-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;"></div>
                </div>
            </div>
        </div>

        </div><!-- /.blkcloner-main-tab extrair -->

        <!-- TAB: BLOCOS GUARDADOS -->
        <div class="blkcloner-main-tab" data-main-tab="blocos">
        <div class="blkcloner-card">
            <h2>Blocos Guardados</h2>
            <p class="description" style="margin-bottom:16px;">
                Use o shortcode em qualquer página do Elementor. Pode adicioná-lo via widget "Shortcode" ou "HTML" do Elementor.
            </p>

            <div class="blkcloner-saved-list" id="blkcloner-saved-list">
                <?php if ( empty( $saved_blocks ) ) : ?>
                    <div class="blkcloner-notice blkcloner-notice-info">
                        Nenhum bloco guardado. Extraia um bloco acima para começar.
                    </div>
                <?php else : ?>
                    <?php foreach ( $saved_blocks as $block_key => $block ) :
                        // Usar chave do array como fallback se campo 'id' não existir
                        $block_id = ! empty( $block['id'] ) ? $block['id'] : $block_key;
                    ?>
                        <div class="blkcloner-saved-item" data-id="<?php echo esc_attr( $block_id ); ?>">
                            <div class="blkcloner-saved-item-info">
                                <h4><?php echo esc_html( ! empty( $block['name'] ) ? $block['name'] : $block_key ); ?></h4>
                                <code><?php echo esc_html( ! empty( $block['shortcode'] ) ? $block['shortcode'] : '[cloned_block id="' . $block_key . '"]' ); ?></code>
                                <br>
                                <small style="color:#646970;">
                                    Fonte: <?php echo esc_html( ! empty( $block['source_url'] ) ? $block['source_url'] : '—' ); ?> |
                                    Criado: <?php echo esc_html( ! empty( $block['created_at'] ) ? $block['created_at'] : '—' ); ?>
                                </small>
                            </div>
                            <div class="blkcloner-saved-item-actions" style="flex-wrap:wrap;">
                                <button class="blkcloner-btn blkcloner-btn-secondary blkcloner-preview-block" title="Preview"
                                        data-id="<?php echo esc_attr( $block_id ); ?>">
                                    <span class="dashicons dashicons-visibility"></span>
                                </button>
                                <button class="blkcloner-btn blkcloner-btn-secondary blkcloner-copy-shortcode"
                                        data-shortcode="<?php echo esc_attr( ! empty( $block['shortcode'] ) ? $block['shortcode'] : '[cloned_block id="' . $block_key . '"]' ); ?>">
                                    <span class="dashicons dashicons-clipboard"></span> Copiar
                                </button>
                                <button class="blkcloner-btn blkcloner-btn-secondary blkcloner-rename-block" title="Renomear"
                                        data-id="<?php echo esc_attr( $block_id ); ?>"
                                        data-name="<?php echo esc_attr( ! empty( $block['name'] ) ? $block['name'] : $block_key ); ?>">
                                    <span class="dashicons dashicons-edit"></span>
                                </button>
                                <button class="blkcloner-btn blkcloner-btn-secondary blkcloner-config-block" title="Configurar (dimensões, icons de cor)"
                                        data-id="<?php echo esc_attr( $block_id ); ?>"
                                        data-name="<?php echo esc_attr( ! empty( $block['name'] ) ? $block['name'] : $block_key ); ?>">
                                    <span class="dashicons dashicons-admin-generic"></span>
                                </button>
                                <button class="blkcloner-btn blkcloner-btn-secondary blkcloner-duplicate-block" title="Duplicar"
                                        data-id="<?php echo esc_attr( $block_id ); ?>">
                                    <span class="dashicons dashicons-admin-page"></span>
                                </button>
                                <button class="blkcloner-btn blkcloner-btn-secondary blkcloner-export-images" title="Exportar Imagens (ZIP)"
                                        data-id="<?php echo esc_attr( $block_id ); ?>"
                                        data-name="<?php echo esc_attr( ! empty( $block['name'] ) ? $block['name'] : $block_key ); ?>">
                                    <span class="dashicons dashicons-format-gallery"></span>
                                </button>
                                <button type="button" class="blkcloner-btn blkcloner-btn-danger blkcloner-delete-block"
                                        data-id="<?php echo esc_attr( $block_id ); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- FERRAMENTAS -->
        <div class="blkcloner-card">
            <h2>Ferramentas</h2>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <button type="button" id="blkcloner-clear-cache" class="blkcloner-btn blkcloner-btn-secondary">
                    <span class="dashicons dashicons-trash"></span> Limpar Cache
                </button>
            </div>

            <?php
            // Diagnóstico: detetar pastas duplicadas do plugin
            $plugins_dir    = WP_PLUGIN_DIR;
            $current_folder = defined( 'BLKCLONER_PLUGIN_FILE' ) ? basename( dirname( BLKCLONER_PLUGIN_FILE ) ) : basename( __DIR__ );
            $duplicates     = array();
            if ( is_dir( $plugins_dir ) ) {
                $dirs = glob( $plugins_dir . '/ducati-block-cloner*', GLOB_ONLYDIR );
                if ( $dirs && count( $dirs ) > 1 ) {
                    foreach ( $dirs as $dir ) {
                        $folder = basename( $dir );
                        $duplicates[] = $folder;
                    }
                }
                // Verificar também nome antigo
                $old_dirs = glob( $plugins_dir . '/elementor-block-cloner*', GLOB_ONLYDIR );
                if ( $old_dirs ) {
                    foreach ( $old_dirs as $dir ) {
                        $duplicates[] = basename( $dir );
                    }
                }
            }
            if ( ! empty( $duplicates ) ) : ?>
            <div class="blkcloner-notice" style="background:#fff3cd;border-left:4px solid #ffc107;padding:12px 16px;margin-top:16px;">
                <h4 style="margin:0 0 8px;color:#856404;">
                    <span class="dashicons dashicons-warning" style="color:#ffc107;"></span>
                    Pastas duplicadas detetadas
                </h4>
                <p style="margin:0 0 8px;color:#856404;">
                    Foram encontradas várias pastas do plugin. Isto pode impedir a eliminação do plugin pelo WordPress.
                </p>
                <ul style="margin:0 0 8px;padding-left:20px;color:#856404;">
                    <?php foreach ( $duplicates as $dup ) : ?>
                        <li><code>wp-content/plugins/<?php echo esc_html( $dup ); ?>/</code>
                            <?php echo ( $dup === $current_folder ) ? ' <strong>(ativa)</strong>' : ' <em>(pode ser apagada)</em>'; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <p style="margin:0;color:#856404;font-size:12px;">
                    <strong>Solução:</strong> Via FTP ou Gestor de Ficheiros do alojamento, apague as pastas <em>inativas</em>
                    em <code>wp-content/plugins/</code>. Mantenha apenas a pasta <strong><?php echo esc_html( $current_folder ); ?></strong>.
                </p>
            </div>
            <?php endif; ?>

            <div style="margin-top:16px;padding:10px 14px;background:#f0f6fc;border-radius:6px;">
                <small style="color:#646970;">
                    <strong>Info:</strong>
                    Pasta ativa: <code><?php echo esc_html( $current_folder ); ?></code> |
                    Ficheiro: <code><?php echo esc_html( defined( 'BLKCLONER_PLUGIN_FILE' ) ? plugin_basename( BLKCLONER_PLUGIN_FILE ) : basename( __DIR__ ) . '/' . basename( __FILE__ ) ); ?></code> |
                    Versão: <?php echo esc_html( BLKCLONER_VERSION ); ?>
                </small>
            </div>
        </div>
        <!-- EXPORT/IMPORT -->
        <div class="blkcloner-card">
            <h2><span class="dashicons dashicons-database-export" style="margin-right:6px;"></span>Exportar / Importar Blocos</h2>
            <p class="description" style="margin-bottom:16px;">
                Exporte blocos como ficheiro JSON para backup ou migração entre sites WordPress.
            </p>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                <!-- EXPORTAR -->
                <div style="background:#f0f6fc;border:1px solid #c3c4c7;border-radius:8px;padding:20px;">
                    <h4 style="margin:0 0 8px;"><span class="dashicons dashicons-upload" style="margin-right:4px;color:#2271b1;"></span>Exportar</h4>
                    <p style="color:#646970;font-size:13px;margin:0 0 12px;">
                        Descarrega todos os blocos guardados como ficheiro JSON.
                    </p>
                    <button type="button" id="blkcloner-export-btn" class="blkcloner-btn blkcloner-btn-primary" <?php echo empty( $saved_blocks ) ? 'disabled' : ''; ?>>
                        <span class="dashicons dashicons-download"></span> Exportar <?php echo count( $saved_blocks ); ?> Bloco(s)
                    </button>
                </div>

                <!-- IMPORTAR -->
                <div style="background:#f9f9f9;border:1px solid #e0e0e0;border-radius:8px;padding:20px;">
                    <h4 style="margin:0 0 8px;"><span class="dashicons dashicons-download" style="margin-right:4px;color:#00a32a;"></span>Importar</h4>
                    <p style="color:#646970;font-size:13px;margin:0 0 12px;">
                        Importe blocos a partir de um ficheiro JSON exportado anteriormente.
                    </p>
                    <input type="file" id="blkcloner-import-file" accept=".json" style="margin-bottom:8px;display:block;" />
                    <button type="button" id="blkcloner-import-btn" class="blkcloner-btn blkcloner-btn-secondary" disabled>
                        <span class="dashicons dashicons-upload"></span> Importar Blocos
                    </button>
                </div>
            </div>
        </div>

        </div><!-- /.blkcloner-main-tab blocos -->

        <!-- TAB: IMPLEMENTAÇÃO -->
        <div class="blkcloner-main-tab" data-main-tab="implementacao">

        <style>
        .blkcloner-impl-section { margin-bottom: 0; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
        .blkcloner-impl-section + .blkcloner-impl-section { margin-top: -1px; border-radius: 0; }
        .blkcloner-impl-section:first-child { border-radius: 8px 8px 0 0; }
        .blkcloner-impl-section:last-child { border-radius: 0 0 8px 8px; }
        .blkcloner-impl-section:only-child { border-radius: 8px; }
        .blkcloner-impl-header { display: flex; align-items: center; gap: 10px; padding: 16px 20px; background: #f9f9f9; cursor: pointer; user-select: none; transition: background 0.2s; }
        .blkcloner-impl-header:hover { background: #f0f6fc; }
        .blkcloner-impl-header .blkcloner-impl-arrow { transition: transform 0.3s; font-size: 14px; color: #646970; }
        .blkcloner-impl-header.open .blkcloner-impl-arrow { transform: rotate(90deg); }
        .blkcloner-impl-header h3 { margin: 0; font-size: 15px; flex: 1; }
        .blkcloner-impl-header .blkcloner-impl-badge { font-size: 11px; padding: 2px 8px; border-radius: 10px; font-weight: 600; }
        .blkcloner-impl-body { display: none; padding: 20px; background: #fff; border-top: 1px solid #e0e0e0; }
        .blkcloner-impl-body.open { display: block; }
        .blkcloner-impl-step { display: flex; gap: 14px; align-items: flex-start; margin-bottom: 16px; }
        .blkcloner-impl-step:last-child { margin-bottom: 0; }
        .blkcloner-impl-num { min-width: 32px; height: 32px; background: #2271b1; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0; }
        .blkcloner-impl-step h4 { margin: 0 0 4px 0; font-size: 14px; color: #1d2327; }
        .blkcloner-impl-step p { margin: 0; color: #646970; font-size: 13px; line-height: 1.6; }
        .blkcloner-code-example { background: #1d2327; color: #e0e0e0; padding: 10px 14px; border-radius: 6px; font-family: 'Fira Code', monospace; font-size: 13px; margin-top: 8px; overflow-x: auto; }
        .blkcloner-impl-note { padding: 12px 16px; background: #fcf9e8; border: 1px solid #dba617; border-radius: 6px; margin-top: 16px; }
        .blkcloner-impl-note h5 { margin: 0 0 6px 0; color: #996800; font-size: 13px; }
        .blkcloner-impl-note ul { margin: 0; padding-left: 18px; color: #646970; font-size: 13px; line-height: 1.8; }
        .blkcloner-impl-tip { padding: 10px 14px; background: #f0f6fc; border-left: 3px solid #2271b1; border-radius: 0 6px 6px 0; margin-top: 12px; font-size: 13px; color: #1d2327; }
        </style>

        <div class="blkcloner-card" style="padding:16px 20px;">
            <h2 style="margin:0 0 4px 0;">Guia de Implementa&ccedil;&atilde;o</h2>
            <p style="color:#646970;font-size:13px;margin:0;">Siga os passos abaixo para extrair, configurar e publicar blocos no seu site WordPress. Clique em cada sec&ccedil;&atilde;o para expandir.</p>
        </div>

        <!-- SECÇÃO 1: COMO EXTRAIR UM BLOCO -->
        <div class="blkcloner-impl-section">
            <div class="blkcloner-impl-header open" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
                <span class="blkcloner-impl-arrow">&#9654;</span>
                <span class="dashicons dashicons-download" style="color:#2271b1;"></span>
                <h3>Como Extrair um Bloco</h3>
                <span class="blkcloner-impl-badge" style="background:#f0f6fc;color:#2271b1;">Passo 1</span>
            </div>
            <div class="blkcloner-impl-body open">
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num">1</div>
                    <div style="flex:1;">
                        <h4>Obter a URL e o Seletor CSS</h4>
                        <p>Abra a p&aacute;gina onde est&aacute; o bloco que pretende copiar. Para encontrar o seletor CSS:</p>
                        <ul style="margin:8px 0 0;padding-left:18px;color:#646970;font-size:13px;line-height:1.8;">
                            <li>Clique com o bot&atilde;o direito sobre o bloco &rarr; <strong>"Inspecionar"</strong></li>
                            <li>No painel DevTools, identifique a classe (<code>.nome-classe</code>) ou ID (<code>#nome-id</code>) do elemento principal</li>
                            <li>Copie o seletor &mdash; ou utilize os <strong>hints r&aacute;pidos</strong> dispon&iacute;veis no campo de seletor</li>
                        </ul>
                        <div class="blkcloner-impl-tip">Dica: Para blocos 360&deg; Ducati, use o seletor <code>.d-model-preview</code>. Para galerias SpriteSpin, use <code>.spritespin</code>.</div>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num">2</div>
                    <div style="flex:1;">
                        <h4>Preencher o Formul&aacute;rio de Extra&ccedil;&atilde;o</h4>
                        <p>Na tab <strong>"Extrair Bloco"</strong>:</p>
                        <ul style="margin:8px 0 0;padding-left:18px;color:#646970;font-size:13px;line-height:1.8;">
                            <li>Cole a <strong>URL</strong> da p&aacute;gina alvo</li>
                            <li>Cole o <strong>Seletor CSS</strong> do bloco</li>
                            <li>Opcionalmente, d&ecirc; um <strong>nome</strong> ao bloco para o identificar facilmente</li>
                            <li>Opcionalmente, ajuste as <strong>Dimens&otilde;es</strong> (Largura Container, Sprite Largura e Altura)</li>
                        </ul>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num">3</div>
                    <div style="flex:1;">
                        <h4>Extrair e Pr&eacute;-visualizar</h4>
                        <p>Clique em <strong>"Extrair Bloco"</strong>. O plugin vai:</p>
                        <ul style="margin:8px 0 0;padding-left:18px;color:#646970;font-size:13px;line-height:1.8;">
                            <li>Aceder &agrave; p&aacute;gina e localizar o bloco</li>
                            <li>Descarregar todas as imagens para o servidor local</li>
                            <li>Extrair o HTML, CSS e JavaScript necess&aacute;rios</li>
                            <li>Auto-detetar dimens&otilde;es e cores (se aplic&aacute;vel)</li>
                        </ul>
                        <p style="margin-top:8px;">Verifique o <strong>Preview</strong> que aparece em baixo antes de guardar.</p>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#00a32a;">4</div>
                    <div style="flex:1;">
                        <h4>Guardar o Bloco</h4>
                        <p>Satisfeito com o preview? Clique em <strong>"Guardar Bloco"</strong>. O bloco fica dispon&iacute;vel na tab "Blocos Guardados" com um <strong>shortcode &uacute;nico</strong> que pode copiar e colar em qualquer p&aacute;gina.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- SECÇÃO 2: COMO CONFIGURAR UM BLOCO -->
        <div class="blkcloner-impl-section">
            <div class="blkcloner-impl-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
                <span class="blkcloner-impl-arrow">&#9654;</span>
                <span class="dashicons dashicons-admin-generic" style="color:#E32219;"></span>
                <h3>Como Configurar um Bloco</h3>
                <span class="blkcloner-impl-badge" style="background:#fce4ec;color:#E32219;">Passo 2</span>
            </div>
            <div class="blkcloner-impl-body">
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#E32219;">1</div>
                    <div style="flex:1;">
                        <h4>Abrir o Modal de Configura&ccedil;&atilde;o</h4>
                        <p>Na tab <strong>"Blocos Guardados"</strong>, clique no bot&atilde;o <span class="dashicons dashicons-admin-generic" style="font-size:14px;"></span> (engrenagem) ao lado do bloco que pretende configurar. Abre um modal com <strong>preview em tempo real</strong> &agrave; esquerda e os controlos de configura&ccedil;&atilde;o &agrave; direita.</p>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#E32219;">2</div>
                    <div style="flex:1;">
                        <h4>Ajustar Dimens&otilde;es</h4>
                        <p>Na sec&ccedil;&atilde;o <strong>"Dimens&otilde;es Gerais"</strong>, configure:</p>
                        <ul style="margin:8px 0 0;padding-left:18px;color:#646970;font-size:13px;line-height:1.8;">
                            <li><strong>Largura Container</strong> &mdash; aceita px, %, vw (ex: 1100px, 100%, 80vw)</li>
                            <li><strong>Tamanho Icons</strong> &mdash; dimens&atilde;o em pixels dos bot&otilde;es de cor</li>
                            <li><strong>Cor Ativa</strong> &mdash; cor da borda do icon selecionado</li>
                        </ul>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#E32219;">3</div>
                    <div style="flex:1;">
                        <h4>Posicionar os Selectores de Cor</h4>
                        <p>Escolha a posi&ccedil;&atilde;o dos bot&otilde;es de cor: <strong>Rodap&eacute;</strong>, <strong>Topo</strong>, <strong>Esquerda</strong> ou <strong>Direita</strong>. Use os sliders <strong>Offset X/Y</strong> ou os campos num&eacute;ricos para ajuste fino. O preview actualiza em tempo real.</p>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#E32219;">4</div>
                    <div style="flex:1;">
                        <h4>Gerir Cores e Icons</h4>
                        <p>Na sec&ccedil;&atilde;o <strong>"Cores do Bloco"</strong>:</p>
                        <ul style="margin:8px 0 0;padding-left:18px;color:#646970;font-size:13px;line-height:1.8;">
                            <li>O sistema auto-detecta as cores existentes no bloco</li>
                            <li>Selecione um <strong>slot de cor</strong> e clique numa imagem da galeria para a atribuir como icon</li>
                            <li>Altere o <strong>nome</strong> e a <strong>cor hex</strong> de cada variante</li>
                            <li>Use <strong>"Adicionar Cor"</strong> para criar novas variantes ou o bot&atilde;o apagar para remover</li>
                        </ul>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#E32219;">5</div>
                    <div style="flex:1;">
                        <h4>Adicionar Imagens &agrave; Galeria</h4>
                        <p>Na sec&ccedil;&atilde;o <strong>"Galeria de Imagens"</strong>, pode adicionar as suas pr&oacute;prias imagens:</p>
                        <ul style="margin:8px 0 0;padding-left:18px;color:#646970;font-size:13px;line-height:1.8;">
                            <li><strong>"Carregar Imagem"</strong> &mdash; enviar imagens do computador (jpg, png, webp, gif, svg)</li>
                            <li><strong>"Adicionar por URL"</strong> &mdash; colar o endere&ccedil;o de uma imagem externa (ser&aacute; descarregada localmente)</li>
                        </ul>
                        <p style="margin-top:8px;">As imagens adicionadas ficam guardadas permanentemente no bloco e podem ser usadas como icons de cor.</p>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#00a32a;">6</div>
                    <div style="flex:1;">
                        <h4>Guardar Configura&ccedil;&atilde;o</h4>
                        <p>Clique em <strong>"Guardar Configura&ccedil;&atilde;o"</strong>. Os bot&otilde;es de cor no HTML s&atilde;o automaticamente reescritos com as imagens e cores escolhidas. As altera&ccedil;&otilde;es ficam vis&iacute;veis no frontend.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- SECÇÃO 3: COMO PUBLICAR NO ELEMENTOR -->
        <div class="blkcloner-impl-section">
            <div class="blkcloner-impl-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
                <span class="blkcloner-impl-arrow">&#9654;</span>
                <span class="dashicons dashicons-welcome-widgets-menus" style="color:#9b59b6;"></span>
                <h3>Como Publicar no Elementor</h3>
                <span class="blkcloner-impl-badge" style="background:#f3e5f5;color:#9b59b6;">Passo 3</span>
            </div>
            <div class="blkcloner-impl-body">
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#9b59b6;">1</div>
                    <div style="flex:1;">
                        <h4>Copiar o Shortcode</h4>
                        <p>Na tab <strong>"Blocos Guardados"</strong>, clique no bot&atilde;o <span class="dashicons dashicons-clipboard" style="font-size:14px;"></span> <strong>"Copiar"</strong> ao lado do bloco. O shortcode fica na &aacute;rea de transfer&ecirc;ncia.</p>
                        <div class="blkcloner-code-example">[cloned_block id="blk_xxxxxxxx"]</div>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#9b59b6;">2</div>
                    <div style="flex:1;">
                        <h4>Abrir a P&aacute;gina no Elementor</h4>
                        <p>V&aacute; a <strong>P&aacute;ginas</strong> &rarr; escolha a p&aacute;gina desejada &rarr; <strong>"Editar com Elementor"</strong>.</p>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#9b59b6;">3</div>
                    <div style="flex:1;">
                        <h4>Adicionar o Widget Shortcode</h4>
                        <p>No painel lateral do Elementor, pesquise por <code>shortcode</code>. Arraste o widget <strong>"Shortcode"</strong> para o local desejado na p&aacute;gina.</p>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px;">
                            <div style="background:#f0f6fc;border:2px solid #2271b1;border-radius:6px;padding:10px;text-align:center;font-size:13px;">
                                <strong style="color:#2271b1;">Widget Shortcode</strong><br>
                                <span style="background:#00a32a;color:#fff;padding:1px 6px;border-radius:8px;font-size:10px;">RECOMENDADO</span>
                            </div>
                            <div style="background:#f9f9f9;border:1px solid #ddd;border-radius:6px;padding:10px;text-align:center;font-size:13px;">
                                <strong style="color:#646970;">Widget HTML</strong><br>
                                <span style="background:#72aee6;color:#fff;padding:1px 6px;border-radius:8px;font-size:10px;">ALTERNATIVA</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blkcloner-impl-step">
                    <div class="blkcloner-impl-num" style="background:#9b59b6;">4</div>
                    <div style="flex:1;">
                        <h4>Colar e Publicar</h4>
                        <p>Cole o shortcode no campo do widget e clique <strong>"Atualizar"</strong> para publicar.</p>
                    </div>
                </div>
                <div class="blkcloner-impl-note">
                    <h5>Nota Importante</h5>
                    <ul>
                        <li>O preview dentro do editor Elementor pode n&atilde;o mostrar o bloco &mdash; verifique sempre no <strong>frontend</strong> (bot&atilde;o "Pr&eacute;-visualizar")</li>
                        <li>Pode utilizar <strong>v&aacute;rios shortcodes</strong> na mesma p&aacute;gina sem conflitos</li>
                        <li>Todos os blocos s&atilde;o <strong>responsivos</strong> e adaptam-se automaticamente &agrave; largura da coluna</li>
                        <li>Os estilos s&atilde;o <strong>isolados</strong> com CSS scoped &mdash; n&atilde;o afetam o resto da p&aacute;gina</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- SECÇÃO 4: SHORTCODES DISPONÍVEIS -->
        <div class="blkcloner-impl-section">
            <div class="blkcloner-impl-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
                <span class="blkcloner-impl-arrow">&#9654;</span>
                <span class="dashicons dashicons-shortcode" style="color:#00a32a;"></span>
                <h3>Refer&ecirc;ncia de Shortcodes</h3>
                <span class="blkcloner-impl-badge" style="background:#e8f5e9;color:#00a32a;">Refer&ecirc;ncia</span>
            </div>
            <div class="blkcloner-impl-body">
                <div style="margin-bottom:20px;">
                    <h4 style="margin:0 0 8px;">[cloned_block] &mdash; Shortcode Principal</h4>
                    <p style="color:#646970;font-size:13px;margin:0 0 8px;">Renderiza qualquer bloco guardado na p&aacute;gina.</p>
                    <div class="blkcloner-code-example">[cloned_block id="blk_xxxxxxxx"]</div>
                    <div style="margin-top:12px;">
                        <table style="width:100%;border-collapse:collapse;font-size:13px;">
                            <thead>
                                <tr style="background:#f9f9f9;"><th style="text-align:left;padding:8px;border:1px solid #e0e0e0;">Par&acirc;metro</th><th style="text-align:left;padding:8px;border:1px solid #e0e0e0;">Padr&atilde;o</th><th style="text-align:left;padding:8px;border:1px solid #e0e0e0;">Descri&ccedil;&atilde;o</th></tr>
                            </thead>
                            <tbody>
                                <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;"><code>id</code></td><td style="padding:6px 8px;border:1px solid #e0e0e0;">&mdash;</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">ID do bloco guardado (obrigat&oacute;rio)</td></tr>
                                <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;"><code>max_width</code></td><td style="padding:6px 8px;border:1px solid #e0e0e0;">100%</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Largura m&aacute;xima do container</td></tr>
                                <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;"><code>align</code></td><td style="padding:6px 8px;border:1px solid #e0e0e0;">center</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Alinhamento: center, left, right</td></tr>
                                <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;"><code>responsive</code></td><td style="padding:6px 8px;border:1px solid #e0e0e0;">yes</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">CSS responsivo autom&aacute;tico (yes/no)</td></tr>
                                <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;"><code>lazy</code></td><td style="padding:6px 8px;border:1px solid #e0e0e0;">yes</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Lazy loading de imagens (yes/no)</td></tr>
                                <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;"><code>background</code></td><td style="padding:6px 8px;border:1px solid #e0e0e0;">transparent</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Cor de fundo do wrapper</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="blkcloner-code-example">[cloned_block id="blk_abc123" max_width="900px" align="left" background="#f5f5f5"]</div>
                </div>

                <div style="margin-bottom:20px;padding-top:20px;border-top:1px solid #e0e0e0;">
                    <h4 style="margin:0 0 8px;">[ducati_360] &mdash; Viewer 360&deg; Dedicado</h4>
                    <p style="color:#646970;font-size:13px;margin:0 0 8px;">Shortcode dedicado ao viewer 360&deg; com configura&ccedil;&atilde;o de cores e demo integrado.</p>
                    <div class="blkcloner-code-example">[ducati_360]<br>[ducati_360 block_id="blk_xxxxxxxx"]</div>
                </div>

                <div style="padding-top:20px;border-top:1px solid #e0e0e0;">
                    <h4 style="margin:0 0 8px;">[ducati_specs_bar] / [ducati_features] / [ducati_hero]</h4>
                    <p style="color:#646970;font-size:13px;margin:0;">Shortcodes auxiliares para p&aacute;ginas de produto: barra de especifica&ccedil;&otilde;es, cards de features e hero banner.</p>
                    <div class="blkcloner-code-example">[ducati_specs_bar potencia="170" cilindrada="1158" peso="215" deposito="22"]<br>[ducati_features titulo="Tecnologia" items="ABS Cornering,Riding Modes,Quick Shift"]<br>[ducati_hero titulo="Monster" subtitulo="The icon" bg="url-imagem"]</div>
                </div>
            </div>
        </div>

        <!-- SECÇÃO 5: GESTÃO DE BLOCOS -->
        <div class="blkcloner-impl-section">
            <div class="blkcloner-impl-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
                <span class="blkcloner-impl-arrow">&#9654;</span>
                <span class="dashicons dashicons-archive" style="color:#d63638;"></span>
                <h3>Gest&atilde;o e Manuten&ccedil;&atilde;o</h3>
                <span class="blkcloner-impl-badge" style="background:#fce4ec;color:#d63638;">Extras</span>
            </div>
            <div class="blkcloner-impl-body">
                <div style="margin-bottom:20px;">
                    <h4 style="margin:0 0 8px;">Gerir Blocos Guardados</h4>
                    <ul style="color:#646970;font-size:13px;padding-left:18px;line-height:1.8;">
                        <li><strong>Renomear</strong> &mdash; clique no &iacute;cone de l&aacute;pis ao lado do nome do bloco</li>
                        <li><strong>Duplicar</strong> &mdash; cria uma c&oacute;pia independente do bloco com novo ID</li>
                        <li><strong>Exportar Imagens</strong> &mdash; descarrega todas as imagens do bloco como ficheiro ZIP</li>
                        <li><strong>Exportar/Importar</strong> &mdash; fa&ccedil;a backup ou migre blocos entre sites via ficheiro JSON</li>
                    </ul>
                </div>

                <div style="margin-bottom:20px;padding-top:20px;border-top:1px solid #e0e0e0;">
                    <h4 style="margin:0 0 8px;">CSS Personalizado</h4>
                    <p style="color:#646970;font-size:13px;margin:0 0 8px;">Adicione CSS extra via Elementor (Avan&ccedil;ado &rarr; CSS personalizado) ou tema filho:</p>
                    <div class="blkcloner-code-example">#blkcloner-blk_xxxx .moto-container { max-width: 800px !important; }<br>#blkcloner-blk_xxxx .color-btn { width: 60px; height: 60px; }</div>
                </div>

                <div style="margin-bottom:20px;padding-top:20px;border-top:1px solid #e0e0e0;">
                    <h4 style="margin:0 0 8px;">Cache e Performance</h4>
                    <ul style="color:#646970;font-size:13px;padding-left:18px;line-height:1.8;">
                        <li>As imagens s&atilde;o guardadas em <code>wp-content/cache/block-cloner/</code></li>
                        <li>Use <strong>"Limpar Cache"</strong> na tab Ferramentas para limpar imagens em cache</li>
                        <li>O lazy loading est&aacute; ativo por defeito em todos os blocos (<code>lazy="yes"</code>)</li>
                        <li>Para sites com muitos blocos, considere usar um CDN para servir imagens</li>
                    </ul>
                </div>

                <div style="padding-top:20px;border-top:1px solid #e0e0e0;">
                    <h4 style="margin:0 0 8px;">Resolu&ccedil;&atilde;o de Problemas</h4>
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead>
                            <tr style="background:#f9f9f9;"><th style="text-align:left;padding:8px;border:1px solid #e0e0e0;">Problema</th><th style="text-align:left;padding:8px;border:1px solid #e0e0e0;">Solu&ccedil;&atilde;o</th></tr>
                        </thead>
                        <tbody>
                            <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;">Imagem 360&deg; n&atilde;o aparece</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Verifique se jQuery e SpriteSpin est&atilde;o a carregar. Limpe cache do browser e do plugin.</td></tr>
                            <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;">Bot&otilde;es de cor n&atilde;o vis&iacute;veis</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Abra a Configura&ccedil;&atilde;o e confirme que as imagens de icon est&atilde;o atribu&iacute;das aos slots.</td></tr>
                            <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;">Bloco n&atilde;o aparece no Elementor</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Normal &mdash; o bloco s&oacute; renderiza no frontend. Use o bot&atilde;o "Pr&eacute;-visualizar".</td></tr>
                            <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;">CSS afeta outros elementos</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">O CSS &eacute; isolado automaticamente desde a v1.7.0. Re-extraia blocos antigos se necess&aacute;rio.</td></tr>
                            <tr><td style="padding:6px 8px;border:1px solid #e0e0e0;">Imagens demoram a carregar</td><td style="padding:6px 8px;border:1px solid #e0e0e0;">Exporte as imagens como ZIP e configure CDN. O proxy de imagens pode ser lento com servidores externos.</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        </div><!-- /.blkcloner-main-tab implementacao -->

        <!-- TAB: SOBRE -->
        <div class="blkcloner-main-tab" data-main-tab="sobre">
        <div class="blkcloner-card" style="text-align:center;padding:40px;">
            <link href="https://fonts.googleapis.com/css2?family=Teko:wght@700&display=swap" rel="stylesheet" />
            <div style="margin-bottom:24px;">
                <div style="font-size:58px;font-weight:700;color:#E32219;letter-spacing:4px;text-transform:uppercase;font-family:'Teko','Arial Black',Impact,'Helvetica Neue',sans-serif;line-height:1;font-style:italic;transform:skewX(-6deg);display:inline-block;">NETSEG<span style="color:#1d2327;">.AI</span></div>
                <p style="color:#646970;font-size:16px;margin-top:8px;letter-spacing:1px;font-style:italic;">Soluções Inteligentes para a Web</p>
            </div>

            <div style="background:#f0f6fc;border-radius:12px;padding:30px;max-width:600px;margin:0 auto 24px;">
                <h2 style="margin:0 0 16px 0;color:#1d2327;">Ducati Block Cloner</h2>
                <table style="width:100%;text-align:left;font-size:14px;color:#646970;">
                    <tr><td style="padding:8px 12px;font-weight:600;color:#1d2327;width:40%;">Versão</td><td style="padding:8px 12px;"><?php echo BLKCLONER_VERSION; ?></td></tr>
                    <tr style="background:#e8f0fe;"><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Autor</td><td style="padding:8px 12px;">Eng.º Fernando Condeço</td></tr>
                    <tr><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Empresa</td><td style="padding:8px 12px;"><a href="https://netseg.ai" target="_blank" style="color:#2271b1;">Netseg.ai</a></td></tr>
                    <tr style="background:#e8f0fe;"><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Email</td><td style="padding:8px 12px;"><a href="mailto:info@netseg.ai" style="color:#2271b1;">info@netseg.ai</a></td></tr>
                    <tr><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Licença</td><td style="padding:8px 12px;">GPL v2 ou superior</td></tr>
                    <tr style="background:#e8f0fe;"><td style="padding:8px 12px;font-weight:600;color:#1d2327;">PHP</td><td style="padding:8px 12px;"><?php echo PHP_VERSION; ?></td></tr>
                    <tr><td style="padding:8px 12px;font-weight:600;color:#1d2327;">WordPress</td><td style="padding:8px 12px;"><?php echo get_bloginfo( 'version' ); ?></td></tr>
                    <tr style="background:#e8f0fe;"><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Blocos Guardados</td><td style="padding:8px 12px;"><?php echo count( $saved_blocks ); ?></td></tr>
                    <tr><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Versão DB</td><td style="padding:8px 12px;"><?php
                        $stored_ver = get_option( 'blkcloner_version', 'N/A' );
                        echo esc_html( $stored_ver );
                        if ( $stored_ver !== BLKCLONER_VERSION ) {
                            echo ' <span style="color:#d63638;font-weight:600;">&larr; desatualizada (ativa: ' . esc_html( BLKCLONER_VERSION ) . ')</span>';
                        } else {
                            echo ' <span style="color:#00a32a;">&#10003;</span>';
                        }
                    ?></td></tr>
                    <?php
                    // Detetar versão Code Snippets (conflito potencial)
                    $cs_conflict = false;
                    if ( function_exists( 'code_snippets' ) || defined( 'CODE_SNIPPETS_FILE' ) ) {
                        // Verificar se existem snippets ativos com funções do Block Cloner
                        global $wpdb;
                        $snippets_table = $wpdb->prefix . 'snippets';
                        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$snippets_table}'" ) === $snippets_table ) {
                            $active_conflicts = $wpdb->get_var(
                                "SELECT COUNT(*) FROM {$snippets_table} WHERE active = 1 AND ( code LIKE '%blkcloner_%' OR code LIKE '%block-cloner%' OR code LIKE '%cloned_block%' )"
                            );
                            if ( $active_conflicts > 0 ) {
                                $cs_conflict = true;
                            }
                        }
                    }
                    ?>
                    <tr style="background:#e8f0fe;"><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Code Snippets</td><td style="padding:8px 12px;"><?php
                        if ( $cs_conflict ) {
                            echo '<span style="color:#d63638;font-weight:600;">&#9888; Detetado! Existem snippets ativos com c&oacute;digo Block Cloner. Desative-os para evitar conflitos.</span>';
                        } elseif ( function_exists( 'code_snippets' ) || defined( 'CODE_SNIPPETS_FILE' ) ) {
                            echo '<span style="color:#dba617;">Code Snippets instalado (sem conflitos detetados)</span>';
                        } else {
                            echo '<span style="color:#00a32a;">Sem conflitos &#10003;</span>';
                        }
                    ?></td></tr>
                    <tr><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Elementor Pro</td><td style="padding:8px 12px;"><?php
                        if ( defined( 'ELEMENTOR_PRO_VERSION' ) ) {
                            echo 'v' . esc_html( ELEMENTOR_PRO_VERSION ) . ' <span style="color:#00a32a;">&#10003;</span>';
                        } elseif ( defined( 'ELEMENTOR_VERSION' ) ) {
                            echo 'Elementor Free v' . esc_html( ELEMENTOR_VERSION ) . ' <span style="color:#dba617;">(Pro recomendado)</span>';
                        } else {
                            echo '<span style="color:#d63638;">N&atilde;o instalado</span>';
                        }
                    ?></td></tr>
                    <tr style="background:#e8f0fe;"><td style="padding:8px 12px;font-weight:600;color:#1d2327;">Cache</td><td style="padding:8px 12px;"><?php
                        $cache_size = 0;
                        if ( is_dir( BLKCLONER_CACHE_DIR ) ) {
                            $files = glob( BLKCLONER_CACHE_DIR . '*' );
                            foreach ( $files as $f ) {
                                if ( is_file( $f ) ) $cache_size += filesize( $f );
                            }
                        }
                        echo number_format( $cache_size / 1024 / 1024, 2 ) . ' MB';
                    ?></td></tr>
                </table>
            </div>

            <div style="max-width:600px;margin:0 auto;">
                <h3 style="color:#1d2327;margin-bottom:12px;">Funcionalidades</h3>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;text-align:left;">
                    <div style="background:#f9f9f9;padding:16px;border-radius:8px;border:1px solid #e0e0e0;">
                        <strong style="color:#2271b1;">Rotação 360</strong>
                        <p style="color:#646970;font-size:12px;margin:4px 0 0;">Extrai e reconstrói viewers 360 com drag e auto-play.</p>
                    </div>
                    <div style="background:#f9f9f9;padding:16px;border-radius:8px;border:1px solid #e0e0e0;">
                        <strong style="color:#2271b1;">Seletor de Cores</strong>
                        <p style="color:#646970;font-size:12px;margin:4px 0 0;">Captura variantes de cor com thumbnails e nomes.</p>
                    </div>
                    <div style="background:#f9f9f9;padding:16px;border-radius:8px;border:1px solid #e0e0e0;">
                        <strong style="color:#2271b1;">Cache Inteligente</strong>
                        <p style="color:#646970;font-size:12px;margin:4px 0 0;">Imagens e HTML em cache local para performance.</p>
                    </div>
                    <div style="background:#f9f9f9;padding:16px;border-radius:8px;border:1px solid #e0e0e0;">
                        <strong style="color:#2271b1;">Widget Elementor</strong>
                        <p style="color:#646970;font-size:12px;margin:4px 0 0;">Widget nativo do Elementor Pro com seletor de blocos.</p>
                    </div>
                    <div style="background:#f9f9f9;padding:16px;border-radius:8px;border:1px solid #e0e0e0;">
                        <strong style="color:#00a32a;">Export/Import</strong>
                        <p style="color:#646970;font-size:12px;margin:4px 0 0;">Exportar e importar blocos como JSON entre sites.</p>
                    </div>
                    <div style="background:#f9f9f9;padding:16px;border-radius:8px;border:1px solid #e0e0e0;">
                        <strong style="color:#00a32a;">Gerir Blocos</strong>
                        <p style="color:#646970;font-size:12px;margin:4px 0 0;">Preview, renomear e duplicar blocos guardados.</p>
                    </div>
                </div>
            </div>

            <div style="margin-top:30px;padding-top:20px;border-top:1px solid #e0e0e0;">
                <p style="color:#646970;font-size:12px;">
                    &copy; <?php echo date( 'Y' ); ?> Netseg.ai - Eng.º Fernando Condeço - Todos os direitos reservados.<br>
                    <a href="https://netseg.ai" target="_blank" style="color:#2271b1;">netseg.ai</a> &middot;
                    <a href="mailto:info@netseg.ai" style="color:#2271b1;">info@netseg.ai</a>
                </p>
            </div>
        </div>
        </div><!-- /.blkcloner-main-tab sobre -->

        <!-- =============================================
             TAB: LICENÇA
             ============================================= -->
        <div class="blkcloner-main-tab" data-main-tab="licenca">
        <div class="blkcloner-card" style="max-width:700px;">
            <?php
            $license = get_option( 'blkcloner_license', array() );
            $is_licensed = function_exists( 'blkcloner_is_licensed' ) ? blkcloner_is_licensed() : false;
            $license_key = $license['key'] ?? '';
            $activated_at = $license['activated_at'] ?? '';
            $expires_at = '';
            $days_left = 0;
            if ( $is_licensed && $activated_at ) {
                $expires_ts = strtotime( $activated_at ) + ( 365 * DAY_IN_SECONDS );
                $expires_at = date_i18n( 'd/m/Y', $expires_ts );
                $days_left = max( 0, ceil( ( $expires_ts - time() ) / DAY_IN_SECONDS ) );
            }
            ?>

            <?php if ( $is_licensed ) : ?>
                <div style="text-align:center;padding:20px;">
                    <div style="font-size:60px;margin-bottom:10px;">&#9989;</div>
                    <h2 style="color:#00a32a;margin:0 0 8px;">Licença Ativa</h2>
                    <p style="color:#646970;font-size:14px;margin:0 0 16px;">A marca d'água NETSEG.AI está removida.</p>
                    <div style="background:#f0f6fc;border-radius:8px;padding:16px;text-align:left;font-size:14px;">
                        <div style="margin-bottom:8px;"><strong>Chave:</strong> <code><?php echo esc_html( $license_key ); ?></code></div>
                        <div style="margin-bottom:8px;"><strong>Ativada em:</strong> <?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $activated_at ) ) ); ?></div>
                        <div style="margin-bottom:8px;"><strong>Expira em:</strong> <?php echo esc_html( $expires_at ); ?></div>
                        <div><strong>Dias restantes:</strong> <span style="color:<?php echo $days_left < 30 ? '#d63638' : '#00a32a'; ?>;font-weight:700;"><?php echo $days_left; ?></span></div>
                    </div>
                    <button type="button" id="blkcloner-deactivate-license" class="blkcloner-btn blkcloner-btn-danger" style="margin-top:16px;padding:10px 20px;">
                        Remover Licença
                    </button>
                </div>
            <?php else : ?>
                <div style="text-align:center;padding:20px;">
                    <div style="font-size:60px;margin-bottom:10px;">&#128274;</div>
                    <h2 style="color:#d63638;margin:0 0 8px;">Plugin Não Licenciado</h2>
                    <p style="color:#646970;font-size:14px;margin:0 0 24px;">
                        As imagens exibem marca d'água <strong>NETSEG.AI</strong>.<br>
                        Introduza a chave de ativação para remover a marca d'água por 365 dias.
                    </p>

                    <div style="max-width:500px;margin:0 auto;">
                        <div style="display:flex;gap:8px;">
                            <input type="text" id="blkcloner-license-key" placeholder="NETSEG-XXXXX-XXXXX-XXXXX-XXXX"
                                style="flex:1;padding:10px 14px;font-size:15px;font-family:monospace;text-transform:uppercase;letter-spacing:1px;border:2px solid #c3c4c7;border-radius:6px;" />
                            <button type="button" id="blkcloner-activate-license" class="blkcloner-btn blkcloner-btn-primary" style="padding:10px 20px;">
                                Ativar
                            </button>
                        </div>
                        <p style="color:#646970;font-size:12px;margin-top:8px;">
                            Formato: NETSEG-XXXXX-XXXXX-XXXXX-XXXX
                        </p>
                    </div>

                    <div style="margin-top:24px;padding:16px;background:#f0f6fc;border-radius:8px;border:1px solid #c3c4c7;">
                        <p style="margin:0;color:#646970;font-size:13px;">
                            <strong>Obter licença:</strong> Contacte
                            <a href="mailto:info@netseg.ai?subject=Licença Block Cloner&body=Domínio: <?php echo esc_attr( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>" style="color:#2271b1;">info@netseg.ai</a>
                            para solicitar uma chave de ativação.
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        </div><!-- /.blkcloner-main-tab licenca -->

        <!-- TAB 360° VIEWER REMOVIDA na v1.6.5 — funcionalidade integrada no shortcode [cloned_block] -->


        <!-- =============================================
             TAB: DESINSTALAR
             ============================================= -->
        <div class="blkcloner-main-tab" data-main-tab="desinstalar">
        <div class="blkcloner-card" style="border-left:4px solid #d63638;">
            <h2 style="color:#d63638;margin-top:0;"><span class="dashicons dashicons-warning" style="font-size:24px;margin-right:8px;"></span>Desinstalar Plugin</h2>
            <p style="color:#646970;font-size:14px;">
                Utilize estas opções para limpar dados antes de desinstalar o plugin, ou para fazer uma reinstalação limpa.
            </p>

            <div style="display:grid;gap:20px;max-width:700px;margin-top:24px;">

                <!-- Opção 1: Apagar todos os blocos -->
                <div style="background:#fcf0f1;border:1px solid #d63638;border-radius:8px;padding:20px;">
                    <h3 style="margin:0 0 8px;color:#8a2424;"><span class="dashicons dashicons-database-remove" style="margin-right:6px;"></span>Apagar Todos os Blocos Guardados</h3>
                    <p style="color:#646970;font-size:13px;margin:0 0 12px;">
                        Remove todos os blocos guardados da base de dados. Os shortcodes nas páginas deixarão de funcionar.
                        <br><strong>Blocos atualmente guardados: <?php echo count( $saved_blocks ); ?></strong>
                    </p>
                    <button type="button" id="blkcloner-delete-all-blocks" class="blkcloner-btn blkcloner-btn-danger" style="padding:10px 20px;">
                        <span class="dashicons dashicons-trash" style="margin-right:4px;"></span> Apagar Todos os Blocos
                    </button>
                </div>

                <!-- Opção 2: Limpar cache -->
                <div style="background:#fff8e5;border:1px solid #dba617;border-radius:8px;padding:20px;">
                    <h3 style="margin:0 0 8px;color:#6e4e00;"><span class="dashicons dashicons-media-archive" style="margin-right:6px;"></span>Limpar Cache de Imagens e Páginas</h3>
                    <p style="color:#646970;font-size:13px;margin:0 0 12px;">
                        Remove todas as imagens em cache e dados temporários. O plugin recriará a cache automaticamente quando necessário.
                        <br><strong>Tamanho da cache: <?php
                            $cache_size_uninstall = 0;
                            if ( is_dir( BLKCLONER_CACHE_DIR ) ) {
                                $files = glob( BLKCLONER_CACHE_DIR . '*' );
                                foreach ( $files as $f ) {
                                    if ( is_file( $f ) ) $cache_size_uninstall += filesize( $f );
                                }
                            }
                            echo number_format( $cache_size_uninstall / 1024 / 1024, 2 ) . ' MB';
                        ?></strong>
                    </p>
                    <button type="button" id="blkcloner-delete-cache-full" class="blkcloner-btn" style="padding:10px 20px;background:#dba617;border-color:#dba617;color:#fff;">
                        <span class="dashicons dashicons-trash" style="margin-right:4px;"></span> Limpar Toda a Cache
                    </button>
                </div>

                <!-- Opção 3: Limpeza total + desinstalar -->
                <div style="background:#f9f9f9;border:2px solid #d63638;border-radius:8px;padding:20px;">
                    <h3 style="margin:0 0 8px;color:#d63638;"><span class="dashicons dashicons-dismiss" style="margin-right:6px;"></span>Limpeza Total e Desinstalar</h3>
                    <p style="color:#646970;font-size:13px;margin:0 0 12px;">
                        Apaga <strong>todos os blocos</strong>, <strong>toda a cache</strong>, <strong>transients</strong> e <strong>opções da base de dados</strong>.
                        Depois pode desativar e apagar o plugin em segurança.
                    </p>
                    <div style="background:#fff;border:1px solid #e0e0e0;border-radius:6px;padding:12px;margin-bottom:12px;">
                        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;color:#1d2327;font-size:13px;">
                            <input type="checkbox" id="blkcloner-confirm-uninstall" />
                            Confirmo que quero apagar <strong>todos os dados</strong> do Ducati Block Cloner
                        </label>
                    </div>
                    <button type="button" id="blkcloner-full-uninstall" class="blkcloner-btn blkcloner-btn-danger" style="padding:12px 24px;font-size:14px;" disabled>
                        <span class="dashicons dashicons-dismiss" style="margin-right:4px;"></span> Limpeza Total
                    </button>
                </div>

            </div>

            <div style="margin-top:24px;padding:16px;background:#f0f6fc;border-radius:8px;border:1px solid #c3c4c7;">
                <p style="margin:0;color:#646970;font-size:13px;">
                    <span class="dashicons dashicons-info" style="color:#2271b1;margin-right:4px;"></span>
                    <strong>Nota:</strong> Após a limpeza total, pode desativar o plugin em
                    <a href="<?php echo admin_url( 'plugins.php' ); ?>">Plugins &raquo; Plugins Instalados</a>
                    e depois apagá-lo.
                </p>
            </div>
        </div>
        </div><!-- /.blkcloner-main-tab desinstalar -->

    </div><!-- /.wrap -->

    <!-- Toast container -->
    <div class="blkcloner-toast-container" id="blkcloner-toasts"></div>

    <script>
    (function($) {
        'use strict';

        console.log('[BlockCloner] Admin JS v1.5.1 carregado.');

        if (typeof $ === 'undefined' || typeof ajaxurl === 'undefined') {
            console.error('[BlockCloner] ERRO: jQuery ou ajaxurl não disponível!');
            return;
        }

        var currentData = null;
        var nonce = '<?php echo esc_js( $nonce ); ?>';
        var exportImagesBaseUrl = '<?php echo esc_url( admin_url( "admin-post.php?action=blkcloner_export_images" ) ); ?>&_wpnonce=<?php echo wp_create_nonce( "blkcloner_export_images" ); ?>';
        var blkLang = '<?php echo esc_js( $blkcloner_lang ); ?>';

        // =============================================
        // SISTEMA DE TRADUÇÕES (i18n)
        // =============================================
        var blkI18n = {
            pt: {
                extract_block: 'Extrair Bloco', saved_blocks: 'Blocos Guardados', implementation: 'Implementação',
                about: 'Sobre', uninstall: 'Desinstalar', page_url: 'URL da Página',
                url_placeholder: 'Cole a URL completa da página que contém o bloco que quer clonar.',
                css_selector: 'Seletor CSS do Bloco', selector_help: 'Use o Inspetor do browser (F12) para encontrar o seletor.',
                block_name: 'Nome do Bloco (opcional)', block_name_placeholder: 'Coloque aqui o nome do bloco...',
                extract: 'Extrair Bloco', save: 'Guardar Bloco', extracting: 'A extrair...',
                extract_status: 'A aceder à página e extrair o bloco (pode demorar 15-30s)...',
                extract_success: 'Bloco extraído com sucesso!', saving: 'A guardar...',
                preview: 'Preview', images: 'Imagens', images_found: 'Imagens Encontradas',
                images_cached: 'Imagens em Cache', css_rules: 'Regras CSS', html_size: 'Tamanho HTML',
                copy_shortcode: 'Shortcode copiado!', delete_confirm: 'Tem certeza que deseja eliminar este bloco?',
                delete_all_title: 'Apagar Todos os Blocos Guardados',
                delete_all_desc: 'Remove todos os blocos guardados da base de dados.',
                clear_cache_title: 'Limpar Cache de Imagens e Páginas',
                clear_cache_desc: 'Remove todas as imagens em cache e dados temporários.',
                full_uninstall_title: 'Limpeza Total e Desinstalar',
                full_uninstall_desc: 'Apaga todos os blocos, toda a cache, transients e opções da base de dados.',
                confirm_uninstall: 'Confirmo que quero apagar todos os dados do Ducati Block Cloner',
                full_cleanup: 'Limpeza Total', cleaning: 'A limpar tudo...',
                blocks_saved: 'Blocos atualmente guardados:', cache_size: 'Tamanho da cache:',
                note_after_uninstall: 'Após a limpeza total, pode apagar o plugin em',
                rotation_colors: 'Rotação 360 + Cores', close: 'Fechar',
                select_block: 'Selecionar bloco...', renamed: 'Bloco renomeado.',
                duplicated: 'Bloco duplicado!', deleted: 'Bloco eliminado.',
                export: 'Exportar', import: 'Importar Blocos',
                lang_changed: 'Idioma alterado. A recarregar...'
            },
            en: {
                extract_block: 'Extract Block', saved_blocks: 'Saved Blocks', implementation: 'Implementation',
                about: 'About', uninstall: 'Uninstall', page_url: 'Page URL',
                url_placeholder: 'Paste the full URL of the page containing the block you want to clone.',
                css_selector: 'Block CSS Selector', selector_help: 'Use browser Inspector (F12) to find the selector.',
                block_name: 'Block Name (optional)', block_name_placeholder: 'Enter block name here...',
                extract: 'Extract Block', save: 'Save Block', extracting: 'Extracting...',
                extract_status: 'Accessing the page and extracting the block (may take 15-30s)...',
                extract_success: 'Block extracted successfully!', saving: 'Saving...',
                preview: 'Preview', images: 'Images', images_found: 'Images Found',
                images_cached: 'Cached Images', css_rules: 'CSS Rules', html_size: 'HTML Size',
                copy_shortcode: 'Shortcode copied!', delete_confirm: 'Are you sure you want to delete this block?',
                delete_all_title: 'Delete All Saved Blocks',
                delete_all_desc: 'Remove all saved blocks from the database.',
                clear_cache_title: 'Clear Image and Page Cache',
                clear_cache_desc: 'Remove all cached images and temporary data.',
                full_uninstall_title: 'Full Cleanup and Uninstall',
                full_uninstall_desc: 'Deletes all blocks, cache, transients and database options.',
                confirm_uninstall: 'I confirm I want to delete all Ducati Block Cloner data',
                full_cleanup: 'Full Cleanup', cleaning: 'Cleaning everything...',
                blocks_saved: 'Currently saved blocks:', cache_size: 'Cache size:',
                note_after_uninstall: 'After full cleanup, you can delete the plugin in',
                rotation_colors: 'Rotation 360 + Colors', close: 'Close',
                select_block: 'Select block...', renamed: 'Block renamed.',
                duplicated: 'Block duplicated!', deleted: 'Block deleted.',
                export: 'Export', import: 'Import Blocks',
                lang_changed: 'Language changed. Reloading...'
            },
            es: {
                extract_block: 'Extraer Bloque', saved_blocks: 'Bloques Guardados', implementation: 'Implementación',
                about: 'Acerca de', uninstall: 'Desinstalar', page_url: 'URL de la Página',
                url_placeholder: 'Pegue la URL completa de la página que contiene el bloque que desea clonar.',
                css_selector: 'Selector CSS del Bloque', selector_help: 'Use el Inspector del navegador (F12) para encontrar el selector.',
                block_name: 'Nombre del Bloque (opcional)', block_name_placeholder: 'Coloque aquí el nombre del bloque...',
                extract: 'Extraer Bloque', save: 'Guardar Bloque', extracting: 'Extrayendo...',
                extract_status: 'Accediendo a la página y extrayendo el bloque (puede tardar 15-30s)...',
                extract_success: '¡Bloque extraído con éxito!', saving: 'Guardando...',
                preview: 'Preview', images: 'Imágenes', images_found: 'Imágenes Encontradas',
                images_cached: 'Imágenes en Caché', css_rules: 'Reglas CSS', html_size: 'Tamaño HTML',
                copy_shortcode: '¡Shortcode copiado!', delete_confirm: '¿Está seguro de que desea eliminar este bloque?',
                delete_all_title: 'Eliminar Todos los Bloques',
                delete_all_desc: 'Elimina todos los bloques guardados de la base de datos.',
                clear_cache_title: 'Limpiar Caché de Imágenes',
                clear_cache_desc: 'Elimina todas las imágenes en caché y datos temporales.',
                full_uninstall_title: 'Limpieza Total y Desinstalar',
                full_uninstall_desc: 'Elimina todos los bloques, caché, transients y opciones de la base de datos.',
                confirm_uninstall: 'Confirmo que quiero eliminar todos los datos del Ducati Block Cloner',
                full_cleanup: 'Limpieza Total', cleaning: 'Limpiando todo...',
                blocks_saved: 'Bloques guardados actualmente:', cache_size: 'Tamaño de caché:',
                note_after_uninstall: 'Después de la limpieza total, puede eliminar el plugin en',
                rotation_colors: 'Rotación 360 + Colores', close: 'Cerrar',
                select_block: 'Seleccionar bloque...', renamed: 'Bloque renombrado.',
                duplicated: '¡Bloque duplicado!', deleted: 'Bloque eliminado.',
                export: 'Exportar', import: 'Importar Bloques',
                lang_changed: 'Idioma cambiado. Recargando...'
            },
            fr: {
                extract_block: 'Extraire Bloc', saved_blocks: 'Blocs Enregistrés', implementation: 'Implémentation',
                about: 'À propos', uninstall: 'Désinstaller', page_url: 'URL de la Page',
                url_placeholder: 'Collez l\'URL complète de la page contenant le bloc à cloner.',
                css_selector: 'Sélecteur CSS du Bloc', selector_help: 'Utilisez l\'Inspecteur du navigateur (F12) pour trouver le sélecteur.',
                block_name: 'Nom du Bloc (optionnel)', block_name_placeholder: 'Entrez le nom du bloc ici...',
                extract: 'Extraire Bloc', save: 'Enregistrer Bloc', extracting: 'Extraction...',
                extract_status: 'Accès à la page et extraction du bloc (peut prendre 15-30s)...',
                extract_success: 'Bloc extrait avec succès!', saving: 'Enregistrement...',
                preview: 'Aperçu', images: 'Images', images_found: 'Images Trouvées',
                images_cached: 'Images en Cache', css_rules: 'Règles CSS', html_size: 'Taille HTML',
                copy_shortcode: 'Shortcode copié!', delete_confirm: 'Êtes-vous sûr de vouloir supprimer ce bloc?',
                delete_all_title: 'Supprimer Tous les Blocs',
                delete_all_desc: 'Supprime tous les blocs enregistrés de la base de données.',
                clear_cache_title: 'Vider le Cache d\'Images',
                clear_cache_desc: 'Supprime toutes les images en cache et les données temporaires.',
                full_uninstall_title: 'Nettoyage Total et Désinstaller',
                full_uninstall_desc: 'Supprime tous les blocs, le cache, les transients et les options de la base de données.',
                confirm_uninstall: 'Je confirme vouloir supprimer toutes les données du Ducati Block Cloner',
                full_cleanup: 'Nettoyage Total', cleaning: 'Nettoyage en cours...',
                blocks_saved: 'Blocs actuellement enregistrés:', cache_size: 'Taille du cache:',
                note_after_uninstall: 'Après le nettoyage total, vous pouvez supprimer le plugin dans',
                rotation_colors: 'Rotation 360 + Couleurs', close: 'Fermer',
                select_block: 'Sélectionner bloc...', renamed: 'Bloc renommé.',
                duplicated: 'Bloc dupliqué!', deleted: 'Bloc supprimé.',
                export: 'Exporter', import: 'Importer Blocs',
                lang_changed: 'Langue modifiée. Rechargement...'
            },
            de: {
                extract_block: 'Block Extrahieren', saved_blocks: 'Gespeicherte Blöcke', implementation: 'Implementierung',
                about: 'Über', uninstall: 'Deinstallieren', page_url: 'Seiten-URL',
                url_placeholder: 'Fügen Sie die vollständige URL der Seite ein, die den zu klonenden Block enthält.',
                css_selector: 'Block CSS-Selektor', selector_help: 'Verwenden Sie den Browser-Inspektor (F12) um den Selektor zu finden.',
                block_name: 'Blockname (optional)', block_name_placeholder: 'Blockname hier eingeben...',
                extract: 'Block Extrahieren', save: 'Block Speichern', extracting: 'Extrahiere...',
                extract_status: 'Zugriff auf die Seite und Extraktion des Blocks (kann 15-30s dauern)...',
                extract_success: 'Block erfolgreich extrahiert!', saving: 'Speichere...',
                preview: 'Vorschau', images: 'Bilder', images_found: 'Bilder Gefunden',
                images_cached: 'Bilder im Cache', css_rules: 'CSS-Regeln', html_size: 'HTML-Größe',
                copy_shortcode: 'Shortcode kopiert!', delete_confirm: 'Sind Sie sicher, dass Sie diesen Block löschen möchten?',
                delete_all_title: 'Alle Blöcke Löschen',
                delete_all_desc: 'Entfernt alle gespeicherten Blöcke aus der Datenbank.',
                clear_cache_title: 'Bild-Cache Leeren',
                clear_cache_desc: 'Entfernt alle zwischengespeicherten Bilder und temporären Daten.',
                full_uninstall_title: 'Vollständige Bereinigung und Deinstallation',
                full_uninstall_desc: 'Löscht alle Blöcke, Cache, Transients und Datenbankoptionen.',
                confirm_uninstall: 'Ich bestätige, dass ich alle Ducati Block Cloner Daten löschen möchte',
                full_cleanup: 'Vollständige Bereinigung', cleaning: 'Alles bereinigen...',
                blocks_saved: 'Aktuell gespeicherte Blöcke:', cache_size: 'Cache-Größe:',
                note_after_uninstall: 'Nach der vollständigen Bereinigung können Sie das Plugin löschen unter',
                rotation_colors: 'Rotation 360 + Farben', close: 'Schließen',
                select_block: 'Block auswählen...', renamed: 'Block umbenannt.',
                duplicated: 'Block dupliziert!', deleted: 'Block gelöscht.',
                export: 'Exportieren', import: 'Blöcke Importieren',
                lang_changed: 'Sprache geändert. Wird neu geladen...'
            },
            it: {
                extract_block: 'Estrai Blocco', saved_blocks: 'Blocchi Salvati', implementation: 'Implementazione',
                about: 'Info', uninstall: 'Disinstalla', page_url: 'URL della Pagina',
                url_placeholder: 'Incolla l\'URL completo della pagina contenente il blocco da clonare.',
                css_selector: 'Selettore CSS del Blocco', selector_help: 'Usa l\'Ispettore del browser (F12) per trovare il selettore.',
                block_name: 'Nome del Blocco (opzionale)', block_name_placeholder: 'Inserisci il nome del blocco...',
                extract: 'Estrai Blocco', save: 'Salva Blocco', extracting: 'Estrazione...',
                extract_status: 'Accesso alla pagina e estrazione del blocco (può richiedere 15-30s)...',
                extract_success: 'Blocco estratto con successo!', saving: 'Salvataggio...',
                preview: 'Anteprima', images: 'Immagini', images_found: 'Immagini Trovate',
                images_cached: 'Immagini in Cache', css_rules: 'Regole CSS', html_size: 'Dimensione HTML',
                copy_shortcode: 'Shortcode copiato!', delete_confirm: 'Sei sicuro di voler eliminare questo blocco?',
                delete_all_title: 'Elimina Tutti i Blocchi',
                delete_all_desc: 'Rimuove tutti i blocchi salvati dal database.',
                clear_cache_title: 'Svuota Cache Immagini',
                clear_cache_desc: 'Rimuove tutte le immagini in cache e i dati temporanei.',
                full_uninstall_title: 'Pulizia Totale e Disinstalla',
                full_uninstall_desc: 'Elimina tutti i blocchi, cache, transient e opzioni del database.',
                confirm_uninstall: 'Confermo di voler eliminare tutti i dati del Ducati Block Cloner',
                full_cleanup: 'Pulizia Totale', cleaning: 'Pulizia in corso...',
                blocks_saved: 'Blocchi attualmente salvati:', cache_size: 'Dimensione cache:',
                note_after_uninstall: 'Dopo la pulizia totale, puoi eliminare il plugin in',
                rotation_colors: 'Rotazione 360 + Colori', close: 'Chiudi',
                select_block: 'Seleziona blocco...', renamed: 'Blocco rinominato.',
                duplicated: 'Blocco duplicato!', deleted: 'Blocco eliminato.',
                export: 'Esporta', import: 'Importa Blocchi',
                lang_changed: 'Lingua cambiata. Ricaricamento...'
            }
        };

        function __(key) {
            return (blkI18n[blkLang] && blkI18n[blkLang][key]) || (blkI18n.pt[key]) || key;
        }

        // Aplicar traduções ao DOM na carga
        function applyTranslations() {
            // Tabs de navegação principal
            $('.nav-tab[data-main-tab="extrair"]').text(__('extract_block'));
            var blocksCount = $('.nav-tab[data-main-tab="blocos"] .count').prop('outerHTML') || '';
            $('.nav-tab[data-main-tab="blocos"]').html(__('saved_blocks') + ' ' + blocksCount);
            $('.nav-tab[data-main-tab="implementacao"]').text(__('implementation'));
            $('.nav-tab[data-main-tab="sobre"]').text(__('about'));
            $('.nav-tab[data-main-tab="desinstalar"]').text(__('uninstall'));

            // Tab Extrair
            $('label[for="blkcloner-url"]').text(__('page_url'));
            $('label[for="blkcloner-selector"]').text(__('css_selector'));
            $('label[for="blkcloner-name"]').text(__('block_name'));
            $('#blkcloner-name').attr('placeholder', __('block_name_placeholder'));
            $('.blkcloner-hint[data-selector=".d-model-preview"]').text(__('rotation_colors'));

            // Botões
            if (!$('#blkcloner-extract-btn').find('.blkcloner-spinner').length) {
                $('#blkcloner-extract-btn').html('<span class="dashicons dashicons-search"></span> ' + __('extract'));
            }
            if (!$('#blkcloner-save-btn').find('.blkcloner-spinner').length) {
                $('#blkcloner-save-btn').html('<span class="dashicons dashicons-saved"></span> ' + __('save'));
            }

            // Sub-tabs
            $('.blkcloner-tab[data-tab="preview"]').text(__('preview'));
            $('.blkcloner-tab[data-tab="images"]').text(__('images'));
        }

        // Aplicar traduções na carga
        applyTranslations();

        // Seletor de idioma (bandeiras)
        $(document).on('click', '.blkcloner-flag', function() {
            var lang = $(this).data('lang');
            if (lang === blkLang) return;

            $('.blkcloner-flag').css('opacity', '0.4').removeClass('active');
            $(this).css('opacity', '1').addClass('active');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_save_language', nonce: nonce, lang: lang },
                success: function(response) {
                    if (response.success) {
                        toast(__('lang_changed'), 'success');
                        setTimeout(function() { location.reload(); }, 800);
                    }
                }
            });
        });

        // =============================================
        // TOAST NOTIFICATIONS
        // =============================================
        function toast(message, type) {
            type = type || 'info';
            var icons = { success: '&#10003;', error: '&#10007;', info: '&#8505;' };
            var $t = $('<div class="blkcloner-toast blkcloner-toast-' + type + '">' + (icons[type] || '') + ' ' + message + '</div>');
            $('#blkcloner-toasts').append($t);
            setTimeout(function() {
                $t.css('animation', 'blkcloner-toast-out 0.3s ease-in forwards');
                setTimeout(function() { $t.remove(); }, 300);
            }, 3500);
        }

        // NAVEGAÇÃO PRINCIPAL POR ABAS
        $(document).on('click', '.nav-tab[data-main-tab]', function(e) {
            e.preventDefault();
            var tab = $(this).data('main-tab');
            $('.nav-tab[data-main-tab]').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            $('.blkcloner-main-tab').removeClass('active').hide();
            $('.blkcloner-main-tab[data-main-tab="' + tab + '"]').addClass('active').show();
        });

        // Restaurar tab ativa a partir do hash (ex: após guardar config)
        if (window.location.hash === '#blkcloner-tab-blocos') {
            $('.nav-tab[data-main-tab]').removeClass('nav-tab-active');
            $('.nav-tab[data-main-tab="blocos"]').addClass('nav-tab-active');
            $('.blkcloner-main-tab').removeClass('active').hide();
            $('.blkcloner-main-tab[data-main-tab="blocos"]').addClass('active').show();
            history.replaceState(null, null, window.location.pathname + window.location.search);
        }

        // Tabs
        $(document).on('click', '.blkcloner-tab', function() {
            var tab = $(this).data('tab');
            $('.blkcloner-tab').removeClass('active');
            $(this).addClass('active');
            $('.blkcloner-tab-content').removeClass('active');
            $('.blkcloner-tab-content[data-tab="' + tab + '"]').addClass('active');
        });

        // Selector hints
        $(document).on('click', '.blkcloner-hint', function() {
            $('#blkcloner-selector').val($(this).data('selector'));
        });

        // Post-extraction dimension sliders synchronization
        (function initPostDimSliders() {
            function syncSliderToInput(sliderId, inputId, valId, suffix) {
                $(document).on('input', '#' + sliderId, function() {
                    var v = $(this).val();
                    $('#' + inputId).val(suffix === 'px' ? v : v + suffix);
                    $('#' + valId).text(v + (suffix || 'px'));
                });
                $(document).on('change input', '#' + inputId, function() {
                    var v = parseInt($(this).val()) || 0;
                    $('#' + sliderId).val(Math.min(v, parseInt($('#' + sliderId).attr('max'))));
                    $('#' + valId).text($(this).val());
                });
            }
            syncSliderToInput('blkcloner-post-container-w-slider', 'blkcloner-post-container-w', 'blkcloner-post-container-w-val', 'px');
            syncSliderToInput('blkcloner-post-sprite-w-slider', 'blkcloner-post-sprite-w', 'blkcloner-post-sprite-w-val', 'px');
            syncSliderToInput('blkcloner-post-sprite-h-slider', 'blkcloner-post-sprite-h', 'blkcloner-post-sprite-h-val', 'px');
        })();

        // EXTRAIR
        $('#blkcloner-extract-btn').on('click', function() {
            var btn = $(this);
            var url = $('#blkcloner-url').val().trim();
            var selector = $('#blkcloner-selector').val().trim();

            if (!url || !selector) {
                alert('Preencha a URL e o seletor CSS.');
                return;
            }

            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A extrair...');
            $('#blkcloner-status').text('A aceder à página e extrair o bloco (pode demorar 15-30s)...').css('color', '#646970');
            $('#blkcloner-result').hide();

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'blkcloner_extract',
                    nonce: nonce,
                    url: url,
                    selector: selector,
                    force_refresh: 1
                },
                timeout: 90000,
                success: function(response) {
                    if (response.success) {
                        currentData = response.data;
                        showResult(response.data);
                        $('#blkcloner-save-btn').prop('disabled', false);
                        $('#blkcloner-status').text('Bloco extraído com sucesso!').css('color', '#00a32a');
                    } else {
                        var errorMsg = response.data || 'Erro desconhecido';
                        $('#blkcloner-status').html('<strong>Erro:</strong> ' + errorMsg).css('color', '#d63638');
                    }
                },
                error: function(xhr, status, error) {
                    var msg = 'Erro de comunicação';
                    if (status === 'timeout') msg = 'Timeout - a página demorou demasiado. Tente novamente ou use o Scanner Visual (Snippet 3).';
                    $('#blkcloner-status').html('<strong>' + msg + '</strong>').css('color', '#d63638');
                },
                complete: function() {
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> Extrair Bloco');
                }
            });
        });

        // =============================================
        // PREVIEW CLONER — showResult + modal
        // Carregado via do_action('blkcloner_preview_js')
        // =============================================
        <?php do_action( 'blkcloner_preview_js' ); ?>
        // --- FIM do Preview Cloner ---

        // GUARDAR
        $('#blkcloner-save-btn').on('click', function() {
            if (!currentData) return;

            var btn = $(this);
            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A guardar...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'blkcloner_save',
                    nonce: nonce,
                    block_id: currentData.block_id || '',
                    name: $('#blkcloner-name').val() || 'Bloco ' + new Date().toLocaleDateString('pt-PT'),
                    html: currentData.html,
                    css: currentData.css,
                    js: currentData.js,
                    images: JSON.stringify(currentData.images || []),
                    source_url: currentData.source_url,
                    container_width: $('#blkcloner-post-container-w').val() || '1100px',
                    sprite_width: $('#blkcloner-post-sprite-w').val() || '1920',
                    sprite_height: $('#blkcloner-post-sprite-h').val() || '1080'
                },
                success: function(response) {
                    if (response.success) {
                        var d = response.data;
                        toast('Bloco guardado! Shortcode: ' + d.shortcode, 'success');
                        setTimeout(function() { location.reload(); }, 1500);
                    } else {
                        toast('Erro: ' + response.data, 'error');
                    }
                },
                complete: function() {
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-saved"></span> Guardar Bloco');
                }
            });
        });

        // COPIAR SHORTCODE
        $(document).on('click', '.blkcloner-copy-shortcode', function() {
            var shortcode = $(this).data('shortcode');
            navigator.clipboard.writeText(shortcode).then(function() {
                toast(__('copy_shortcode'), 'success');
            }).catch(function() {
                prompt('Shortcode:', shortcode);
            });
        });

        // ELIMINAR BLOCO
        $(document).on('click', '.blkcloner-delete-block', function(e) {
            e.preventDefault();
            e.stopPropagation();

            var btn = $(this);
            // Usar attr() em vez de data() para evitar cache do jQuery
            var id = btn.attr('data-id') || btn.data('id') || '';

            if (!id) {
                // Fallback: obter do container pai
                id = btn.closest('.blkcloner-saved-item').attr('data-id') || '';
            }

            console.log('[BlockCloner] A apagar bloco:', id);

            if (!id) {
                alert('Error: Block ID not found.');
                return;
            }

            if (!confirm(__('delete_confirm') + '\nID: ' + id)) return;

            var item = btn.closest('.blkcloner-saved-item');
            btn.prop('disabled', true).text('A eliminar...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'blkcloner_delete',
                    nonce: nonce,
                    block_id: String(id)
                },
                success: function(response) {
                    if (response && response.success) {
                        item.slideUp(300, function() { $(this).remove(); });
                        toast(__('deleted'), 'success');
                    } else {
                        var msg = (response && response.data) ? response.data : 'Erro desconhecido';
                        toast('Erro ao eliminar: ' + msg, 'error');
                        btn.prop('disabled', false).html('<span class="dashicons dashicons-trash"></span>');
                    }
                },
                error: function(xhr, status, error) {
                    toast('Erro de rede ao eliminar bloco.', 'error');
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-trash"></span>');
                }
            });
        });

        // LIMPAR CACHE
        $('#blkcloner-clear-cache').on('click', function() {
            if (!confirm('Limpar toda a cache de páginas e imagens?')) return;

            var btn = $(this);
            btn.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'blkcloner_clear_cache',
                    nonce: nonce
                },
                success: function(response) {
                    toast(response.success ? response.data : 'Erro ao limpar cache', response.success ? 'success' : 'error');
                },
                complete: function() {
                    btn.prop('disabled', false);
                }
            });
        });

        // =============================================
        // RENOMEAR BLOCO
        // =============================================
        $(document).on('click', '.blkcloner-rename-block', function() {
            var btn = $(this);
            var id = btn.attr('data-id');
            var currentName = btn.attr('data-name');
            var item = btn.closest('.blkcloner-saved-item');
            var h4 = item.find('h4');

            // Substituir h4 por input inline
            var editHtml = '<div class="blkcloner-inline-edit">' +
                '<input type="text" value="' + $('<span>').text(currentName).html() + '" maxlength="100" style="width:200px;" />' +
                '<button class="blkcloner-btn-inline-save" style="background:#00a32a;color:#fff;">&#10003;</button>' +
                '<button class="blkcloner-btn-inline-cancel" style="background:#d63638;color:#fff;">&#10007;</button>' +
                '</div>';
            h4.hide().after(editHtml);
            item.find('.blkcloner-inline-edit input').focus().select();

            // Guardar
            item.find('.blkcloner-btn-inline-save').on('click', function() {
                var newName = item.find('.blkcloner-inline-edit input').val().trim();
                if (!newName) { toast('Nome não pode ser vazio.', 'error'); return; }

                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: { action: 'blkcloner_rename', nonce: nonce, block_id: id, new_name: newName },
                    success: function(response) {
                        if (response.success) {
                            h4.text(newName).show();
                            btn.attr('data-name', newName);
                            item.find('.blkcloner-inline-edit').remove();
                            toast(__('renamed'), 'success');
                        } else {
                            toast('Erro: ' + response.data, 'error');
                        }
                    },
                    error: function() { toast('Erro de rede.', 'error'); }
                });
            });

            // Cancelar
            item.find('.blkcloner-btn-inline-cancel').on('click', function() {
                h4.show();
                item.find('.blkcloner-inline-edit').remove();
            });

            // Enter/Escape
            item.find('.blkcloner-inline-edit input').on('keydown', function(e) {
                if (e.key === 'Enter') item.find('.blkcloner-btn-inline-save').click();
                if (e.key === 'Escape') item.find('.blkcloner-btn-inline-cancel').click();
            });
        });

        // =============================================
        // CONFIGURAR BLOCO (dimensões + icons de rodapé)
        // =============================================
        $(document).on('click', '.blkcloner-config-block', function() {
            var btn = $(this);
            var id = btn.attr('data-id');
            var name = btn.attr('data-name') || id;

            btn.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_get_config', nonce: nonce, block_id: id },
                success: function(response) {
                    if (!response.success) {
                        toast('Erro: ' + response.data, 'error');
                        return;
                    }
                    var d = response.data;
                    var cfg = d.config || {};
                    var images = d.images || [];
                    var numColors = d.detected_colors || 0;
                    var colorDetails = d.color_details || [];
                    if (numColors < 1) numColors = 1;

                    // Construir modal — layout com preview à esquerda e config à direita
                    var curPos = cfg.controls_position || 'bottom';
                    var curOffX = cfg.controls_offset_x || 0;
                    var curOffY = cfg.controls_offset_y || 0;

                    var modalHtml = '<div class="blkcloner-config-modal" id="blkcloner-config-modal">' +
                        '<div class="blkcloner-config-modal-content" style="max-width:1300px;">' +
                            '<div class="blkcloner-config-modal-header">' +
                                '<h3 style="margin:0;display:flex;align-items:center;gap:8px;">' +
                                    '<span class="dashicons dashicons-admin-generic" style="color:#2271b1;"></span> ' +
                                    'Configurar: ' + $('<span>').text(name).html() +
                                '</h3>' +
                                '<button class="blkcloner-preview-modal-close blkcloner-config-close" title="Fechar">&times;</button>' +
                            '</div>' +
                            '<div class="blkcloner-config-modal-body" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">' +

                                // COLUNA ESQUERDA: Live Preview
                                '<div style="min-height:400px;">' +
                                    '<h4 style="margin:0 0 10px;"><span class="dashicons dashicons-visibility" style="margin-right:6px;color:#2271b1;"></span>Preview em Tempo Real</h4>' +
                                    '<div id="cfg-live-preview" style="border:1px solid #ddd;border-radius:8px;overflow:hidden;background:#f9f9f9;min-height:350px;">' +
                                        '<iframe id="cfg-preview-iframe" style="width:100%;min-height:350px;border:none;display:block;" sandbox="allow-scripts allow-same-origin"></iframe>' +
                                    '</div>' +
                                '</div>' +

                                // COLUNA DIREITA: Configurações
                                '<div style="overflow-y:auto;max-height:70vh;">' +

                                    // SECÇÃO: Dimensões Gerais
                                    '<div class="blkcloner-config-section">' +
                                        '<h4><span class="dashicons dashicons-image-crop" style="margin-right:6px;color:#2271b1;"></span>Dimensões Gerais</h4>' +
                                        '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">' +
                                            '<div class="blkcloner-config-field">' +
                                                '<label>Largura Container</label>' +
                                                '<input type="text" id="cfg-container-width" value="' + (cfg.container_width || '1100px') + '" placeholder="1100px" />' +
                                            '</div>' +
                                            '<div class="blkcloner-config-field">' +
                                                '<label>Tamanho Icons (px)</label>' +
                                                '<input type="number" id="cfg-btn-size" value="' + (cfg.btn_size || 45) + '" min="20" max="120" />' +
                                            '</div>' +
                                            '<div class="blkcloner-config-field">' +
                                                '<label>Cor Ativa (borda)</label>' +
                                                '<input type="color" id="cfg-active-color" value="' + (cfg.active_color || '#E32219') + '" style="height:36px;padding:2px;" />' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>' +

                                    // SECÇÃO: Posição dos Selectores
                                    '<div class="blkcloner-config-section">' +
                                        '<h4><span class="dashicons dashicons-move" style="margin-right:6px;color:#9b59b6;"></span>Posição dos Selectores de Cor</h4>' +
                                        '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">' +
                                            '<div class="blkcloner-config-field">' +
                                                '<label>Posição</label>' +
                                                '<select id="cfg-controls-pos" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;">' +
                                                    '<option value="bottom"' + (curPos === 'bottom' ? ' selected' : '') + '>Rodapé (baixo)</option>' +
                                                    '<option value="top"' + (curPos === 'top' ? ' selected' : '') + '>Topo (cima)</option>' +
                                                    '<option value="left"' + (curPos === 'left' ? ' selected' : '') + '>Esquerda</option>' +
                                                    '<option value="right"' + (curPos === 'right' ? ' selected' : '') + '>Direita</option>' +
                                                '</select>' +
                                            '</div>' +
                                            '<div class="blkcloner-config-field">' +
                                                '<label>Offset X (px)</label>' +
                                                '<input type="range" id="cfg-offset-x" min="-200" max="200" value="' + curOffX + '" style="width:100%;" />' +
                                                '<input type="number" id="cfg-offset-x-input" min="-200" max="200" value="' + curOffX + '" style="width:100%;margin-top:4px;padding:4px 8px;border:1px solid #ddd;border-radius:4px;font-size:13px;text-align:center;" />' +
                                            '</div>' +
                                            '<div class="blkcloner-config-field">' +
                                                '<label>Offset Y (px)</label>' +
                                                '<input type="range" id="cfg-offset-y" min="-200" max="200" value="' + curOffY + '" style="width:100%;" />' +
                                                '<input type="number" id="cfg-offset-y-input" min="-200" max="200" value="' + curOffY + '" style="width:100%;margin-top:4px;padding:4px 8px;border:1px solid #ddd;border-radius:4px;font-size:13px;text-align:center;" />' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>' +

                                    // SECÇÃO: Cores Detetadas (Gestão)
                                    '<div class="blkcloner-config-section">' +
                                        '<h4><span class="dashicons dashicons-art" style="margin-right:6px;color:#E32219;"></span>Cores do Bloco' +
                                            '<span style="font-size:12px;font-weight:400;color:#646970;margin-left:8px;">' + numColors + ' cor(es) detetada(s)</span>' +
                                        '</h4>' +
                                        '<p style="color:#646970;font-size:13px;margin:0 0 12px;">Gerir as cores do seletor. Pode alterar o nome, a imagem de ícone, apagar ou adicionar novas cores.</p>' +
                                        '<div style="display:flex;gap:6px;margin-bottom:12px;">' +
                                            '<button type="button" class="blkcloner-btn blkcloner-btn-primary" id="cfg-add-icon-slot" style="font-size:12px;padding:4px 12px;">' +
                                                '<span class="dashicons dashicons-plus-alt2" style="font-size:16px;"></span> Adicionar Cor' +
                                            '</button>' +
                                        '</div>' +
                                        '<div id="cfg-icon-slots"></div>' +
                                    '</div>' +

                                    // SECÇÃO: Opções de Visualização
                                    '<div class="blkcloner-config-section">' +
                                        '<h4><span class="dashicons dashicons-visibility" style="margin-right:6px;color:#2271b1;"></span>Opções de Visualização</h4>' +
                                        '<div style="display:flex;flex-direction:column;gap:10px;">' +
                                            '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;">' +
                                                '<input type="checkbox" id="cfg-show-single-color" ' + (cfg.show_single_color !== false ? 'checked' : '') + ' />' +
                                                '<span>Mostrar seletor de cor mesmo com apenas 1 cor detetada</span>' +
                                            '</label>' +
                                        '</div>' +
                                    '</div>' +

                                    // SECÇÃO: Gestão de Imagens do Bloco (remoção)
                                    '<div class="blkcloner-config-section">' +
                                        '<h4><span class="dashicons dashicons-trash" style="margin-right:6px;color:#d63638;"></span>Remover Imagens do Bloco' +
                                            '<span style="font-size:12px;font-weight:400;color:#646970;margin-left:8px;" id="cfg-total-images-count">' + images.length + ' imagens no total</span>' +
                                        '</h4>' +
                                        '<p style="color:#646970;font-size:13px;margin:0 0 8px;">Selecione imagens desnecessárias para as apagar do bloco e do 360°.</p>' +
                                        '<div style="margin-bottom:8px;display:flex;gap:8px;align-items:center;">' +
                                            '<button type="button" class="blkcloner-btn blkcloner-btn-secondary" id="cfg-select-all-rm" style="font-size:12px;padding:4px 10px;">☐ Selecionar Todas</button>' +
                                            '<button type="button" class="blkcloner-btn" id="cfg-remove-selected-rm" style="font-size:12px;padding:4px 10px;background:#d63638;color:#fff;display:none;">🗑 Remover Selecionadas</button>' +
                                            '<span id="cfg-rm-sel-count" style="font-size:12px;color:#646970;"></span>' +
                                        '</div>' +
                                        '<div class="blkcloner-icon-grid" id="cfg-removable-images"></div>' +
                                    '</div>' +

                                    // SECÇÃO: Galeria de Imagens do Bloco
                                    '<div class="blkcloner-config-section">' +
                                        '<h4><span class="dashicons dashicons-format-gallery" style="margin-right:6px;color:#00a32a;"></span>Galeria de Imagens do Bloco' +
                                            '<span style="font-size:12px;font-weight:400;color:#646970;margin-left:8px;" id="cfg-gallery-count">' + images.length + ' imagens</span>' +
                                        '</h4>' +
                                        '<p style="color:#646970;font-size:13px;margin:0 0 8px;">Clique numa imagem para a selecionar como icon do slot ativo (realçado a verde).</p>' +
                                        // Botões para adicionar imagens
                                        '<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;align-items:center;">' +
                                            '<button type="button" class="blkcloner-btn blkcloner-btn-secondary" id="cfg-add-image-file" style="font-size:12px;padding:4px 12px;">' +
                                                '<span class="dashicons dashicons-upload" style="font-size:16px;"></span> Carregar Imagem' +
                                            '</button>' +
                                            '<button type="button" class="blkcloner-btn blkcloner-btn-secondary" id="cfg-add-image-url-toggle" style="font-size:12px;padding:4px 12px;">' +
                                                '<span class="dashicons dashicons-admin-links" style="font-size:16px;"></span> Adicionar por URL' +
                                            '</button>' +
                                            '<input type="file" id="cfg-image-file-input" accept="image/*" multiple style="display:none;" />' +
                                        '</div>' +
                                        // Campo URL (oculto por defeito)
                                        '<div id="cfg-url-input-area" style="display:none;margin-bottom:12px;">' +
                                            '<div style="display:flex;gap:8px;">' +
                                                '<input type="url" id="cfg-image-url-input" placeholder="https://exemplo.com/imagem.jpg" style="flex:1;padding:6px 10px;border:1px solid #ddd;border-radius:4px;font-size:13px;" />' +
                                                '<button type="button" class="blkcloner-btn blkcloner-btn-primary" id="cfg-add-image-url-btn" style="font-size:12px;padding:4px 12px;">Adicionar</button>' +
                                            '</div>' +
                                            '<p style="color:#646970;font-size:11px;margin:4px 0 0;">Cole a URL completa de uma imagem (jpg, png, webp, gif, svg).</p>' +
                                        '</div>' +
                                        '<div id="cfg-image-upload-status" style="display:none;margin-bottom:8px;padding:8px 12px;border-radius:4px;font-size:13px;"></div>' +
                                        '<div class="blkcloner-icon-grid" id="cfg-image-gallery"></div>' +
                                    '</div>' +

                                    // Botões
                                    '<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:16px;border-top:1px solid #eee;">' +
                                        '<button type="button" class="blkcloner-btn blkcloner-btn-secondary blkcloner-config-close">Cancelar</button>' +
                                        '<button type="button" class="blkcloner-btn blkcloner-btn-primary" id="cfg-save-btn">' +
                                            '<span class="dashicons dashicons-saved"></span> Guardar Configuração' +
                                        '</button>' +
                                    '</div>' +

                                '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>';

                    var modal = $(modalHtml);
                    $('body').append(modal);

                    // ---- LIVE PREVIEW ----
                    var blockHtml = d.html || '';
                    var blockCss = d.css || '';
                    var blockJs = d.js || '';

                    function refreshLivePreview() {
                        var previewIframe = document.getElementById('cfg-preview-iframe');
                        if (!previewIframe) return;
                        var iframeContent = buildFullPreviewIframe(blockHtml, blockCss, blockJs);
                        var iframeDoc = previewIframe.contentDocument || previewIframe.contentWindow.document;
                        iframeDoc.open();
                        iframeDoc.write(iframeContent);
                        iframeDoc.close();
                        previewIframe.onload = function() { autoResizeIframe(previewIframe); };
                    }
                    refreshLivePreview();

                    // Posição dos selectores: ao mudar, atualizar preview e injetar CSS
                    function updatePreviewPositioning() {
                        var pos = $('#cfg-controls-pos').val();
                        var offX = parseInt($('#cfg-offset-x').val()) || 0;
                        var offY = parseInt($('#cfg-offset-y').val()) || 0;
                        $('#cfg-offset-x-input').val(offX);
                        $('#cfg-offset-y-input').val(offY);

                        var previewIframe = document.getElementById('cfg-preview-iframe');
                        if (!previewIframe || !previewIframe.contentDocument) return;
                        var iframeDoc = previewIframe.contentDocument;

                        // Remover CSS anterior de posicionamento
                        var oldStyle = iframeDoc.getElementById('cfg-pos-style');
                        if (oldStyle) oldStyle.remove();

                        var css = '';
                        if (pos === 'top') {
                            css = '.ducati-controls-area { order: -1; margin-bottom: -20px; margin-top: 0; }';
                        } else if (pos === 'left') {
                            css = '.ducati-lisboa-360-wrapper { position: relative; }' +
                                  '.ducati-controls-area { position: absolute; left: 0; top: 50%; transform: translateY(-50%); flex-direction: column; }' +
                                  '.ducati-selector { flex-direction: column; }';
                        } else if (pos === 'right') {
                            css = '.ducati-lisboa-360-wrapper { position: relative; }' +
                                  '.ducati-controls-area { position: absolute; right: 0; top: 50%; transform: translateY(-50%); flex-direction: column; }' +
                                  '.ducati-selector { flex-direction: column; }';
                        }
                        if (offX || offY) {
                            css += '.ducati-controls-area { margin-left: ' + offX + 'px; margin-top: ' + offY + 'px; }';
                        }
                        if (css) {
                            var styleEl = iframeDoc.createElement('style');
                            styleEl.id = 'cfg-pos-style';
                            styleEl.textContent = css;
                            iframeDoc.head.appendChild(styleEl);
                        }
                    }

                    $('#cfg-controls-pos').on('change', updatePreviewPositioning);
                    $('#cfg-offset-x, #cfg-offset-y').on('input', updatePreviewPositioning);
                    // Sync: number input -> range slider
                    $('#cfg-offset-x-input').on('input', function() {
                        var v = parseInt($(this).val()) || 0;
                        v = Math.max(-200, Math.min(200, v));
                        $('#cfg-offset-x').val(v);
                        updatePreviewPositioning();
                    });
                    $('#cfg-offset-y-input').on('input', function() {
                        var v = parseInt($(this).val()) || 0;
                        v = Math.max(-200, Math.min(200, v));
                        $('#cfg-offset-y').val(v);
                        updatePreviewPositioning();
                    });
                    // Inicializar posicionamento no preview
                    setTimeout(function() { updatePreviewPositioning(); }, 1500);

                    // Estado local
                    var activeSlot = 0;
                    var iconSlots = [];

                    // Carregar icons: prioridade a config guardada, senão usar cores detetadas do JS
                    var existingIcons = cfg.footer_icons || [];
                    if (existingIcons.length > 0) {
                        // Usar config guardada
                        for (var si = 0; si < existingIcons.length; si++) {
                            iconSlots.push({
                                key: existingIcons[si].key || 'color_' + si,
                                url: existingIcons[si].url || '',
                                color_name: existingIcons[si].color_name || ('Cor ' + (si + 1)),
                                color_hex: existingIcons[si].color_hex || '',
                                image_count: existingIcons[si].image_count || 0
                            });
                        }
                    } else if (colorDetails.length > 0) {
                        // Usar cores detetadas do bikeData
                        for (var ci = 0; ci < colorDetails.length; ci++) {
                            iconSlots.push({
                                key: colorDetails[ci].key || 'color_' + ci,
                                url: colorDetails[ci].thumbnail || '',
                                color_name: colorDetails[ci].name || ('Cor ' + (ci + 1)),
                                color_hex: '',
                                image_count: colorDetails[ci].image_count || 0
                            });
                        }
                    } else {
                        iconSlots.push({ key: 'color_0', url: '', color_name: 'Cor 1', color_hex: '', image_count: 0 });
                    }

                    function renderIconSlots() {
                        var slotsHtml = '';
                        iconSlots.forEach(function(slot, si) {
                            var isActive = si === activeSlot;
                            var previewStyle = slot.url ? "background-image:url('" + slot.url + "');background-size:cover;background-position:center;" : (slot.color_hex ? 'background:' + slot.color_hex : 'background:#eee;');
                            var hasImg = slot.url ? ' has-image' : '';
                            var imgInfo = slot.image_count > 0 ? '<span style="color:#2271b1;font-size:11px;margin-left:6px;">' + slot.image_count + ' imagens 360°</span>' : '';
                            slotsHtml += '<div class="blkcloner-icon-slot' + (isActive ? ' active' : '') + '" data-slot="' + si + '" style="border:2px solid ' + (isActive ? '#2271b1' : '#ddd') + ';border-radius:8px;padding:10px;margin-bottom:8px;background:' + (isActive ? '#f0f6fc' : '#fff') + ';cursor:pointer;transition:all 0.2s;">' +
                                '<div class="blkcloner-icon-slot-header" style="display:flex;align-items:center;gap:10px;">' +
                                    '<div class="blkcloner-icon-slot-preview' + hasImg + '" style="width:50px;height:50px;border-radius:50%;border:2px solid #ccc;flex-shrink:0;' + previewStyle + '"></div>' +
                                    '<div style="flex:1;min-width:0;">' +
                                        '<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">' +
                                            '<strong style="font-size:11px;color:#646970;">Chave:</strong>' +
                                            '<code style="font-size:11px;background:#f0f0f0;padding:1px 5px;border-radius:3px;">' + $('<span>').text(slot.key).html() + '</code>' +
                                            imgInfo +
                                        '</div>' +
                                        '<div style="display:flex;align-items:center;gap:6px;">' +
                                            '<input type="text" class="cfg-color-name" data-slot="' + si + '" value="' + $('<span>').text(slot.color_name).html() + '" placeholder="Nome da cor" style="flex:1;padding:4px 8px;border:1px solid #ddd;border-radius:4px;font-size:13px;" />' +
                                            '<input type="color" class="cfg-color-hex" data-slot="' + si + '" value="' + (slot.color_hex || '#888888') + '" style="width:36px;height:30px;padding:0;border:1px solid #ddd;border-radius:4px;cursor:pointer;" />' +
                                        '</div>' +
                                        '<small style="color:#646970;font-size:11px;">' + (slot.url ? '✓ Imagem de ícone atribuída' : 'Selecione este slot e clique numa imagem abaixo') + '</small>' +
                                    '</div>' +
                                    '<div style="display:flex;flex-direction:column;gap:4px;flex-shrink:0;">' +
                                        '<button type="button" class="cfg-select-slot" data-slot="' + si + '" style="padding:4px 10px;border:1px solid #2271b1;background:' + (isActive ? '#2271b1' : '#fff') + ';color:' + (isActive ? '#fff' : '#2271b1') + ';border-radius:4px;cursor:pointer;font-size:11px;white-space:nowrap;">' +
                                            (isActive ? '● Ativo' : 'Selecionar') +
                                        '</button>' +
                                        '<button type="button" class="cfg-delete-slot" data-slot="' + si + '" style="padding:4px 10px;border:1px solid #d63638;background:#fff;color:#d63638;border-radius:4px;cursor:pointer;font-size:11px;white-space:nowrap;" title="Apagar esta cor">' +
                                            '<span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px;"></span> Apagar' +
                                        '</button>' +
                                    '</div>' +
                                '</div>' +
                            '</div>';
                        });
                        $('#cfg-icon-slots').html(slotsHtml);
                    }

                    function renderGallery() {
                        var galleryHtml = '';
                        if (images.length === 0) {
                            galleryHtml = '<div class="blkcloner-notice blkcloner-notice-info">Nenhuma imagem encontrada neste bloco.</div>';
                        } else {
                            images.forEach(function(img, ii) {
                                // Verificar se esta imagem já está selecionada nalgum slot
                                var selectedSlot = -1;
                                iconSlots.forEach(function(slot, si) {
                                    if (slot.url === img.url) selectedSlot = si;
                                });
                                var selClass = selectedSlot >= 0 ? ' selected' : '';
                                var badge = selectedSlot >= 0 ? (selectedSlot + 1) : '';
                                galleryHtml += '<div class="blkcloner-icon-item' + selClass + '" data-url="' + img.url + '" data-idx="' + ii + '">' +
                                    '<img src="' + img.url + '" alt="' + $('<span>').text(img.filename).html() + '" loading="lazy" />' +
                                    '<div class="blkcloner-icon-badge">' + badge + '</div>' +
                                    '<div style="padding:4px 6px;font-size:10px;color:#646970;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;" title="' + $('<span>').text(img.filename).html() + '">' +
                                        (ii + 1) + '. ' + $('<span>').text(img.filename).html() +
                                    '</div>' +
                                '</div>';
                            });
                        }
                        $('#cfg-image-gallery').html(galleryHtml);
                    }

                    renderIconSlots();
                    renderGallery();

                    // ---- GRELHA DE REMOÇÃO DE IMAGENS ----
                    function renderRemovableImages() {
                        var rmHtml = '';
                        if (images.length === 0) {
                            rmHtml = '<div class="blkcloner-notice blkcloner-notice-info">Nenhuma imagem.</div>';
                        } else {
                            images.forEach(function(img, ii) {
                                rmHtml += '<div class="blkcloner-icon-item blkcloner-rm-img-item" data-rm-idx="' + ii + '" style="position:relative;">' +
                                    '<label style="position:absolute;top:2px;left:2px;z-index:2;background:rgba(255,255,255,0.85);border-radius:3px;padding:1px 4px;cursor:pointer;">' +
                                    '<input type="checkbox" class="cfg-rm-check" data-rm-idx="' + ii + '" style="cursor:pointer;" />' +
                                    '</label>' +
                                    '<img src="' + img.url + '" alt="" loading="lazy" style="width:100%;height:80px;object-fit:contain;" />' +
                                    '<div style="padding:2px 4px;font-size:9px;color:#646970;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;">' + (ii+1) + '/' + images.length + '</div>' +
                                '</div>';
                            });
                        }
                        $('#cfg-removable-images').html(rmHtml);
                        $('#cfg-total-images-count').text(images.length + ' imagens no total');
                    }
                    renderRemovableImages();

                    var rmAllSel = false;
                    function updateRmCount() {
                        var checked = $('.cfg-rm-check:checked').length;
                        if (checked > 0) {
                            $('#cfg-remove-selected-rm').show();
                            $('#cfg-rm-sel-count').text(checked + ' selecionada(s)');
                        } else {
                            $('#cfg-remove-selected-rm').hide();
                            $('#cfg-rm-sel-count').text('');
                        }
                    }
                    $(document).on('click.cfgRmAll', '#cfg-select-all-rm', function() {
                        rmAllSel = !rmAllSel;
                        $('.cfg-rm-check').prop('checked', rmAllSel);
                        $(this).html(rmAllSel ? '☑ Desselecionar' : '☐ Selecionar Todas');
                        $('.blkcloner-rm-img-item').css('opacity', rmAllSel ? '0.4' : '1');
                        updateRmCount();
                    });
                    $(document).on('change.cfgRmChk', '.cfg-rm-check', function() {
                        var item = $(this).closest('.blkcloner-rm-img-item');
                        item.css('opacity', $(this).is(':checked') ? '0.4' : '1');
                        updateRmCount();
                    });
                    $(document).on('click.cfgRmBtn', '#cfg-remove-selected-rm', function() {
                        var toRemove = [];
                        $('.cfg-rm-check:checked').each(function() {
                            toRemove.push(parseInt($(this).data('rm-idx')));
                        });
                        if (toRemove.length === 0) return;
                        if (!confirm('Remover ' + toRemove.length + ' imagem(ns)? Isto também as remove do 360°.')) return;

                        // Remover do array (ordenar decrescente)
                        toRemove.sort(function(a,b) { return b-a; });
                        var removedUrls = [];
                        toRemove.forEach(function(idx) {
                            if (images[idx]) {
                                removedUrls.push(images[idx].url || '');
                                images.splice(idx, 1);
                            }
                        });

                        // Remover URLs do JS (bikeData)
                        if (blockJs) {
                            removedUrls.forEach(function(url) {
                                if (url) {
                                    var escaped = url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                                    blockJs = blockJs.replace(new RegExp('\\s*"' + escaped + '"\\s*,?', 'g'), '');
                                }
                            });
                            blockJs = blockJs.replace(/,\s*\]/g, ']');
                        }

                        // Re-render
                        renderRemovableImages();
                        renderGallery();
                        updateRmCount();
                        refreshLivePreview();
                    });

                    // Selecionar slot
                    $(document).on('click.cfgslot', '.cfg-select-slot, .blkcloner-icon-slot', function(e) {
                        if ($(e.target).is('input')) return;
                        var slot = parseInt($(this).closest('.blkcloner-icon-slot').attr('data-slot') || $(this).attr('data-slot'));
                        if (!isNaN(slot)) {
                            activeSlot = slot;
                            renderIconSlots();
                            renderGallery();
                        }
                    });

                    // Selecionar imagem da galeria para o slot ativo
                    $(document).on('click.cfgimg', '.blkcloner-icon-item', function() {
                        var url = $(this).attr('data-url');
                        if (activeSlot >= 0 && activeSlot < iconSlots.length) {
                            iconSlots[activeSlot].url = url;
                            renderIconSlots();
                            renderGallery();
                        }
                    });

                    // Atualizar nome da cor
                    $(document).on('input.cfgname', '.cfg-color-name', function() {
                        var si = parseInt($(this).attr('data-slot'));
                        if (!isNaN(si) && si < iconSlots.length) {
                            iconSlots[si].color_name = $(this).val();
                        }
                    });

                    // Atualizar hex da cor
                    $(document).on('input.cfghex', '.cfg-color-hex', function() {
                        var si = parseInt($(this).attr('data-slot'));
                        if (!isNaN(si) && si < iconSlots.length) {
                            iconSlots[si].color_hex = $(this).val();
                        }
                    });

                    // Adicionar nova cor
                    $('#cfg-add-icon-slot').on('click', function() {
                        var newIdx = iconSlots.length;
                        iconSlots.push({ key: 'color_' + newIdx, url: '', color_name: 'Cor ' + (newIdx + 1), color_hex: '', image_count: 0 });
                        activeSlot = newIdx;
                        renderIconSlots();
                        renderGallery();
                    });

                    // Apagar cor individual
                    $(document).on('click.cfgdel', '.cfg-delete-slot', function(e) {
                        e.stopPropagation();
                        var si = parseInt($(this).attr('data-slot'));
                        if (isNaN(si) || iconSlots.length <= 1) {
                            alert('Tem de manter pelo menos uma cor.');
                            return;
                        }
                        var nome = iconSlots[si].color_name || 'Cor ' + (si + 1);
                        if (!confirm('Apagar a cor "' + nome + '"?')) return;
                        iconSlots.splice(si, 1);
                        if (activeSlot >= iconSlots.length) activeSlot = iconSlots.length - 1;
                        renderIconSlots();
                        renderGallery();
                    });

                    // ---- ADICIONAR IMAGENS PERSONALIZADAS ----
                    function showUploadStatus(msg, type) {
                        var el = $('#cfg-image-upload-status');
                        var bg = type === 'success' ? '#e8f5e9' : (type === 'error' ? '#fce4ec' : '#f0f6fc');
                        var color = type === 'success' ? '#2e7d32' : (type === 'error' ? '#c62828' : '#1565c0');
                        el.html(msg).css({ display: 'block', background: bg, color: color, border: '1px solid ' + color });
                        setTimeout(function() { el.fadeOut(); }, 4000);
                    }

                    function uploadCustomImage(formData) {
                        formData.append('action', 'blkcloner_add_custom_image');
                        formData.append('nonce', nonce);
                        formData.append('block_id', id);

                        $.ajax({
                            url: ajaxurl,
                            method: 'POST',
                            data: formData,
                            processData: false,
                            contentType: false,
                            beforeSend: function() {
                                showUploadStatus('<span class="blkcloner-spinner" style="border-color:rgba(0,0,0,.2);border-top-color:#1565c0;display:inline-block;vertical-align:middle;margin-right:6px;"></span> A carregar imagem...', 'info');
                            },
                            success: function(resp) {
                                if (resp.success) {
                                    showUploadStatus('&#10003; ' + resp.data.message, 'success');
                                    // Adicionar novas imagens à galeria local
                                    resp.data.images.forEach(function(img) {
                                        images.push({ url: img.url, filename: img.filename });
                                    });
                                    $('#cfg-gallery-count').text(images.length + ' imagens');
                                    renderGallery();
                                } else {
                                    showUploadStatus('&#9888; ' + resp.data, 'error');
                                }
                            },
                            error: function() {
                                showUploadStatus('&#9888; Erro de rede ao carregar imagem.', 'error');
                            }
                        });
                    }

                    // Botão: Carregar ficheiro
                    $('#cfg-add-image-file').on('click', function() {
                        $('#cfg-image-file-input').click();
                    });
                    $('#cfg-image-file-input').on('change', function() {
                        var files = this.files;
                        if (!files || files.length === 0) return;
                        var formData = new FormData();
                        for (var fi = 0; fi < files.length; fi++) {
                            formData.append('custom_image[]', files[fi]);
                        }
                        uploadCustomImage(formData);
                        $(this).val(''); // Reset input
                    });

                    // Botão: Adicionar por URL (toggle)
                    $('#cfg-add-image-url-toggle').on('click', function() {
                        $('#cfg-url-input-area').slideToggle(200);
                    });
                    // Botão: Confirmar URL
                    $('#cfg-add-image-url-btn').on('click', function() {
                        var url = $('#cfg-image-url-input').val().trim();
                        if (!url) {
                            showUploadStatus('&#9888; Introduza uma URL válida.', 'error');
                            return;
                        }
                        var formData = new FormData();
                        formData.append('image_url', url);
                        uploadCustomImage(formData);
                        $('#cfg-image-url-input').val('');
                    });
                    $('#cfg-image-url-input').on('keydown', function(e) {
                        if (e.key === 'Enter') { e.preventDefault(); $('#cfg-add-image-url-btn').click(); }
                    });

                    // Guardar configuração
                    $('#cfg-save-btn').on('click', function() {
                        var saveBtn = $(this);
                        saveBtn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A guardar...');

                        // Recolher nomes atualizados dos inputs
                        $('#cfg-icon-slots .cfg-color-name').each(function() {
                            var si = parseInt($(this).attr('data-slot'));
                            if (!isNaN(si) && si < iconSlots.length) {
                                iconSlots[si].color_name = $(this).val();
                            }
                        });
                        $('#cfg-icon-slots .cfg-color-hex').each(function() {
                            var si = parseInt($(this).attr('data-slot'));
                            if (!isNaN(si) && si < iconSlots.length) {
                                iconSlots[si].color_hex = $(this).val();
                            }
                        });

                        var configData = {
                            container_width: $('#cfg-container-width').val(),
                            btn_size: parseInt($('#cfg-btn-size').val()) || 45,
                            active_color: $('#cfg-active-color').val(),
                            controls_position: $('#cfg-controls-pos').val(),
                            controls_offset_x: parseInt($('#cfg-offset-x').val()) || 0,
                            controls_offset_y: parseInt($('#cfg-offset-y').val()) || 0,
                            show_single_color: $('#cfg-show-single-color').is(':checked'),
                            footer_icons: iconSlots
                        };

                        $.ajax({
                            url: ajaxurl,
                            method: 'POST',
                            data: {
                                action: 'blkcloner_save_config',
                                nonce: nonce,
                                block_id: id,
                                config: JSON.stringify(configData)
                            },
                            success: function(resp) {
                                if (resp.success) {
                                    toast('Configuração guardada! As alterações serão visíveis no frontend.', 'success');
                                } else {
                                    toast('Erro: ' + resp.data, 'error');
                                }
                            },
                            error: function() { toast('Erro de rede.', 'error'); },
                            complete: function() {
                                saveBtn.prop('disabled', false).html('<span class="dashicons dashicons-saved"></span> Guardar Configuração');
                            }
                        });
                    });

                    // Fechar modal
                    function closeConfigModal() {
                        modal.remove();
                        $(document).off('.cfgslot .cfgimg .cfgname .cfghex .cfgdel .blkcfg');
                    }
                    modal.on('click', '.blkcloner-config-close', closeConfigModal);
                    modal.on('click', function(e) {
                        if ($(e.target).hasClass('blkcloner-config-modal')) closeConfigModal();
                    });
                    $(document).on('keydown.blkcfg', function(e) {
                        if (e.key === 'Escape') closeConfigModal();
                    });
                },
                error: function() { toast('Erro ao carregar configuração.', 'error'); },
                complete: function() { btn.prop('disabled', false); }
            });
        });

        // =============================================
        // DUPLICAR BLOCO
        // =============================================
        $(document).on('click', '.blkcloner-duplicate-block', function() {
            var btn = $(this);
            var id = btn.attr('data-id');
            btn.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_duplicate', nonce: nonce, block_id: id },
                success: function(response) {
                    if (response.success) {
                        toast('Bloco duplicado! Novo: ' + response.data.shortcode, 'success');
                        setTimeout(function() { location.reload(); }, 1200);
                    } else {
                        toast('Erro: ' + response.data, 'error');
                    }
                },
                error: function() { toast('Erro de rede.', 'error'); },
                complete: function() { btn.prop('disabled', false); }
            });
        });

        // =============================================
        // EXPORTAR IMAGENS DO BLOCO (ZIP)
        // =============================================
        $(document).on('click', '.blkcloner-export-images', function() {
            var btn = $(this);
            var id = btn.attr('data-id');
            var name = btn.attr('data-name') || id;

            btn.prop('disabled', true).html('<span class="blkcloner-spinner" style="border-color:rgba(0,0,0,.2);border-top-color:#333;"></span>');

            // Abrir URL de download direto (admin-post.php)
            var url = exportImagesBaseUrl + '&block_id=' + encodeURIComponent(id);
            var downloadFrame = document.createElement('iframe');
            downloadFrame.style.display = 'none';
            downloadFrame.src = url;
            document.body.appendChild(downloadFrame);

            // Restaurar botão após tempo razoável para o download iniciar
            setTimeout(function() {
                btn.prop('disabled', false).html('<span class="dashicons dashicons-format-gallery"></span>');
                toast('A exportar imagens de "' + name + '"...', 'info');
                // Limpar iframe após download
                setTimeout(function() {
                    if (downloadFrame.parentNode) {
                        downloadFrame.parentNode.removeChild(downloadFrame);
                    }
                }, 30000);
            }, 2000);
        });

        // =============================================
        // EXPORTAR BLOCOS
        // =============================================
        $('#blkcloner-export-btn').on('click', function() {
            var btn = $(this);
            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A exportar...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_export', nonce: nonce, block_ids: 'all' },
                success: function(response) {
                    if (response.success) {
                        var json = JSON.stringify(response.data, null, 2);
                        var blob = new Blob([json], { type: 'application/json' });
                        var url = URL.createObjectURL(blob);
                        var a = document.createElement('a');
                        a.href = url;
                        a.download = 'ducati-block-cloner-export-' + new Date().toISOString().slice(0, 10) + '.json';
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        toast('Exportação concluída! ' + response.data.count + ' bloco(s).', 'success');
                    } else {
                        toast('Erro: ' + response.data, 'error');
                    }
                },
                error: function() { toast('Erro de rede na exportação.', 'error'); },
                complete: function() {
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-download"></span> Exportar <?php echo count( $saved_blocks ); ?> Bloco(s)');
                }
            });
        });

        // =============================================
        // IMPORTAR BLOCOS
        // =============================================
        $('#blkcloner-import-file').on('change', function() {
            $('#blkcloner-import-btn').prop('disabled', !this.files.length);
        });

        $('#blkcloner-import-btn').on('click', function() {
            var btn = $(this);
            var fileInput = document.getElementById('blkcloner-import-file');
            if (!fileInput.files.length) { toast('Selecione um ficheiro JSON.', 'error'); return; }

            var reader = new FileReader();
            reader.onload = function(e) {
                var content = e.target.result;
                try { JSON.parse(content); } catch(ex) { toast('Ficheiro JSON inválido.', 'error'); return; }

                btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A importar...');

                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: { action: 'blkcloner_import', nonce: nonce, import_data: content },
                    success: function(response) {
                        if (response.success) {
                            toast(response.data.message, 'success');
                            setTimeout(function() { location.reload(); }, 1500);
                        } else {
                            toast('Erro: ' + response.data, 'error');
                        }
                    },
                    error: function() { toast('Erro de rede na importação.', 'error'); },
                    complete: function() {
                        btn.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Importar Blocos');
                    }
                });
            };
            reader.readAsText(fileInput.files[0]);
        });

        // =============================================
        // TAB DESINSTALAR
        // =============================================

        // =============================================
        // LICENCIAMENTO
        // =============================================
        $('#blkcloner-activate-license').on('click', function() {
            var btn = $(this);
            var key = $('#blkcloner-license-key').val().trim().toUpperCase();
            if (!key) { toast('Introduza a chave de licença.', 'error'); return; }

            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span>');
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_activate_license', nonce: nonce, license_key: key },
                success: function(response) {
                    if (response.success) {
                        toast(response.data, 'success');
                        setTimeout(function() { location.reload(); }, 1200);
                    } else {
                        toast(response.data, 'error');
                    }
                },
                error: function() { toast('Erro de rede.', 'error'); },
                complete: function() { btn.prop('disabled', false).text('Ativar'); }
            });
        });

        $('#blkcloner-deactivate-license').on('click', function() {
            if (!confirm('Remover licença? A marca d\'água voltará a aparecer.')) return;
            var btn = $(this);
            btn.prop('disabled', true);
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_deactivate_license', nonce: nonce },
                success: function(response) {
                    if (response.success) {
                        toast(response.data, 'success');
                        setTimeout(function() { location.reload(); }, 1200);
                    }
                },
                complete: function() { btn.prop('disabled', false); }
            });
        });

        // Enter key no campo de licença
        $('#blkcloner-license-key').on('keydown', function(e) {
            if (e.key === 'Enter') $('#blkcloner-activate-license').click();
        });

        // Checkbox ativa/desativa botão de limpeza total
        $('#blkcloner-confirm-uninstall').on('change', function() {
            $('#blkcloner-full-uninstall').prop('disabled', !$(this).is(':checked'));
        });

        // Apagar todos os blocos
        $('#blkcloner-delete-all-blocks').on('click', function(e) {
            e.preventDefault();
            if (!confirm('ATENÇÃO: Vai apagar TODOS os blocos guardados.\nOs shortcodes nas páginas deixarão de funcionar.\n\nTem a certeza?')) return;

            var btn = $(this);
            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A apagar...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'blkcloner_delete_all_blocks',
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        toast(response.data, 'success');
                        setTimeout(function() { location.reload(); }, 1500);
                    } else {
                        toast('Erro: ' + (response.data || 'Erro desconhecido'), 'error');
                        btn.prop('disabled', false).html('<span class="dashicons dashicons-trash" style="margin-right:4px;"></span> Apagar Todos os Blocos');
                    }
                },
                error: function(xhr, status, error) {
                    toast('Erro de rede: ' + error, 'error');
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-trash" style="margin-right:4px;"></span> Apagar Todos os Blocos');
                }
            });
        });

        // Limpar cache (tab desinstalar)
        $('#blkcloner-delete-cache-full').on('click', function(e) {
            e.preventDefault();
            if (!confirm('Limpar toda a cache de imagens e páginas?')) return;

            var btn = $(this);
            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A limpar...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'blkcloner_clear_cache',
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        toast(response.data, 'success');
                        setTimeout(function() { location.reload(); }, 1500);
                    } else {
                        toast('Erro: ' + (response.data || 'Erro desconhecido'), 'error');
                    }
                },
                complete: function() {
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-trash" style="margin-right:4px;"></span> Limpar Toda a Cache');
                }
            });
        });

        // Limpeza total
        $('#blkcloner-full-uninstall').on('click', function(e) {
            e.preventDefault();
            if (!confirm('ATENÇÃO FINAL: Isto vai apagar TODOS os dados do Ducati Block Cloner:\n\n- Todos os blocos guardados\n- Toda a cache\n- Todos os transients\n- Todas as opções da base de dados\n\nEsta ação NÃO pode ser revertida.\nTem a certeza absoluta?')) return;

            var btn = $(this);
            btn.prop('disabled', true).html('<span class="blkcloner-spinner"></span> A limpar tudo...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'blkcloner_full_uninstall',
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        toast(response.data, 'success');
                        setTimeout(function() { window.location.href = '<?php echo admin_url( "plugins.php" ); ?>'; }, 2000);
                    } else {
                        toast('Erro: ' + (response.data || 'Erro desconhecido'), 'error');
                        btn.prop('disabled', false).html('<span class="dashicons dashicons-dismiss" style="margin-right:4px;"></span> Limpeza Total');
                    }
                },
                error: function(xhr, status, error) {
                    toast('Erro de rede: ' + error, 'error');
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-dismiss" style="margin-right:4px;"></span> Limpeza Total');
                }
            });
        });


    })(jQuery);
    </script>
    <?php
}
endif;
