<?php
/**
 * Ducati Block Cloner - Funcionalidades Avançadas
 *
 * @package    DucatiBlockCloner
 * @author     Eng. Fernando Condeço - Netseg.ai
 * @copyright  2024-2026 Netseg.ai
 * @version    1.2.2
 */

// Impedir acesso direto
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'BLKCLONER_OPTION_KEY' ) ) {
    define( 'BLKCLONER_OPTION_KEY', 'blkcloner_saved_blocks' );
}

// =============================================
// REST API ENDPOINTS
// =============================================
add_action( 'rest_api_init', function () {

    // GET /wp-json/block-cloner/v1/blocks
    register_rest_route( 'block-cloner/v1', '/blocks', array(
        'methods'             => 'GET',
        'callback'            => function () {
            $blocks = get_option( BLKCLONER_OPTION_KEY, array() );
            $result = array();
            foreach ( $blocks as $id => $block ) {
                $result[] = array(
                    'id'         => $id,
                    'name'       => $block['name'],
                    'shortcode'  => $block['shortcode'],
                    'source_url' => $block['source_url'],
                    'created_at' => $block['created_at'],
                );
            }
            return rest_ensure_response( $result );
        },
        'permission_callback' => function () {
            return current_user_can( 'manage_options' );
        },
    ));

    // POST /wp-json/block-cloner/v1/scan - Scanner client-side
    register_rest_route( 'block-cloner/v1', '/scan', array(
        'methods'             => 'POST',
        'callback'            => 'blkcloner_api_scan',
        'permission_callback' => function () {
            return current_user_can( 'manage_options' );
        },
    ));

    // POST /wp-json/block-cloner/v1/save-scan - Guardar resultado do scan
    register_rest_route( 'block-cloner/v1', '/save-scan', array(
        'methods'             => 'POST',
        'callback'            => 'blkcloner_api_save_scan',
        'permission_callback' => function () {
            return current_user_can( 'manage_options' );
        },
    ));
});

if ( ! function_exists( 'blkcloner_api_scan' ) ) :
function blkcloner_api_scan( $request ) {
    $url = esc_url_raw( $request->get_param( 'url' ) );
    if ( empty( $url ) ) {
        return new WP_Error( 'missing_url', 'URL é obrigatório.', array( 'status' => 400 ) );
    }

    // Gerar página de scanning
    $scan_id = 'scan_' . wp_generate_password( 8, false );

    set_transient( 'blkcloner_scan_' . $scan_id, array(
        'url'    => $url,
        'status' => 'pending',
        'time'   => time(),
    ), HOUR_IN_SECONDS );

    return rest_ensure_response( array(
        'scan_id'  => $scan_id,
        'scan_url' => home_url( '?blkcloner_scan=' . $scan_id ),
        'message'  => 'Abra o scan_url numa nova aba para iniciar a extração visual.',
    ));
}
endif;

// =============================================
// SANITIZAÇÃO HTML CUSTOMIZADA (preserva data-* attributes)
// =============================================
if ( ! function_exists( 'blkcloner_kses_html' ) ) :
/**
 * Sanitiza HTML preservando data-* attributes essenciais para blocos interativos.
 * wp_kses_post() remove data-color, data-name, etc. que são necessários para 360°/SpriteSpin.
 */
function blkcloner_kses_html( $html ) {
    // Remover scripts (JS é tratado separadamente)
    $html = preg_replace( '/<script\b[^>]*>.*?<\/script>/is', '', $html );
    // Remover inline event handlers (onclick, onload, onerror, etc.)
    $html = preg_replace( '/\s+on[a-z]+\s*=\s*["\'][^"\']*["\']/i', '', $html );
    $html = preg_replace( '/\s+on[a-z]+\s*=\s*[^\s>]+/i', '', $html );
    // Remover javascript: URLs
    $html = preg_replace( '/href\s*=\s*["\']javascript:[^"\']*["\']/i', 'href="#"', $html );
    return $html;
}
endif;

if ( ! function_exists( 'blkcloner_api_save_scan' ) ) :
function blkcloner_api_save_scan( $request ) {
    $data = $request->get_json_params();

    if ( empty( $data['html'] ) ) {
        return new WP_Error( 'missing_data', 'HTML é obrigatório.', array( 'status' => 400 ) );
    }

    $block_id = 'blk_' . strtolower( wp_generate_password( 8, false ) );
    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    // Processar e guardar imagens
    $images = array();
    if ( ! empty( $data['images'] ) && is_array( $data['images'] ) ) {
        foreach ( $data['images'] as $img_url ) {
            $images[] = array(
                'original'  => $img_url,
                'local_url' => home_url( '?blkcloner_proxy=1&url=' . urlencode( $img_url ) ),
            );
        }
    }

    // Extrair <style> tags do HTML e juntar ao CSS
    $raw_html = $data['html'];
    $css      = $data['css'] ?? '';
    if ( preg_match_all( '/<style[^>]*>(.*?)<\/style>/is', $raw_html, $style_matches ) ) {
        foreach ( $style_matches[1] as $inline_css ) {
            $css .= "\n" . $inline_css;
        }
        $raw_html = preg_replace( '/<style[^>]*>.*?<\/style>/is', '', $raw_html );
    }

    // Filter oversized CSS: keep only rules relevant to block HTML
    // Usar sanitização customizada que preserva data-* attributes (essenciais para 360° e interatividade)
    $clean_html = blkcloner_kses_html( $raw_html );
    if ( strlen( $css ) > 50000 && function_exists( 'blkcloner_filter_relevant_css' ) ) {
        $css = blkcloner_filter_relevant_css( $css, $clean_html );
    }

    $saved[ $block_id ] = array(
        'id'         => $block_id,
        'name'       => sanitize_text_field( $data['name'] ?? 'Scan ' . date( 'd/m/Y H:i' ) ),
        'html'       => $clean_html,
        'css'        => wp_strip_all_tags( $css ),
        'js'         => $data['js'] ?? '',
        'images'     => $images,
        'source_url' => esc_url_raw( $data['source_url'] ?? '' ),
        'shortcode'  => '[cloned_block id="' . $block_id . '"]',
        'created_at' => current_time( 'mysql' ),
        'updated_at' => current_time( 'mysql' ),
    );

    update_option( BLKCLONER_OPTION_KEY, $saved );

    return rest_ensure_response( array(
        'block_id'  => $block_id,
        'shortcode' => '[cloned_block id="' . $block_id . '"]',
    ));
}
endif;

// =============================================
// SCANNER VISUAL (IFRAME-BASED)
// =============================================
add_action( 'template_redirect', function () {
    if ( ! isset( $_GET['blkcloner_scan'] ) ) {
        return;
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Acesso negado.' );
    }

    $scan_id = sanitize_key( $_GET['blkcloner_scan'] );
    $scan_data = get_transient( 'blkcloner_scan_' . $scan_id );

    if ( ! $scan_data ) {
        wp_die( 'Scan expirado ou inválido. Inicie um novo scan.' );
    }

    $target_url = $scan_data['url'];

    // Renderizar página de scanning
    ?>
    <!DOCTYPE html>
    <html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Block Cloner - Scanner Visual</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #1d2327; color: #fff; }

            .scanner-toolbar {
                position: fixed; top: 0; left: 0; right: 0; z-index: 99999;
                background: #2271b1; padding: 10px 20px;
                display: flex; align-items: center; gap: 12px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            }
            .scanner-toolbar h3 { font-size: 14px; white-space: nowrap; }
            .scanner-toolbar input { flex: 1; padding: 6px 12px; border: none; border-radius: 4px; font-size: 13px; }
            .scanner-toolbar button {
                padding: 6px 16px; border: none; border-radius: 4px;
                font-size: 13px; cursor: pointer; font-weight: 500;
                transition: all 0.2s;
            }
            .scanner-toolbar .btn-scan { background: #00a32a; color: #fff; }
            .scanner-toolbar .btn-scan:hover { background: #008a20; }
            .scanner-toolbar .btn-save { background: #f0c33c; color: #1d2327; }
            .scanner-toolbar .btn-cancel { background: #d63638; color: #fff; }

            .scanner-frame {
                position: fixed; top: 52px; left: 0; right: 0; bottom: 0;
                border: none; width: 100%; height: calc(100vh - 52px);
            }

            .scanner-sidebar {
                position: fixed; top: 52px; right: 0; bottom: 0; width: 400px;
                background: #23282d; border-left: 2px solid #2271b1;
                overflow-y: auto; padding: 16px; display: none; z-index: 99998;
            }
            .scanner-sidebar.visible { display: block; }
            .scanner-sidebar h4 { color: #72aee6; margin-bottom: 12px; }
            .scanner-sidebar pre {
                background: #1d2327; padding: 12px; border-radius: 4px;
                font-size: 12px; overflow-x: auto; max-height: 300px;
                color: #e0e0e0; white-space: pre-wrap;
            }
            .scanner-sidebar .stat { margin: 8px 0; font-size: 13px; color: #c3c4c7; }
            .scanner-sidebar .stat strong { color: #72aee6; }

            .scanner-overlay {
                position: fixed; top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0,0,0,0.7); z-index: 999999;
                display: none; justify-content: center; align-items: center;
            }
            .scanner-overlay.visible { display: flex; }
            .scanner-modal {
                background: #fff; color: #1d2327; border-radius: 12px;
                padding: 30px; max-width: 500px; width: 90%; text-align: center;
            }
            .scanner-modal h3 { margin-bottom: 16px; }
            .scanner-modal input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; margin: 8px 0; font-size: 14px; }
            .scanner-modal button { margin: 8px 4px; padding: 10px 24px; border: none; border-radius: 6px; font-size: 14px; cursor: pointer; }

            .scanner-status {
                position: fixed; bottom: 20px; left: 20px; z-index: 99999;
                background: #1d2327; color: #fff; padding: 10px 20px;
                border-radius: 8px; font-size: 13px; display: none;
                border: 1px solid #2271b1;
            }
            .scanner-status.visible { display: block; }

            #scanner-highlight {
                position: fixed; pointer-events: none; z-index: 99997;
                border: 3px solid #00a32a; background: rgba(0,163,42,0.1);
                border-radius: 4px; display: none;
                transition: all 0.15s ease;
            }
        </style>
    </head>
    <body>
        <div class="scanner-toolbar">
            <h3>Block Cloner Scanner</h3>
            <input type="text" id="scan-selector" placeholder="Seletor CSS: .classe, #id, [data-attr]" />
            <button class="btn-scan" id="btn-auto-scan">Auto-Scan</button>
            <button class="btn-scan" id="btn-manual-extract">Extrair Seletor</button>
            <button class="btn-save" id="btn-show-save" style="display:none;">Guardar Bloco</button>
            <button class="btn-cancel" onclick="window.close();">Fechar</button>
        </div>

        <iframe id="scanner-frame" class="scanner-frame" sandbox="allow-same-origin allow-scripts allow-popups" referrerpolicy="no-referrer"></iframe>

        <div class="scanner-sidebar" id="scanner-sidebar">
            <h4>Bloco Extraído</h4>
            <div class="stat">HTML: <strong id="stat-html">-</strong></div>
            <div class="stat">Imagens: <strong id="stat-images">-</strong></div>
            <div class="stat">CSS: <strong id="stat-css">-</strong></div>
            <h4 style="margin-top:16px;">Preview HTML</h4>
            <pre id="sidebar-html"></pre>
        </div>

        <div id="scanner-highlight"></div>

        <div class="scanner-overlay" id="save-overlay">
            <div class="scanner-modal">
                <h3>Guardar Bloco</h3>
                <p>Dê um nome ao bloco para facilitar a identificação.</p>
                <input type="text" id="save-name" placeholder="Nome do bloco (ex: Configurador Ducati)" />
                <br>
                <button style="background:#00a32a;color:#fff;" id="btn-confirm-save">Guardar</button>
                <button style="background:#f0f0f1;color:#333;" onclick="document.getElementById('save-overlay').classList.remove('visible');">Cancelar</button>
            </div>
        </div>

        <div class="scanner-status" id="scanner-status"></div>

        <script>
        (function() {
            'use strict';

            var targetUrl = <?php echo wp_json_encode( $target_url ); ?>;
            var wpRestUrl = <?php echo wp_json_encode( rest_url( 'block-cloner/v1/' ) ); ?>;
            var wpNonce = <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?>;
            var extractedData = null;
            var frame = document.getElementById('scanner-frame');
            var statusEl = document.getElementById('scanner-status');

            // Carregar página no iframe (via proxy para evitar X-Frame-Options)
            showStatus('A carregar página...');

            // Usar CORS proxy ou acesso direto
            frame.src = targetUrl;

            frame.onload = function() {
                showStatus('Página carregada. Use Auto-Scan ou introduza um seletor CSS.');
                hideStatus(3000);
            };

            frame.onerror = function() {
                showStatus('Erro: a página bloqueia iframe. Use o método manual (copiar/colar HTML).');
            };

            // AUTO-SCAN: Encontrar blocos interativos automaticamente
            document.getElementById('btn-auto-scan').addEventListener('click', function() {
                showStatus('A procurar blocos interativos...');

                // Tentar aceder ao iframe (pode falhar por CORS)
                try {
                    var iframeDoc = frame.contentDocument || frame.contentWindow.document;
                    autoScan(iframeDoc);
                } catch (e) {
                    // CORS blocked - usar fetch server-side
                    showStatus('Iframe bloqueado por CORS. A usar extração server-side...');
                    serverSideExtract();
                }
            });

            // EXTRAÇÃO MANUAL POR SELETOR
            document.getElementById('btn-manual-extract').addEventListener('click', function() {
                var selector = document.getElementById('scan-selector').value.trim();
                if (!selector) {
                    alert('Introduza um seletor CSS.');
                    return;
                }

                try {
                    var iframeDoc = frame.contentDocument || frame.contentWindow.document;
                    extractBySelector(iframeDoc, selector);
                } catch (e) {
                    // CORS - usar server-side
                    serverSideExtractWithSelector(selector);
                }
            });

            // AUTO-SCAN
            function autoScan(doc) {
                var interactiveSelectors = [
                    // Configuradores de produtos
                    '[data-component*="config"]', '[data-module*="config"]',
                    '.configurator', '.product-configurator',
                    // Rotação 360° e seletor de cores
                    '.d-model-preview', '[data-image-urls]',
                    '.spritespin', '[data-spritespin]',
                    '.color-switch', '.color-selector', '.color-btn',
                    '[data-color]', '.rotation-viewer', '.viewer-360',
                    // Galerias interativas
                    '.interactive-gallery', '.product-gallery',
                    '.hero-carousel', '.slider-container',
                    // Genéricos
                    '[data-react-component]', '[data-vue-component]',
                    '[ng-app]', '[data-controller]',
                    // Elementos com muitas imagens (provavelmente interativos)
                    'section', '.section', '.block', '.module',
                ];

                var found = [];

                interactiveSelectors.forEach(function(sel) {
                    try {
                        var els = doc.querySelectorAll(sel);
                        els.forEach(function(el) {
                            var images = el.querySelectorAll('img, [data-src], [style*="background-image"]');
                            var hasJS = el.querySelectorAll('script, [onclick], [onmouseover], [data-action]').length > 0;
                            var hasInteraction = el.querySelectorAll('button, input, select, [role="button"], [tabindex]').length > 0;

                            if (images.length >= 2 || hasJS || hasInteraction) {
                                found.push({
                                    selector: sel,
                                    element: el,
                                    images: images.length,
                                    interactive: hasJS || hasInteraction,
                                    size: el.getBoundingClientRect()
                                });
                            }
                        });
                    } catch (e) { /* selector inválido */ }
                });

                if (found.length === 0) {
                    showStatus('Nenhum bloco interativo encontrado automaticamente. Tente um seletor manual.');
                    hideStatus(5000);
                    return;
                }

                // Ordenar por relevância (mais imagens + interativo primeiro)
                found.sort(function(a, b) {
                    var scoreA = a.images * 2 + (a.interactive ? 10 : 0);
                    var scoreB = b.images * 2 + (b.interactive ? 10 : 0);
                    return scoreB - scoreA;
                });

                var best = found[0];
                showStatus('Encontrado: "' + best.selector + '" com ' + best.images + ' imagens. A extrair...');

                extractElement(best.element, best.selector, doc);
            }

            // EXTRAIR POR SELETOR
            function extractBySelector(doc, selector) {
                var el = doc.querySelector(selector);
                if (!el) {
                    showStatus('Elemento não encontrado com o seletor: ' + selector);
                    hideStatus(4000);
                    return;
                }
                extractElement(el, selector, doc);
            }

            // EXTRAIR ELEMENTO
            function extractElement(el, selector, doc) {
                var html = el.outerHTML;

                // Extrair imagens
                var images = [];
                var imgEls = el.querySelectorAll('img, [data-src], [style*="background"]');
                imgEls.forEach(function(img) {
                    var src = img.src || img.getAttribute('data-src') || img.getAttribute('data-lazy');
                    if (src) images.push(src);

                    var srcset = img.getAttribute('srcset');
                    if (srcset) {
                        srcset.split(',').forEach(function(s) {
                            var url = s.trim().split(/\s+/)[0];
                            if (url) images.push(url);
                        });
                    }

                    var bg = img.style.backgroundImage;
                    if (bg) {
                        var match = bg.match(/url\(['"]*([^'")\s]+)['"]*\)/);
                        if (match) images.push(match[1]);
                    }
                });

                // Extrair CSS computado
                var css = extractComputedCSS(el, doc);

                // Extrair JS inline
                var js = '';
                var scripts = el.querySelectorAll('script');
                scripts.forEach(function(script) {
                    if (!script.src) {
                        js += script.textContent + '\n';
                    }
                });

                // Deduplificar imagens
                images = [...new Set(images)].filter(function(url) {
                    return url && !url.startsWith('data:');
                });

                extractedData = {
                    html: html,
                    css: css,
                    js: js,
                    images: images,
                    source_url: targetUrl,
                    selector: selector
                };

                // Atualizar sidebar
                document.getElementById('stat-html').textContent = formatBytes(html.length);
                document.getElementById('stat-images').textContent = images.length + ' imagens';
                document.getElementById('stat-css').textContent = formatBytes(css.length);
                document.getElementById('sidebar-html').textContent = html.substring(0, 2000) + (html.length > 2000 ? '\n...' : '');

                document.getElementById('scanner-sidebar').classList.add('visible');
                document.getElementById('btn-show-save').style.display = 'inline-block';

                // Ajustar iframe
                frame.style.right = '400px';

                showStatus('Bloco extraído com sucesso! ' + images.length + ' imagens encontradas.');
                hideStatus(4000);
            }

            // CSS COMPUTADO
            function extractComputedCSS(el, doc) {
                var css = '';
                var allStyles = doc.querySelectorAll('style, link[rel="stylesheet"]');

                allStyles.forEach(function(styleEl) {
                    if (styleEl.tagName === 'STYLE') {
                        css += styleEl.textContent + '\n';
                    }
                });

                return css;
            }

            // SERVER-SIDE EXTRACT
            function serverSideExtract() {
                // Redirecionar para admin com URL pré-preenchido
                window.location.href = <?php echo wp_json_encode( admin_url( 'admin.php?page=block-cloner' ) ); ?> +
                    '&url=' + encodeURIComponent(targetUrl);
            }

            function serverSideExtractWithSelector(selector) {
                window.location.href = <?php echo wp_json_encode( admin_url( 'admin.php?page=block-cloner' ) ); ?> +
                    '&url=' + encodeURIComponent(targetUrl) +
                    '&selector=' + encodeURIComponent(selector);
            }

            // GUARDAR
            document.getElementById('btn-show-save').addEventListener('click', function() {
                document.getElementById('save-overlay').classList.add('visible');
            });

            document.getElementById('btn-confirm-save').addEventListener('click', function() {
                if (!extractedData) return;

                var name = document.getElementById('save-name').value || 'Bloco ' + new Date().toLocaleDateString('pt-PT');

                fetch(wpRestUrl + 'save-scan', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': wpNonce
                    },
                    body: JSON.stringify({
                        name: name,
                        html: extractedData.html,
                        css: extractedData.css,
                        js: extractedData.js,
                        images: extractedData.images,
                        source_url: extractedData.source_url
                    })
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    document.getElementById('save-overlay').classList.remove('visible');
                    alert('Bloco guardado!\n\nShortcode: ' + data.shortcode + '\n\nCole este shortcode num widget Shortcode do Elementor Pro.');
                })
                .catch(function(err) {
                    alert('Erro ao guardar: ' + err.message);
                });
            });

            // UTILIDADES
            function showStatus(msg) {
                statusEl.textContent = msg;
                statusEl.classList.add('visible');
            }

            function hideStatus(delay) {
                if (delay) {
                    setTimeout(function() { statusEl.classList.remove('visible'); }, delay);
                } else {
                    statusEl.classList.remove('visible');
                }
            }

            function formatBytes(bytes) {
                if (bytes === 0) return '0 B';
                var k = 1024;
                var sizes = ['B', 'KB', 'MB'];
                var i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
            }

        })();
        </script>
    </body>
    </html>
    <?php
    exit;
});


// =============================================
// AUTO-PREENCHER URL/SELECTOR VIA QUERY STRING
// =============================================
add_action( 'admin_footer', function () {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'toplevel_page_block-cloner' ) {
        return;
    }

    $url = isset( $_GET['url'] ) ? esc_url_raw( urldecode( $_GET['url'] ) ) : '';
    $selector = isset( $_GET['selector'] ) ? sanitize_text_field( urldecode( $_GET['selector'] ) ) : '';

    if ( $url || $selector ) {
        ?>
        <script>
        jQuery(function($) {
            <?php if ( $url ) : ?>
                $('#blkcloner-url').val(<?php echo wp_json_encode( $url ); ?>);
            <?php endif; ?>
            <?php if ( $selector ) : ?>
                $('#blkcloner-selector').val(<?php echo wp_json_encode( $selector ); ?>);
            <?php endif; ?>
        });
        </script>
        <?php
    }
});
