<?php
/**
 * Ducati Block Cloner - Uninstall
 *
 * Executado quando o plugin é eliminado pelo WordPress.
 * Limpa todos os dados da base de dados e ficheiros de cache.
 *
 * @package DucatiBlockCloner
 */

// Segurança: só executar via WordPress uninstall
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// 1. Apagar blocos guardados
delete_option( 'blkcloner_saved_blocks' );

// 2. Apagar opções adicionais
delete_option( 'blkcloner_version' );
delete_option( 'blkcloner_language' );
delete_option( 'blkcloner_license' );

// 3. Limpar registo de uninstall hooks órfãos
$uninstall_plugins = get_option( 'uninstall_plugins', array() );
if ( isset( $uninstall_plugins[ plugin_basename( __FILE__ ) ] ) ) {
    unset( $uninstall_plugins[ plugin_basename( __FILE__ ) ] );
    update_option( 'uninstall_plugins', $uninstall_plugins );
}

// 4. Limpar transients
global $wpdb;
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_blkcloner_%' OR option_name LIKE '_transient_timeout_blkcloner_%'"
);

// 5. Limpar cache dir (incluindo subpastas)
$cache_dir = WP_CONTENT_DIR . '/cache/block-cloner/';
if ( is_dir( $cache_dir ) ) {
    // Função recursiva para limpar diretórios
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator( $cache_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ( $iterator as $item ) {
        if ( $item->isDir() ) {
            @rmdir( $item->getRealPath() );
        } else {
            @unlink( $item->getRealPath() );
        }
    }
    @rmdir( $cache_dir );
}
