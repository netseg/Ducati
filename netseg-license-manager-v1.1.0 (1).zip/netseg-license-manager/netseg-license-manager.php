<?php
/**
 * Plugin Name:       NETSEG License Manager
 * Plugin URI:        https://netseg.ai
 * Description:       Gerador e gestor de chaves de licença para plugins NETSEG.AI. Chaves bloqueadas por domínio — só funcionam na instalação do cliente.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Eng. Fernando Condeço - Netseg.ai
 * Author URI:        https://netseg.ai
 * License:           GPL v2 or later
 * Text Domain:       netseg-license-manager
 *
 * @package NetsegLicenseManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ESTE PLUGIN É APENAS PARA ADMIN — zero impacto no frontend
if ( ! is_admin() ) {
    return;
}

define( 'NSLM_VERSION', '1.1.0' );
define( 'NSLM_OPTION_KEY', 'nslm_licenses' );
define( 'NSLM_SECRET', 'NETSEG_AI_2024_' );

// =============================================
// MENU DE ADMINISTRAÇÃO
// =============================================
add_action( 'admin_menu', function () {
    add_menu_page(
        'NETSEG License Manager',
        'NETSEG Licenças',
        'manage_options',
        'netseg-licenses',
        'nslm_admin_page',
        'dashicons-admin-network',
        31
    );
});

// =============================================
// GERAR CHAVE DE LICENÇA (bloqueada ao domínio)
// CHECK = md5(SECRET + payload + domain_normalizado)
// =============================================
function nslm_generate_license_key( $domain ) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $p1 = ''; $p2 = ''; $p3 = '';
    for ( $i = 0; $i < 5; $i++ ) {
        $p1 .= $chars[ random_int( 0, 35 ) ];
        $p2 .= $chars[ random_int( 0, 35 ) ];
        $p3 .= $chars[ random_int( 0, 35 ) ];
    }
    $domain_clean = strtolower( trim( preg_replace( '/^www\./', '', $domain ) ) );
    $check = strtoupper( substr( md5( NSLM_SECRET . $p1 . $p2 . $p3 . $domain_clean ), 0, 4 ) );
    return "NETSEG-{$p1}-{$p2}-{$p3}-{$check}";
}

// Validar chave para um domínio específico
function nslm_validate_key_for_domain( $key, $domain ) {
    $key = strtoupper( trim( $key ) );
    if ( ! preg_match( '/^NETSEG-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{4})$/', $key, $parts ) ) {
        return false;
    }
    $payload = $parts[1] . $parts[2] . $parts[3];
    $domain_clean = strtolower( trim( preg_replace( '/^www\./', '', $domain ) ) );
    $expected = strtoupper( substr( md5( NSLM_SECRET . $payload . $domain_clean ), 0, 4 ) );
    return ( $parts[4] === $expected );
}

// =============================================
// AJAX: GERAR LICENÇA
// =============================================
add_action( 'wp_ajax_nslm_generate', function () {
    check_ajax_referer( 'nslm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Sem permissões.' );
    }

    $client_name  = sanitize_text_field( $_POST['client_name'] ?? '' );
    $dealer_nr    = sanitize_text_field( $_POST['dealer_nr'] ?? '' );
    $email        = sanitize_email( $_POST['email'] ?? '' );
    $phone        = sanitize_text_field( $_POST['phone'] ?? '' );
    $company      = sanitize_text_field( $_POST['company'] ?? '' );
    $domain       = sanitize_text_field( $_POST['domain'] ?? '' );
    $notes        = sanitize_textarea_field( $_POST['notes'] ?? '' );

    if ( empty( $client_name ) || empty( $email ) ) {
        wp_send_json_error( 'Nome do cliente e email são obrigatórios.' );
    }
    if ( empty( $domain ) ) {
        wp_send_json_error( 'Domínio é obrigatório. A chave será bloqueada a este domínio.' );
    }

    $key = nslm_generate_license_key( $domain );

    $license = array(
        'key'              => $key,
        'client_name'      => $client_name,
        'dealer_nr'        => $dealer_nr,
        'email'            => $email,
        'phone'            => $phone,
        'company'          => $company,
        'domain'           => $domain,
        'notes'            => $notes,
        'created_at'       => current_time( 'mysql' ),
        'expires_at'       => date( 'Y-m-d H:i:s', time() + ( 365 * DAY_IN_SECONDS ) ),
        'status'           => 'active',
        'activated'        => false,
        'activated_at'     => '',
        'activated_domain' => '',
    );

    $licenses = get_option( NSLM_OPTION_KEY, array() );
    $licenses[ $key ] = $license;
    update_option( NSLM_OPTION_KEY, $licenses, 'no' );

    wp_send_json_success( $license );
});

// =============================================
// AJAX: VERIFICAR ATIVAÇÃO (chamado pelo Block Cloner)
// =============================================
add_action( 'wp_ajax_nslm_check_activation', function () {
    check_ajax_referer( 'nslm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Sem permissões.' );
    }

    $key = strtoupper( trim( sanitize_text_field( $_POST['license_key'] ?? '' ) ) );
    $licenses = get_option( NSLM_OPTION_KEY, array() );

    if ( ! isset( $licenses[ $key ] ) ) {
        wp_send_json_error( 'Licença não encontrada.' );
    }

    wp_send_json_success( array(
        'activated'        => $licenses[ $key ]['activated'] ?? false,
        'activated_at'     => $licenses[ $key ]['activated_at'] ?? '',
        'activated_domain' => $licenses[ $key ]['activated_domain'] ?? '',
        'domain'           => $licenses[ $key ]['domain'] ?? '',
        'status'           => $licenses[ $key ]['status'] ?? 'active',
    ));
});

// =============================================
// AJAX: MARCAR COMO ATIVADA (manual pelo admin)
// =============================================
add_action( 'wp_ajax_nslm_mark_activated', function () {
    check_ajax_referer( 'nslm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Sem permissões.' );
    }

    $key = strtoupper( trim( sanitize_text_field( $_POST['license_key'] ?? '' ) ) );
    $activated_domain = sanitize_text_field( $_POST['activated_domain'] ?? '' );
    $licenses = get_option( NSLM_OPTION_KEY, array() );

    if ( ! isset( $licenses[ $key ] ) ) {
        wp_send_json_error( 'Licença não encontrada.' );
    }

    $licenses[ $key ]['activated'] = true;
    $licenses[ $key ]['activated_at'] = current_time( 'mysql' );
    $licenses[ $key ]['activated_domain'] = ! empty( $activated_domain ) ? $activated_domain : ( $licenses[ $key ]['domain'] ?? '' );
    update_option( NSLM_OPTION_KEY, $licenses, 'no' );

    wp_send_json_success( 'Licença marcada como ativada.' );
});

// =============================================
// AJAX: REVOGAR LICENÇA
// =============================================
add_action( 'wp_ajax_nslm_revoke', function () {
    check_ajax_referer( 'nslm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Sem permissões.' );
    }

    $key = sanitize_text_field( $_POST['license_key'] ?? '' );
    $licenses = get_option( NSLM_OPTION_KEY, array() );

    if ( ! isset( $licenses[ $key ] ) ) {
        wp_send_json_error( 'Licença não encontrada.' );
    }

    $licenses[ $key ]['status'] = 'revoked';
    update_option( NSLM_OPTION_KEY, $licenses, 'no' );

    wp_send_json_success( 'Licença revogada.' );
});

// =============================================
// AJAX: ELIMINAR LICENÇA
// =============================================
add_action( 'wp_ajax_nslm_delete', function () {
    check_ajax_referer( 'nslm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Sem permissões.' );
    }

    $key = sanitize_text_field( $_POST['license_key'] ?? '' );
    $licenses = get_option( NSLM_OPTION_KEY, array() );

    if ( isset( $licenses[ $key ] ) ) {
        unset( $licenses[ $key ] );
        update_option( NSLM_OPTION_KEY, $licenses, 'no' );
    }

    wp_send_json_success( 'Licença eliminada.' );
});

// =============================================
// PÁGINA DE ADMINISTRAÇÃO
// =============================================
function nslm_admin_page() {
    $nonce = wp_create_nonce( 'nslm_nonce' );
    $licenses = get_option( NSLM_OPTION_KEY, array() );
    if ( ! is_array( $licenses ) ) {
        $licenses = array();
    }
    uasort( $licenses, function( $a, $b ) {
        return strcmp( $b['created_at'] ?? '', $a['created_at'] ?? '' );
    });

    $count_active = 0;
    $count_activated = 0;
    foreach ( $licenses as $lic ) {
        if ( ( $lic['status'] ?? '' ) === 'active' ) $count_active++;
        if ( ! empty( $lic['activated'] ) ) $count_activated++;
    }
    ?>
    <style>
        .nslm-wrap { max-width: 1200px; margin: 20px auto; }
        .nslm-card { background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
        .nslm-stats { display: flex; gap: 16px; margin-bottom: 20px; }
        .nslm-stat { background: #f0f6fc; border: 1px solid #c3c4c7; border-radius: 8px; padding: 16px 24px; text-align: center; flex: 1; }
        .nslm-stat-number { font-size: 28px; font-weight: 900; color: #1d2327; }
        .nslm-stat-label { font-size: 12px; color: #646970; margin-top: 4px; }
        .nslm-stat-active .nslm-stat-number { color: #00a32a; }
        .nslm-stat-used .nslm-stat-number { color: #2271b1; }
        .nslm-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .nslm-form-grid label { display: block; font-weight: 600; margin-bottom: 4px; color: #1d2327; font-size: 13px; }
        .nslm-form-grid input, .nslm-form-grid textarea { width: 100%; padding: 8px 12px; border: 1px solid #8c8f94; border-radius: 4px; font-size: 14px; }
        .nslm-form-grid textarea { min-height: 60px; }
        .nslm-form-full { grid-column: 1 / -1; }
        .nslm-required { color: #d63638; }
        .nslm-domain-note { font-size: 11px; color: #d63638; font-weight: 600; margin-top: 2px; }
        .nslm-btn { display: inline-flex; align-items: center; gap: 6px; padding: 10px 24px; border-radius: 4px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; transition: all 0.2s; }
        .nslm-btn-primary { background: #E32219; color: #fff; }
        .nslm-btn-primary:hover { background: #b81c15; }
        .nslm-key-display { background: #1d2327; color: #00ff41; padding: 16px 24px; border-radius: 8px; font-family: 'Fira Code', monospace; font-size: 20px; text-align: center; letter-spacing: 2px; margin: 16px 0; user-select: all; }
        .nslm-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .nslm-table th { background: #f0f6fc; padding: 10px 12px; text-align: left; font-weight: 600; color: #1d2327; border-bottom: 2px solid #c3c4c7; white-space: nowrap; }
        .nslm-table td { padding: 10px 12px; border-bottom: 1px solid #e0e0e0; color: #646970; }
        .nslm-table tr:hover { background: #f9f9f9; }
        .nslm-status-active { color: #00a32a; font-weight: 600; }
        .nslm-status-revoked { color: #d63638; font-weight: 600; }
        .nslm-status-expired { color: #dba617; font-weight: 600; }
        .nslm-activated-yes { background: #d1fae5; color: #065f46; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .nslm-activated-no { background: #fef3c7; color: #92400e; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .nslm-key-cell { font-family: monospace; font-size: 11px; letter-spacing: 0.3px; color: #1d2327; }
        .nslm-domain-cell { font-family: monospace; font-size: 12px; color: #2271b1; }
        .nslm-actions button { padding: 4px 10px; font-size: 11px; cursor: pointer; border: 1px solid #c3c4c7; border-radius: 3px; background: #fff; margin: 1px 2px; }
        .nslm-actions button.revoke { color: #d63638; border-color: #d63638; }
        .nslm-actions button.delete { color: #8a2424; border-color: #8a2424; }
        .nslm-actions button.copy { color: #2271b1; border-color: #2271b1; }
        .nslm-actions button.mark-active { color: #065f46; border-color: #065f46; }
    </style>

    <div class="nslm-wrap">
        <h1 style="display:flex;align-items:center;gap:10px;">
            <span style="font-size:36px;font-weight:900;color:#E32219;font-family:'Arial Black',Impact,sans-serif;letter-spacing:2px;">NETSEG<span style="color:#1d2327;">.AI</span></span>
            <span style="font-size:16px;color:#646970;margin-left:8px;">License Manager</span>
            <span style="font-size:12px;background:#f0f6fc;padding:4px 10px;border-radius:12px;color:#2271b1;">v<?php echo NSLM_VERSION; ?></span>
        </h1>

        <!-- ESTATÍSTICAS -->
        <div class="nslm-stats">
            <div class="nslm-stat">
                <div class="nslm-stat-number"><?php echo count( $licenses ); ?></div>
                <div class="nslm-stat-label">Total Geradas</div>
            </div>
            <div class="nslm-stat nslm-stat-active">
                <div class="nslm-stat-number"><?php echo $count_active; ?></div>
                <div class="nslm-stat-label">Ativas</div>
            </div>
            <div class="nslm-stat nslm-stat-used">
                <div class="nslm-stat-number"><?php echo $count_activated; ?></div>
                <div class="nslm-stat-label">Ativadas pelo Cliente</div>
            </div>
        </div>

        <!-- GERAR NOVA LICENÇA -->
        <div class="nslm-card">
            <h2 style="margin-top:0;padding-bottom:12px;border-bottom:1px solid #eee;color:#1d2327;">
                <span class="dashicons dashicons-plus-alt2" style="margin-right:6px;"></span>Gerar Nova Licença
            </h2>

            <div class="nslm-form-grid">
                <div>
                    <label for="nslm-client-name">Nome do Cliente <span class="nslm-required">*</span></label>
                    <input type="text" id="nslm-client-name" placeholder="Nome completo do cliente" />
                </div>
                <div>
                    <label for="nslm-dealer-nr">Número de Dealer</label>
                    <input type="text" id="nslm-dealer-nr" placeholder="Ex: DLR-001" />
                </div>
                <div>
                    <label for="nslm-email">Email <span class="nslm-required">*</span></label>
                    <input type="email" id="nslm-email" placeholder="cliente@exemplo.com" />
                </div>
                <div>
                    <label for="nslm-phone">Telefone</label>
                    <input type="text" id="nslm-phone" placeholder="+351 912 345 678" />
                </div>
                <div>
                    <label for="nslm-company">Empresa</label>
                    <input type="text" id="nslm-company" placeholder="Nome da empresa" />
                </div>
                <div>
                    <label for="nslm-domain">Domínio WordPress <span class="nslm-required">*</span></label>
                    <input type="text" id="nslm-domain" placeholder="exemplo.com" />
                    <div class="nslm-domain-note">A chave só funcionará neste domínio!</div>
                </div>
                <div class="nslm-form-full">
                    <label for="nslm-notes">Notas</label>
                    <textarea id="nslm-notes" placeholder="Notas adicionais..."></textarea>
                </div>
            </div>

            <div style="margin-top:16px;display:flex;align-items:center;gap:12px;">
                <button type="button" id="nslm-generate-btn" class="nslm-btn nslm-btn-primary">
                    <span class="dashicons dashicons-admin-network"></span> Gerar Chave de Licença
                </button>
                <span id="nslm-generate-status" style="color:#646970;font-size:13px;"></span>
            </div>

            <div id="nslm-result" style="display:none;">
                <div id="nslm-generated-key" class="nslm-key-display"></div>
                <p style="text-align:center;color:#646970;font-size:13px;">
                    Clique na chave para copiar. Válida por <strong>365 dias</strong>. Bloqueada ao domínio indicado.
                </p>
            </div>
        </div>

        <!-- LICENÇAS EXISTENTES -->
        <div class="nslm-card">
            <h2 style="margin-top:0;padding-bottom:12px;border-bottom:1px solid #eee;color:#1d2327;">
                <span class="dashicons dashicons-list-view" style="margin-right:6px;"></span>Licenças Geradas
                <span style="background:#2271b1;color:#fff;padding:2px 8px;border-radius:10px;font-size:12px;margin-left:6px;"><?php echo count( $licenses ); ?></span>
            </h2>

            <?php if ( empty( $licenses ) ) : ?>
                <p style="color:#646970;font-style:italic;">Nenhuma licença gerada ainda.</p>
            <?php else : ?>
                <div style="overflow-x:auto;">
                <table class="nslm-table">
                    <thead>
                        <tr>
                            <th>Chave</th>
                            <th>Cliente</th>
                            <th>Dealer</th>
                            <th>Email</th>
                            <th>Domínio Bloqueado</th>
                            <th>Ativação</th>
                            <th>Criada</th>
                            <th>Expira</th>
                            <th>Estado</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $licenses as $lic ) :
                            $expired = ( strtotime( $lic['expires_at'] ?? '' ) < time() );
                            $status = $lic['status'] ?? 'active';
                            if ( $status === 'active' && $expired ) $status = 'expired';
                            $status_class = 'nslm-status-' . $status;
                            $status_label = array( 'active' => 'Ativa', 'revoked' => 'Revogada', 'expired' => 'Expirada' );
                            $is_activated = ! empty( $lic['activated'] );
                        ?>
                        <tr>
                            <td class="nslm-key-cell"><?php echo esc_html( $lic['key'] ?? '' ); ?></td>
                            <td><strong><?php echo esc_html( $lic['client_name'] ?? '' ); ?></strong><br><small><?php echo esc_html( $lic['company'] ?? '' ); ?></small></td>
                            <td><?php echo esc_html( $lic['dealer_nr'] ?? '-' ); ?></td>
                            <td><a href="mailto:<?php echo esc_attr( $lic['email'] ?? '' ); ?>"><?php echo esc_html( $lic['email'] ?? '' ); ?></a></td>
                            <td class="nslm-domain-cell"><?php echo esc_html( $lic['domain'] ?? '-' ); ?></td>
                            <td>
                                <?php if ( $is_activated ) : ?>
                                    <span class="nslm-activated-yes">ATIVADA</span>
                                    <?php if ( ! empty( $lic['activated_at'] ) ) : ?>
                                        <br><small style="color:#646970;"><?php echo esc_html( date_i18n( 'd/m/Y H:i', strtotime( $lic['activated_at'] ) ) ); ?></small>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $lic['activated_domain'] ) ) : ?>
                                        <br><small style="color:#2271b1;font-family:monospace;font-size:10px;"><?php echo esc_html( $lic['activated_domain'] ); ?></small>
                                    <?php endif; ?>
                                <?php else : ?>
                                    <span class="nslm-activated-no">NÃO ATIVADA</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $lic['created_at'] ?? '' ) ) ); ?></td>
                            <td><?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $lic['expires_at'] ?? '' ) ) ); ?></td>
                            <td><span class="<?php echo $status_class; ?>"><?php echo $status_label[ $status ] ?? $status; ?></span></td>
                            <td class="nslm-actions">
                                <button class="copy" onclick="navigator.clipboard.writeText('<?php echo esc_js( $lic['key'] ?? '' ); ?>');this.textContent='Copiado!';">Copiar</button>
                                <?php if ( ! $is_activated && $status === 'active' ) : ?>
                                    <button class="mark-active" data-key="<?php echo esc_attr( $lic['key'] ?? '' ); ?>" data-domain="<?php echo esc_attr( $lic['domain'] ?? '' ); ?>">Marcar Ativada</button>
                                <?php endif; ?>
                                <?php if ( $status === 'active' ) : ?>
                                    <button class="revoke" data-key="<?php echo esc_attr( $lic['key'] ?? '' ); ?>">Revogar</button>
                                <?php endif; ?>
                                <button class="delete" data-key="<?php echo esc_attr( $lic['key'] ?? '' ); ?>">Eliminar</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- INFO -->
        <div class="nslm-card" style="background:#f0f6fc;">
            <h3 style="margin-top:0;color:#1d2327;">Como funciona o bloqueio por domínio</h3>
            <ul style="color:#646970;font-size:13px;line-height:1.8;">
                <li>Cada chave é <strong>criptograficamente bloqueada</strong> ao domínio indicado.</li>
                <li>A mesma chave <strong>não funciona</strong> noutro domínio/instalação WordPress.</li>
                <li>Quando o cliente ativa a chave no Block Cloner, o plugin verifica se o domínio corresponde.</li>
                <li>Se o cliente copiar a base de dados para outro site, a licença <strong>deixa de funcionar</strong>.</li>
                <li>Cada chave é válida por <strong>365 dias</strong> a partir da data de criação.</li>
            </ul>
        </div>
    </div>

    <script>
    (function($) {
        'use strict';
        var nonce = '<?php echo esc_js( $nonce ); ?>';

        // Gerar licença
        $('#nslm-generate-btn').on('click', function() {
            var btn = $(this);
            var data = {
                action: 'nslm_generate',
                nonce: nonce,
                client_name: $('#nslm-client-name').val().trim(),
                dealer_nr: $('#nslm-dealer-nr').val().trim(),
                email: $('#nslm-email').val().trim(),
                phone: $('#nslm-phone').val().trim(),
                company: $('#nslm-company').val().trim(),
                domain: $('#nslm-domain').val().trim(),
                notes: $('#nslm-notes').val().trim()
            };

            if (!data.client_name || !data.email) {
                alert('Nome do cliente e email são obrigatórios.');
                return;
            }
            if (!data.domain) {
                alert('Domínio é obrigatório! A chave será bloqueada a este domínio.');
                return;
            }

            btn.prop('disabled', true).text('A gerar...');

            $.ajax({
                url: ajaxurl, method: 'POST', data: data,
                success: function(response) {
                    if (response.success) {
                        var lic = response.data;
                        $('#nslm-generated-key').text(lic.key);
                        $('#nslm-result').slideDown(300);
                        $('#nslm-generate-status').text('Chave gerada para ' + data.domain + '!').css('color', '#00a32a');
                        $('#nslm-client-name,#nslm-dealer-nr,#nslm-email,#nslm-phone,#nslm-company,#nslm-domain,#nslm-notes').val('');
                        $('#nslm-generated-key').off('click').on('click', function() {
                            navigator.clipboard.writeText(lic.key);
                            $('#nslm-generate-status').text('Chave copiada!');
                        });
                        setTimeout(function() { location.reload(); }, 3000);
                    } else {
                        alert('Erro: ' + response.data);
                    }
                },
                complete: function() {
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-network"></span> Gerar Chave de Licença');
                }
            });
        });

        // Marcar como ativada
        $(document).on('click', '.nslm-actions .mark-active', function() {
            var key = $(this).data('key');
            var domain = $(this).data('domain');
            if (!confirm('Marcar a licença ' + key + ' como ativada no domínio ' + domain + '?')) return;
            $.ajax({
                url: ajaxurl, method: 'POST',
                data: { action: 'nslm_mark_activated', nonce: nonce, license_key: key, activated_domain: domain },
                success: function(r) { if (r.success) location.reload(); else alert(r.data); }
            });
        });

        // Revogar
        $(document).on('click', '.nslm-actions .revoke', function() {
            var key = $(this).data('key');
            if (!confirm('Revogar a licença ' + key + '?')) return;
            $.ajax({
                url: ajaxurl, method: 'POST',
                data: { action: 'nslm_revoke', nonce: nonce, license_key: key },
                success: function(r) { if (r.success) location.reload(); else alert(r.data); }
            });
        });

        // Eliminar
        $(document).on('click', '.nslm-actions .delete', function() {
            var key = $(this).data('key');
            if (!confirm('Eliminar permanentemente a licença ' + key + '?')) return;
            $.ajax({
                url: ajaxurl, method: 'POST',
                data: { action: 'nslm_delete', nonce: nonce, license_key: key },
                success: function(r) { if (r.success) location.reload(); else alert(r.data); }
            });
        });

    })(jQuery);
    </script>
    <?php
}
