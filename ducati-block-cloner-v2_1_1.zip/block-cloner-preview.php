<?php
/**
 * Preview Cloner — Motor de renderização de previews do Ducati Block Cloner
 *
 * Ficheiro independente para ser administrado via Code Snippets.
 * O admin.php chama este código via: do_action('blkcloner_preview_css')
 *                                     do_action('blkcloner_preview_html')
 *                                     do_action('blkcloner_preview_js')
 *
 * @package    DucatiBlockCloner
 * @author     Eng. Fernando Condeço - Netseg.ai
 * @copyright  2024-2026 Netseg.ai
 * @version    2.1.1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// =============================================
// 1) CSS do Preview — containers + modal
// =============================================
add_action( 'blkcloner_preview_css', function () {
?>
    .blkcloner-preview {
        border: 2px dashed #c3c4c7;
        border-radius: 8px;
        padding: 0;
        margin-top: 16px;
        min-height: 200px;
        background: #f9f9f9;
        overflow: hidden;
    }
    .blkcloner-preview.has-content {
        border-style: solid;
        border-color: #2271b1;
        background: #fff;
        overflow: hidden;
    }
    .blkcloner-preview iframe {
        width: 100%;
        min-height: 400px;
        border: none;
        display: block;
    }
    .blkcloner-preview-modal {
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        z-index: 999998;
        background: rgba(0,0,0,0.6);
        display: flex; align-items: center; justify-content: center;
    }
    .blkcloner-preview-modal-content {
        background: #fff;
        border-radius: 12px;
        width: 95%; max-width: 1100px; max-height: 90vh;
        overflow: auto;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    }
    .blkcloner-preview-modal-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 16px 20px;
        border-bottom: 1px solid #e0e0e0;
        position: sticky; top: 0; background: #fff; z-index: 1;
        border-radius: 12px 12px 0 0;
    }
    .blkcloner-preview-modal-body {
        padding: 0;
        min-height: 300px;
        overflow: auto;
    }
    .blkcloner-preview-modal-close {
        background: none; border: none;
        font-size: 24px; cursor: pointer; color: #646970;
        padding: 4px 8px; border-radius: 4px;
    }
    .blkcloner-preview-modal-close:hover {
        background: #f0f0f1; color: #d63638;
    }
<?php
});

// =============================================
// 2) HTML — Container de preview
// =============================================
add_action( 'blkcloner_preview_html', function () {
?>
                    <div class="blkcloner-preview" id="blkcloner-preview"></div>
<?php
});

// =============================================
// 3) JavaScript — showResult + preview modal
// =============================================
add_action( 'blkcloner_preview_js', function () {
?>
        // =============================================
        // PREVIEW CLONER — Construir iframe com conteúdo completo
        // Renderiza HTML + CSS + JS (incluindo SpriteSpin 360°)
        // =============================================
        function buildFullPreviewIframe(html, css, js) {
            var hasSpriteSpin = (js && (js.indexOf('spritespin') !== -1 || js.indexOf('SpriteSpin') !== -1))
                || (html && (html.indexOf('moto-viewer') !== -1 || html.indexOf('blk-360-spritespin') !== -1));

            var iframeHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8">' +
                '<meta name="viewport" content="width=1200, initial-scale=1.0">' +
                '<style>' +
                'html, body { margin: 0; padding: 10px; font-family: Arial, sans-serif; background: #fff; }' +
                'body > div { width: 100%; display: flex; flex-direction: column; align-items: center; }' +
                '</style>';

            // jQuery + SpriteSpin se necessário
            if (hasSpriteSpin) {
                iframeHtml += '<script src="https://code.jquery.com/jquery-3.6.0.min.js"><\/script>' +
                    '<script src="https://unpkg.com/spritespin@4.1.0/release/spritespin.js"><\/script>';
            }

            // CSS para imagem 360° proporcional sem corte
            iframeHtml += '<style>' +
                '.moto-container { overflow: hidden !important; aspect-ratio: auto !important; position: relative; min-height: 200px; }' +
                '.moto-container > div:not(.rotation-overlay) { width: 100% !important; max-width: 100% !important; overflow: hidden !important; }' +
                '.spritespin-stage { overflow: hidden !important; }' +
                '.spritespin-stage img { max-width: 100% !important; height: auto !important; display: block; object-fit: contain; }' +
                '.ducati-lisboa-360-wrapper { overflow: visible !important; }' +
                '.rotation-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; pointer-events: none; opacity: 0; visibility: hidden; transition: opacity 0.4s ease-in-out; display: flex; align-items: center; justify-content: center; }' +
                '.rotation-overlay.visible { opacity: 1; visibility: visible; }' +
                '.drag-indicator { background: rgba(0,0,0,0.3); width: 70px; height: 70px; border-radius: 50%; border: 1px solid rgba(255,255,255,0.4); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 9999; }' +
                '.drag-indicator svg { width: 45px; height: 45px; filter: drop-shadow(0px 0px 3px rgba(0,0,0,0.8)); }' +
                '.ducati-controls-area { position: relative; z-index: 9999; }' +
                '.color-btn { position: relative; z-index: 9999; }' +
                '</style>';

            // CSS original
            if (css) {
                iframeHtml += '<style>' + css + '</style>';
            }

            iframeHtml += '</head><body>' +
                '<div style="width:100%;max-width:1100px;margin:0 auto;">' +
                (html || '') +
                '</div>';

            // JS
            if (js) {
                if (hasSpriteSpin) {
                    iframeHtml += '<script>var $=jQuery;' + js + '<\/script>';
                } else {
                    iframeHtml += '<script>' + js + '<\/script>';
                }
            }

            iframeHtml += '</body></html>';
            return iframeHtml;
        }

        // =============================================
        // PREVIEW CLONER — Auto-ajustar altura do iframe
        // =============================================
        function autoResizeIframe(iframe) {
            try {
                var adjustH = function() {
                    var h = iframe.contentDocument.body.scrollHeight;
                    iframe.style.height = Math.max(h + 60, 400) + 'px';
                };
                adjustH();
                var imgs = iframe.contentDocument.querySelectorAll('img');
                var loaded = 0;
                if (imgs.length > 0) {
                    imgs.forEach(function(img) {
                        if (img.complete) { loaded++; if (loaded >= imgs.length) adjustH(); }
                        else { img.onload = img.onerror = function() { loaded++; if (loaded >= imgs.length) adjustH(); }; }
                    });
                }
                setTimeout(adjustH, 3000);
            } catch(e) {}
        }

        // =============================================
        // PREVIEW CLONER — showResult()
        // Renderiza o bloco completo com 360° funcional
        // =============================================
        function showResult(data) {
            var previewContainer = $('#blkcloner-preview');
            previewContainer.addClass('has-content');

            // Construir iframe com conteúdo completo (HTML + CSS + JS + SpriteSpin)
            var iframeContent = buildFullPreviewIframe(data.html || '', data.css || '', data.js || '');

            previewContainer.html('<iframe style="width:100%;min-height:400px;border:none;display:block;" sandbox="allow-scripts allow-same-origin"></iframe>');
            var iframe = previewContainer.find('iframe')[0];
            var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            iframeDoc.open();
            iframeDoc.write(iframeContent);
            iframeDoc.close();
            iframe.onload = function() { autoResizeIframe(iframe); };

            // Code tabs
            $('#blkcloner-html-code').text(data.html || 'Sem HTML');
            $('#blkcloner-css-code').text(data.css || 'Sem CSS');
            $('#blkcloner-js-code').text(data.js || 'Sem JavaScript');

            // Images tab — galeria com seleção para remoção
            var imagesHtml = '';
            if (data.images && data.images.length > 0) {
                imagesHtml += '<div style="margin-bottom:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">' +
                    '<button type="button" id="blkcloner-select-all-imgs" class="blkcloner-btn blkcloner-btn-secondary" style="font-size:12px;padding:4px 10px;">☐ Selecionar Todas</button>' +
                    '<button type="button" id="blkcloner-remove-selected-imgs" class="blkcloner-btn" style="font-size:12px;padding:4px 10px;background:#d63638;color:#fff;display:none;">🗑 Remover Selecionadas</button>' +
                    '<span id="blkcloner-img-sel-count" style="font-size:12px;color:#646970;"></span>' +
                    '</div>';
                data.images.forEach(function(img, idx) {
                    var src = img.local_url || img.original;
                    imagesHtml += '<div class="blkcloner-img-item" data-idx="' + idx + '" style="border:1px solid #e0e0e0;border-radius:6px;overflow:hidden;background:#f9f9f9;position:relative;">' +
                        '<label style="position:absolute;top:4px;left:4px;z-index:2;cursor:pointer;background:rgba(255,255,255,0.85);border-radius:3px;padding:1px 4px;">' +
                        '<input type="checkbox" class="blkcloner-img-check" data-idx="' + idx + '" style="cursor:pointer;" />' +
                        '</label>' +
                        '<img src="' + src + '" alt="Imagem ' + (idx+1) + '" loading="lazy" style="width:100%;height:120px;object-fit:contain;display:block;background:#fff;" />' +
                        '<div style="padding:6px 8px;font-size:10px;color:#646970;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + (img.original || '') + '">' +
                        (img.cached ? '✓ ' : '') + (idx+1) + '/' + data.images.length +
                        '</div></div>';
                });
            } else {
                imagesHtml = '<div class="blkcloner-notice blkcloner-notice-info">Nenhuma imagem encontrada no bloco.</div>';
            }
            $('#blkcloner-images-grid').html(imagesHtml);

            // Eventos de seleção/remoção de imagens
            (function initImageRemoval() {
                var allSelected = false;

                function updateCount() {
                    var checked = $('.blkcloner-img-check:checked').length;
                    var total = $('.blkcloner-img-check').length;
                    if (checked > 0) {
                        $('#blkcloner-remove-selected-imgs').show();
                        $('#blkcloner-img-sel-count').text(checked + ' de ' + total + ' selecionada(s)');
                    } else {
                        $('#blkcloner-remove-selected-imgs').hide();
                        $('#blkcloner-img-sel-count').text('');
                    }
                }

                $(document).off('click.blkImgSel').on('click.blkImgSel', '#blkcloner-select-all-imgs', function() {
                    allSelected = !allSelected;
                    $('.blkcloner-img-check').prop('checked', allSelected);
                    $(this).html(allSelected ? '☑ Desselecionar Todas' : '☐ Selecionar Todas');
                    updateCount();
                });

                $(document).off('change.blkImgChk').on('change.blkImgChk', '.blkcloner-img-check', function() {
                    updateCount();
                    // Marcar visualmente
                    var item = $(this).closest('.blkcloner-img-item');
                    if ($(this).is(':checked')) {
                        item.css({ 'opacity': '0.4', 'border-color': '#d63638' });
                    } else {
                        item.css({ 'opacity': '1', 'border-color': '#e0e0e0' });
                    }
                });

                $(document).off('click.blkImgRm').on('click.blkImgRm', '#blkcloner-remove-selected-imgs', function() {
                    var toRemove = [];
                    $('.blkcloner-img-check:checked').each(function() {
                        toRemove.push(parseInt($(this).data('idx')));
                    });
                    if (toRemove.length === 0) return;
                    if (!confirm('Remover ' + toRemove.length + ' imagem(ns)? Isto também as remove do 360° se aplicável.')) return;

                    // Remover dos dados em memória (ordenar decrescente para não desalinhar índices)
                    toRemove.sort(function(a,b) { return b - a; });
                    var removedUrls = [];
                    toRemove.forEach(function(idx) {
                        if (currentData.images && currentData.images[idx]) {
                            removedUrls.push(currentData.images[idx].original || '');
                            removedUrls.push(currentData.images[idx].local_url || '');
                            currentData.images.splice(idx, 1);
                        }
                    });

                    // Remover URLs do JS (bikeData 360°) para evitar frames vazios
                    if (currentData.js) {
                        removedUrls.forEach(function(url) {
                            if (url) {
                                // Remover a entrada "url" do array JS (com e sem trailing comma)
                                var escaped = url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                                currentData.js = currentData.js.replace(new RegExp('\\s*"' + escaped + '"\\s*,?', 'g'), '');
                                // Versão com barras escaped (JSON)
                                var escapedSlash = url.replace(/\//g, '\\/').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                                currentData.js = currentData.js.replace(new RegExp('\\s*"' + escapedSlash + '"\\s*,?', 'g'), '');
                            }
                        });
                        // Limpar trailing commas em arrays: ,] → ]
                        currentData.js = currentData.js.replace(/,\s*\]/g, ']');
                    }

                    // Remover URLs do HTML (src= e data-src= e background-image)
                    if (currentData.html) {
                        removedUrls.forEach(function(url) {
                            if (url) {
                                currentData.html = currentData.html.split(url).join('');
                            }
                        });
                    }

                    // Re-renderizar preview e grelha
                    showResult(currentData);
                    toast(toRemove.length + ' imagem(ns) removida(s) com sucesso.', 'success');
                });
            })();

            $('#blkcloner-result').slideDown(300);

            // Populate post-extraction dimension controls from detected data
            (function updatePostDims() {
                var containerW = $('#blkcloner-dim-width').val() || '1100px';
                var spriteW = parseInt($('#blkcloner-dim-sprite-w').val()) || 1920;
                var spriteH = parseInt($('#blkcloner-dim-sprite-h').val()) || 1080;

                // Auto-detect from first image
                if (data.images && data.images.length > 0) {
                    var probeImg = new Image();
                    probeImg.onload = function() {
                        if (probeImg.naturalWidth > 0) {
                            spriteW = probeImg.naturalWidth;
                            spriteH = probeImg.naturalHeight;
                            $('#blkcloner-post-sprite-w').val(spriteW);
                            $('#blkcloner-post-sprite-w-slider').val(Math.min(spriteW, 4000));
                            $('#blkcloner-post-sprite-w-val').text(spriteW + 'px');
                            $('#blkcloner-post-sprite-h').val(spriteH);
                            $('#blkcloner-post-sprite-h-slider').val(Math.min(spriteH, 4000));
                            $('#blkcloner-post-sprite-h-val').text(spriteH + 'px');
                            $('#blkcloner-dim-sprite-w').val(spriteW);
                            $('#blkcloner-dim-sprite-h').val(spriteH);
                        }
                    };
                    probeImg.src = data.images[0].local_url || data.images[0].original;
                }

                var containerPx = parseInt(containerW) || 1100;
                $('#blkcloner-post-container-w').val(containerW);
                $('#blkcloner-post-container-w-slider').val(Math.min(containerPx, 1920));
                $('#blkcloner-post-container-w-val').text(containerW);
                $('#blkcloner-post-sprite-w').val(spriteW);
                $('#blkcloner-post-sprite-w-slider').val(Math.min(spriteW, 4000));
                $('#blkcloner-post-sprite-w-val').text(spriteW + 'px');
                $('#blkcloner-post-sprite-h').val(spriteH);
                $('#blkcloner-post-sprite-h-slider').val(Math.min(spriteH, 4000));
                $('#blkcloner-post-sprite-h-val').text(spriteH + 'px');
            })();
        }

        // =============================================
        // PREVIEW CLONER — Modal de preview (blocos guardados)
        // =============================================
        $(document).on('click', '.blkcloner-preview-block', function() {
            var btn = $(this);
            var id = btn.attr('data-id');
            var name = btn.closest('.blkcloner-saved-item').find('h4').text();

            btn.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: 'blkcloner_preview', nonce: nonce, block_id: id },
                success: function(response) {
                    if (response.success) {
                        var d = response.data;

                        // Construir iframe com conteúdo completo
                        var iframeContent = buildFullPreviewIframe(d.html || '', d.css || '', d.js || '');

                        var modal = $(
                            '<div class="blkcloner-preview-modal">' +
                                '<div class="blkcloner-preview-modal-content">' +
                                    '<div class="blkcloner-preview-modal-header">' +
                                        '<h3 style="margin:0;">' + $('<span>').text(name).html() + '</h3>' +
                                        '<button class="blkcloner-preview-modal-close" title="Fechar">&times;</button>' +
                                    '</div>' +
                                    '<div class="blkcloner-preview-modal-body" style="padding:0;min-height:400px;">' +
                                        '<iframe class="blkcloner-preview-iframe" style="width:100%;min-height:400px;border:none;display:block;" sandbox="allow-scripts allow-same-origin"></iframe>' +
                                    '</div>' +
                                '</div>' +
                            '</div>'
                        );
                        $('body').append(modal);

                        var iframe = modal.find('.blkcloner-preview-iframe')[0];
                        var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                        iframeDoc.open();
                        iframeDoc.write(iframeContent);
                        iframeDoc.close();
                        iframe.onload = function() { autoResizeIframe(iframe); };

                        modal.on('click', '.blkcloner-preview-modal-close', function() { modal.remove(); });
                        modal.on('click', function(e) { if ($(e.target).hasClass('blkcloner-preview-modal')) modal.remove(); });
                        $(document).on('keydown.blkmodal', function(e) { if (e.key === 'Escape') { modal.remove(); $(document).off('keydown.blkmodal'); } });
                    } else {
                        toast('Erro: ' + response.data, 'error');
                    }
                },
                error: function() { toast('Erro ao carregar preview.', 'error'); },
                complete: function() { btn.prop('disabled', false); }
            });
        });
<?php
});
