<?php
/**
 * Ducati Block Cloner - Shortcode para renderizar blocos clonados
 *
 * @package    DucatiBlockCloner
 * @author     Eng. Fernando Condeço - Netseg.ai
 * @copyright  2024-2026 Netseg.ai
 * @version    2.1.1
 */

// Impedir acesso direto
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// =============================================
// CONSTANTES (protegidas contra redefinição)
// =============================================
if ( ! defined( 'BLKCLONER_OPTION_KEY' ) ) {
    define( 'BLKCLONER_OPTION_KEY', 'blkcloner_saved_blocks' );
}
if ( ! defined( 'BLKCLONER_CACHE_URL' ) ) {
    define( 'BLKCLONER_CACHE_URL', content_url( 'cache/block-cloner/' ) );
}

// =============================================
// FRONTEND ENQUEUE + ELEMENTOR COMPATIBILITY
// =============================================

/**
 * Enqueue scripts on frontend pages that contain Block Cloner shortcodes.
 * Ensures jQuery is available even when page caching serves pre-rendered HTML
 * that bypasses shortcode-time wp_enqueue_script() calls.
 */
add_action( 'wp_enqueue_scripts', function () {
    global $post;
    // Fallback: na front page estática com cache, $post pode ser null
    if ( ! is_a( $post, 'WP_Post' ) ) {
        $post = get_queried_object();
        if ( ! is_a( $post, 'WP_Post' ) ) {
            // Último fallback: verificar page_on_front
            $front_id = (int) get_option( 'page_on_front' );
            if ( $front_id > 0 ) {
                $post = get_post( $front_id );
            }
            if ( ! is_a( $post, 'WP_Post' ) ) {
                return;
            }
        }
    }
    $content        = $post->post_content ?? '';
    $elementor_data = get_post_meta( $post->ID, '_elementor_data', true );
    $has_shortcode  = ( has_shortcode( $content, 'cloned_block' )
        || has_shortcode( $content, 'ducati_360' )
        || has_shortcode( $content, 'blk-360-spritespin-render' )
        || ( ! empty( $elementor_data )
            && ( strpos( $elementor_data, 'cloned_block' ) !== false
                || strpos( $elementor_data, 'ducati_360' ) !== false
                || strpos( $elementor_data, 'blk-360-spritespin' ) !== false
                || strpos( $elementor_data, 'cloned_block_hero' ) !== false ) ) );
    if ( $has_shortcode ) {
        wp_enqueue_script( 'jquery' );
    }
});

/**
 * Output CSS on frontend to guarantee visibility of Block Cloner containers.
 * Counteracts Elementor entrance animations (.elementor-invisible),
 * lazy-loading wrappers, and theme CSS that may hide shortcode content.
 */
add_action( 'wp_head', function () {
    if ( is_admin() ) {
        return;
    }
    global $post;
    // Fallback: na front page estática com cache, $post pode ser null
    if ( ! is_a( $post, 'WP_Post' ) ) {
        $post = get_queried_object();
        if ( ! is_a( $post, 'WP_Post' ) ) {
            $front_id = (int) get_option( 'page_on_front' );
            if ( $front_id > 0 ) {
                $post = get_post( $front_id );
            }
            if ( ! is_a( $post, 'WP_Post' ) ) {
                return;
            }
        }
    }
    $content        = $post->post_content ?? '';
    $elementor_data = get_post_meta( $post->ID, '_elementor_data', true );
    $has_shortcode  = ( strpos( $content, 'cloned_block' ) !== false
        || strpos( $content, 'ducati_360' ) !== false
        || ( ! empty( $elementor_data )
            && ( strpos( $elementor_data, 'cloned_block' ) !== false
                || strpos( $elementor_data, 'ducati_360' ) !== false
                || strpos( $elementor_data, 'cloned_block_hero' ) !== false ) ) );
    if ( ! $has_shortcode ) {
        return;
    }
    ?>
    <style id="blkcloner-frontend-compat">
    /* Shortcode widget genérico */
    .elementor-shortcode { overflow: visible !important; }
    .elementor-widget-shortcode .elementor-widget-container { overflow: visible !important; }
    .elementor-widget-shortcode iframe[id*="blkcloner-"] { visibility: visible !important; opacity: 1 !important; display: block !important; }
    /* Widgets custom Netseg: Block Cloner + Hero */
    .elementor-widget-cloned_block .elementor-widget-container,
    .elementor-widget-cloned_block_hero .elementor-widget-container { overflow: visible !important; }
    .elementor-widget-cloned_block iframe[id*="blkcloner-"],
    .elementor-widget-cloned_block_hero iframe[id*="blkcloner-"] { visibility: visible !important; opacity: 1 !important; display: block !important; min-height: 300px !important; }
    /* Elementor entrance animations — forçar visibilidade */
    .elementor-invisible .blkcloner-block,
    .elementor-invisible iframe[id*="blkcloner-"] { visibility: visible !important; opacity: 1 !important; }
    .elementor-widget-cloned_block.elementor-invisible .elementor-widget-container,
    .elementor-widget-cloned_block_hero.elementor-invisible .elementor-widget-container { visibility: visible !important; opacity: 1 !important; }
    /* Front page: garantir que iframes não ficam com height:0 */
    iframe[id*="blkcloner-"] { min-height: 300px; }
    .blkcloner-360-wrap { overflow: visible !important; min-height: 300px !important; }
    .blkcloner-360-wrap iframe { visibility: visible !important; opacity: 1 !important; display: block !important; min-height: 400px !important; }
    </style>
    <?php
}, 999 );

/**
 * Fallback initialization in wp_footer for Block Cloner iframes.
 * Catches iframes that were not initialized because inline scripts
 * were deferred by caching/optimization plugins (WP Rocket, LiteSpeed,
 * Autoptimize, Cloudflare Rocket Loader, etc.).
 *
 * The global window._blkPending map is populated by each shortcode's
 * inline script with the iframe init function.
 */
add_action( 'wp_footer', function () {
    if ( is_admin() ) {
        return;
    }
    // Sempre injetar o fallback se houver iframes pendentes OU se estamos numa página com widgets Elementor
    // (widgets custom não definem $GLOBALS['blkcloner_has_frontend_iframe'] se o shortcode não foi chamado via do_shortcode)
    ?>
    <script data-cfasync="false" data-no-lazy="1" data-no-optimize="1">
    (function(){
        function _blkRunPending(){
            if(!window._blkPending)return;
            for(var k in window._blkPending){
                if(window._blkPending.hasOwnProperty(k)){try{window._blkPending[k]();}catch(e){}}
            }
        }
        if(document.readyState==="complete"){setTimeout(_blkRunPending,300);}
        else{window.addEventListener("load",function(){setTimeout(_blkRunPending,300);});}
        document.addEventListener("DOMContentLoaded",function(){
            setTimeout(_blkRunPending,200);
            if(window.jQuery){
                jQuery(window).on("elementor/frontend/init",function(){setTimeout(_blkRunPending,500);});
            }
        });
    })();
    </script>
    <?php
}, 99 );

// =============================================
// SISTEMA DE LICENCIAMENTO
// =============================================
if ( ! function_exists( 'blkcloner_is_licensed' ) ) :
function blkcloner_is_licensed() {
    $license = get_option( 'blkcloner_license', array() );
    if ( empty( $license['key'] ) || empty( $license['activated_at'] ) ) {
        return false;
    }
    // Verificar expiração (365 dias)
    $activated = strtotime( $license['activated_at'] );
    if ( ! $activated ) {
        return false;
    }
    $expires = $activated + ( 365 * DAY_IN_SECONDS );
    if ( time() > $expires ) {
        return false;
    }
    // Verificar se o domínio atual corresponde ao domínio de ativação
    $current_domain = strtolower( preg_replace( '/^www\./', '', wp_parse_url( home_url(), PHP_URL_HOST ) ) );
    $stored_domain = strtolower( preg_replace( '/^www\./', '', $license['domain'] ?? '' ) );
    if ( $current_domain !== $stored_domain ) {
        return false;
    }
    return blkcloner_validate_license_key( $license['key'] );
}
endif;

if ( ! function_exists( 'blkcloner_validate_license_key' ) ) :
function blkcloner_validate_license_key( $key ) {
    $key = strtoupper( trim( $key ) );
    if ( ! preg_match( '/^NETSEG-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{4})$/', $key, $parts ) ) {
        return false;
    }
    $payload = $parts[1] . $parts[2] . $parts[3];
    // Validar com o domínio atual (chave bloqueada ao domínio)
    $domain = strtolower( preg_replace( '/^www\./', '', wp_parse_url( home_url(), PHP_URL_HOST ) ) );
    $expected_check = strtoupper( substr( md5( 'NETSEG_AI_2024_' . $payload . $domain ), 0, 4 ) );
    return ( $parts[4] === $expected_check );
}
endif;

// AJAX: Ativar licença
add_action( 'wp_ajax_blkcloner_activate_license', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }
    $key = strtoupper( trim( sanitize_text_field( isset( $_POST['license_key'] ) ? $_POST['license_key'] : '' ) ) );
    if ( empty( $key ) ) {
        wp_send_json_error( 'Chave de licença em falta.' );
    }
    if ( ! blkcloner_validate_license_key( $key ) ) {
        wp_send_json_error( 'Chave de licença inválida ou não corresponde a este domínio.' );
    }
    $domain = strtolower( preg_replace( '/^www\./', '', wp_parse_url( home_url(), PHP_URL_HOST ) ) );
    update_option( 'blkcloner_license', array(
        'key'          => $key,
        'activated_at' => current_time( 'mysql' ),
        'domain'       => $domain,
    ));
    wp_send_json_success( 'Licença ativada com sucesso para ' . $domain . '! Válida por 365 dias.' );
});

// AJAX: Remover licença
add_action( 'wp_ajax_blkcloner_deactivate_license', function () {
    check_ajax_referer( 'blkcloner_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permissões insuficientes.' );
    }
    delete_option( 'blkcloner_license' );
    wp_send_json_success( 'Licença removida.' );
});

// =============================================
// HELPER: Scope CSS selectors with wrapper ID
// =============================================
if ( ! function_exists( 'blkcloner_scope_css' ) ) :
function blkcloner_scope_css( $css, $wrapper_id ) {
    if ( empty( trim( $css ) ) ) {
        return '';
    }

    // Pre-clean: remove @import and @charset (global rules that can't be scoped)
    $css = preg_replace( '/@import\s+[^;]+;/i', '', $css );
    $css = preg_replace( '/@charset\s+[^;]+;/i', '', $css );

    /**
     * Helper: extract the brace-matched body starting at position $start
     * (just after the opening {). Returns [ body_string, position_after_closing_} ].
     */
    $extract_body = function( $css, $start, $len ) {
        $depth = 1;
        $j = $start;
        while ( $j < $len && $depth > 0 ) {
            if ( $css[ $j ] === '{' ) $depth++;
            if ( $css[ $j ] === '}' ) $depth--;
            $j++;
        }
        // body is everything between { and matching }
        return array( substr( $css, $start, $j - $start - 1 ), $j );
    };

    /**
     * Recursive scoping function — handles @media nesting.
     */
    $scope_block = function( $css, $wrapper_id ) use ( &$scope_block, $extract_body ) {
        $result = '';
        $len    = strlen( $css );
        $i      = 0;

        while ( $i < $len ) {
            // Skip whitespace
            while ( $i < $len && ctype_space( $css[ $i ] ) ) {
                $result .= $css[ $i ];
                $i++;
            }
            if ( $i >= $len ) break;

            // Find selector up to {
            $brace_pos = strpos( $css, '{', $i );
            if ( $brace_pos === false ) {
                // No more rules — append rest (orphan text)
                $result .= substr( $css, $i );
                break;
            }
            $selector_block = substr( $css, $i, $brace_pos - $i );
            $i = $brace_pos + 1;

            // Extract the full body (handles nested braces)
            list( $body, $i ) = $extract_body( $css, $i, $len );

            $trimmed_sel = trim( $selector_block );

            // ---- @-rules ----
            if ( preg_match( '/^\s*@/', $trimmed_sel ) ) {
                // @keyframes: pass through entirely (don't scope inner stops)
                if ( preg_match( '/@(-webkit-|-moz-)?keyframes/i', $trimmed_sel ) ) {
                    $result .= $selector_block . '{' . $body . '}';
                    continue;
                }
                // @font-face: pass through verbatim (declarations, not selectors)
                if ( preg_match( '/@font-face/i', $trimmed_sel ) ) {
                    $result .= $selector_block . '{' . $body . '}';
                    continue;
                }
                // @media / @supports / @layer etc.: recurse into body to scope inner rules
                $scoped_inner = $scope_block( $body, $wrapper_id );
                if ( ! empty( trim( $scoped_inner ) ) ) {
                    $result .= $selector_block . '{' . $scoped_inner . '}';
                }
                continue;
            }

            // ---- Normal rule: scope selector, copy body verbatim ----

            // Keyframe stops (from, to, percentages) — safety fallback
            if ( preg_match( '/^(from|to|\d+%)/', $trimmed_sel ) ) {
                $result .= $selector_block . '{' . $body . '}';
                continue;
            }

            // Split comma-separated selectors and prefix each
            $selectors = explode( ',', $selector_block );
            $prefixed  = array();
            foreach ( $selectors as $sel ) {
                $sel = trim( $sel );
                if ( empty( $sel ) ) continue;

                // Remap standalone global selectors to wrapper (preserve CSS custom properties)
                $sel_lower = strtolower( $sel );
                if ( in_array( $sel_lower, array( ':root', 'html', 'body' ), true ) ) {
                    $prefixed[] = '#' . $wrapper_id;
                    continue;
                }
                // Skip universal selector (too broad)
                if ( $sel_lower === '*' ) {
                    continue;
                }
                // Strip html/body/:root prefix from compound selectors
                $sel = preg_replace( '/^(html|body|:root)\s+/i', '', $sel );
                if ( empty( trim( $sel ) ) ) continue;

                $prefixed[] = '#' . $wrapper_id . ' ' . $sel;
            }
            if ( ! empty( $prefixed ) ) {
                $result .= implode( ', ', $prefixed ) . ' {' . $body . '}';
            }
            // If all selectors were dangerous — rule is silently dropped
        }
        return $result;
    };

    return $scope_block( $css, $wrapper_id );
}
endif;

// =============================================
// HELPER: Filter CSS to keep only rules relevant to block HTML
// =============================================
if ( ! function_exists( 'blkcloner_filter_relevant_css' ) ) :
/**
 * Filters CSS to keep only rules whose selectors match classes/IDs found in the block HTML.
 * Dramatically reduces CSS size when source site's full stylesheet was captured.
 *
 * @param string $css  Raw CSS to filter.
 * @param string $html Block HTML content.
 * @return string Filtered CSS containing only relevant rules.
 */
function blkcloner_filter_relevant_css( $css, $html ) {
    if ( empty( trim( $css ) ) || empty( trim( $html ) ) ) {
        return $css;
    }

    // ---- Extract all class names from HTML ----
    $classes = array();
    if ( preg_match_all( '/class=["\']([^"\']+)["\']/i', $html, $class_matches ) ) {
        foreach ( $class_matches[1] as $class_list ) {
            foreach ( preg_split( '/\s+/', trim( $class_list ) ) as $cls ) {
                $cls = trim( $cls );
                if ( ! empty( $cls ) ) {
                    $classes[ strtolower( $cls ) ] = true;
                }
            }
        }
    }

    // ---- Extract all IDs from HTML ----
    $ids = array();
    if ( preg_match_all( '/id=["\']([^"\']+)["\']/i', $html, $id_matches ) ) {
        foreach ( $id_matches[1] as $id ) {
            $ids[ strtolower( trim( $id ) ) ] = true;
        }
    }

    if ( empty( $classes ) && empty( $ids ) ) {
        return $css;
    }

    // Patterns that are always relevant (SpriteSpin, controls, etc.)
    $always_keep = array(
        'spritespin', 'sprite-spin', 'moto-viewer', 'moto-container',
        'rotation-overlay', 'drag-indicator', 'ducati', 'color-btn',
        'color-name', 'controls-area', 'blkcloner',
    );

    // Pre-clean global directives
    $css = preg_replace( '/@import\s+[^;]+;/i', '', $css );
    $css = preg_replace( '/@charset\s+[^;]+;/i', '', $css );

    // ---- Brace-matching body extractor ----
    $extract_body = function( $css, $start, $len ) {
        $depth = 1;
        $j     = $start;
        while ( $j < $len && $depth > 0 ) {
            if ( $css[ $j ] === '{' ) $depth++;
            if ( $css[ $j ] === '}' ) $depth--;
            $j++;
        }
        return array( substr( $css, $start, $j - $start - 1 ), $j );
    };

    /**
     * Check if a selector string references any of the known classes/IDs.
     */
    $is_selector_relevant = function( $selector ) use ( $classes, $ids, $always_keep ) {
        $sel_lower = strtolower( $selector );

        // Always-keep patterns
        foreach ( $always_keep as $pat ) {
            if ( strpos( $sel_lower, $pat ) !== false ) {
                return true;
            }
        }

        // Check classes: look for .classname in selector
        foreach ( $classes as $cls => $v ) {
            // Match .classname followed by non-alphanumeric or end of string
            if ( preg_match( '/\.' . preg_quote( $cls, '/' ) . '(?![a-z0-9_-])/i', $sel_lower ) ) {
                return true;
            }
        }

        // Check IDs: look for #idname in selector
        foreach ( $ids as $id => $v ) {
            if ( preg_match( '/#' . preg_quote( $id, '/' ) . '(?![a-z0-9_-])/i', $sel_lower ) ) {
                return true;
            }
        }

        return false;
    };

    // ---- Recursive filter ----
    $filter_block = function( $css ) use ( &$filter_block, $extract_body, $is_selector_relevant ) {
        $result = '';
        $len    = strlen( $css );
        $i      = 0;

        while ( $i < $len ) {
            // Skip whitespace
            while ( $i < $len && ctype_space( $css[ $i ] ) ) {
                $i++;
            }
            if ( $i >= $len ) break;

            $brace_pos = strpos( $css, '{', $i );
            if ( $brace_pos === false ) {
                break;
            }
            $selector_block = substr( $css, $i, $brace_pos - $i );
            $i = $brace_pos + 1;

            list( $body, $i ) = $extract_body( $css, $i, $len );

            $trimmed_sel = trim( $selector_block );

            // ---- @-rules ----
            if ( preg_match( '/^\s*@/', $trimmed_sel ) ) {
                // Always keep @keyframes and @font-face
                if ( preg_match( '/@(-webkit-|-moz-)?keyframes/i', $trimmed_sel ) ||
                     preg_match( '/@font-face/i', $trimmed_sel ) ) {
                    $result .= $trimmed_sel . '{' . $body . '}';
                    continue;
                }
                // @media / @supports: filter inner rules recursively
                $filtered_inner = $filter_block( $body );
                if ( ! empty( trim( $filtered_inner ) ) ) {
                    $result .= $trimmed_sel . '{' . $filtered_inner . '}';
                }
                continue;
            }

            // :root / html / body — keep only if they contain CSS custom properties
            $sel_lower = strtolower( $trimmed_sel );
            if ( in_array( $sel_lower, array( ':root', 'html', 'body' ), true ) ) {
                if ( strpos( $body, '--' ) !== false ) {
                    $result .= $trimmed_sel . '{' . $body . '}';
                }
                continue;
            }

            // Check comma-separated selectors — keep the rule if ANY selector is relevant
            $selectors    = explode( ',', $selector_block );
            $has_relevant = false;
            foreach ( $selectors as $sel ) {
                if ( $is_selector_relevant( trim( $sel ) ) ) {
                    $has_relevant = true;
                    break;
                }
            }

            if ( $has_relevant ) {
                $result .= $trimmed_sel . '{' . $body . '}';
            }
        }
        return $result;
    };

    return $filter_block( $css );
}
endif;

// =============================================
// HELPER: CSS para posicionamento dos controlos
// =============================================
if ( ! function_exists( 'blkcloner_controls_position_css' ) ) :
function blkcloner_controls_position_css( $config ) {
    $pos = ! empty( $config['controls_position'] ) ? $config['controls_position'] : 'bottom';
    $ox  = isset( $config['controls_offset_x'] ) ? intval( $config['controls_offset_x'] ) : 0;
    $oy  = isset( $config['controls_offset_y'] ) ? intval( $config['controls_offset_y'] ) : 0;
    $css = '';
    switch ( $pos ) {
        case 'top':
            $css = 'order: -1; margin-bottom: -20px; margin-top: 0; padding-bottom: 0; padding-top: 40px;';
            break;
        case 'left':
            $css = 'position: absolute; left: 0; top: 50%; transform: translateY(-50%); flex-direction: column;';
            break;
        case 'right':
            $css = 'position: absolute; right: 0; top: 50%; transform: translateY(-50%); flex-direction: column;';
            break;
    }
    if ( $ox || $oy ) {
        $css .= " margin-left: {$ox}px; margin-top: {$oy}px;";
    }
    return $css;
}
endif;

// =============================================
// GERAR JS LIMPO PARA 360° (evita "too much recursion")
// =============================================
if ( ! function_exists( 'blkcloner_generate_clean_360_js' ) ) :
/**
 * Extrai bikeData do JS guardado e gera JS limpo para o iframe 360°.
 * O JS raw scraped do site original contém resize loops, jQuery-migrate conflicts,
 * e event handlers cascading que causam "too much recursion" no jQuery.
 * Esta função extrai apenas os dados necessários e gera código limpo.
 *
 * @param string $js_raw   O JS guardado (scraped do site original).
 * @param string $html     O HTML do bloco.
 * @param array  $block    Os dados do bloco guardado.
 * @param string $wrapper_id O ID do wrapper para selectores scoped.
 * @return string JS limpo para o iframe, ou string vazia se não for 360°.
 */
function blkcloner_generate_clean_360_js( $js_raw, $html, $block, $wrapper_id ) {
    // Verificar se é conteúdo 360° com bikeData
    $has_bike_data = preg_match( '/(?:var|const|let)\s+bikeData\s*=\s*(\{.+?\});/s', $js_raw, $bd_match );
    if ( ! $has_bike_data ) {
        return ''; // Não é 360° com bikeData — devolver vazio para usar fallback
    }

    $bike_data_json = $bd_match[1];

    // Extrair viewer ID do HTML
    $viewer_id = '';
    if ( preg_match( '/id="(moto-viewer[^"]*)"/', $html, $vm ) ) {
        $viewer_id = $vm[1];
    }

    // Extrair overlay/hint ID do HTML
    $overlay_selector = '.rotation-overlay';

    // Dimensões do sprite
    $sprite_w = ! empty( $block['sprite_width'] )  ? intval( $block['sprite_width'] )  : 1920;
    $sprite_h = ! empty( $block['sprite_height'] ) ? intval( $block['sprite_height'] ) : 1080;

    // Extrair colorNames do JS se existir
    $color_names_js = '{}';
    if ( preg_match( '/(?:var|const|let)\s+colorNames\s*=\s*(\{[^}]+\})/', $js_raw, $cn_match ) ) {
        $color_names_js = $cn_match[1];
    }

    // Determinar a primeira cor (primeira key do bikeData)
    $first_color = '';
    if ( preg_match_all( '/"([^"]+)"\s*:\s*\[/', $bike_data_json, $keys_match ) ) {
        $first_color = $keys_match[1][0] ?? '';
    }

    // Gerar JS limpo — mesmo padrão do shortcode [ducati_360]
    $js  = 'var $=jQuery;';
    $js .= '(function(){';
    $js .= 'var bikeData=' . $bike_data_json . ';';
    $js .= 'var colorNames=' . $color_names_js . ';';

    // Encontrar o wrapper (pode ser o wrapper_id ou o primeiro .ducati-lisboa-360-wrapper)
    $js .= 'var w=document.getElementById(' . wp_json_encode( $wrapper_id ) . ')||document.querySelector(".ducati-lisboa-360-wrapper");';
    $js .= 'if(!w)w=document.body;';
    $js .= 'var $w=$(w);';

    // Encontrar o viewer
    if ( $viewer_id ) {
        $js .= 'var $viewer=$("#' . esc_js( $viewer_id ) . '");';
        $js .= 'if(!$viewer.length)$viewer=$w.find("[id^=moto-viewer]").first();';
    } else {
        $js .= 'var $viewer=$w.find("[id^=moto-viewer]").first();';
        $js .= 'if(!$viewer.length)$viewer=$w.find(".moto-container>div:first-child");';
    }

    // Overlay — inject if missing from stored HTML
    $js .= 'var $overlay=$w.find("' . $overlay_selector . '");';
    $js .= 'if(!$overlay.length){';
    $js .= '  var $mc=$w.find(".moto-container");';
    $js .= '  if($mc.length){';
    $js .= '    $mc.append(\'<div class="rotation-overlay visible"><div class="drag-indicator"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 6c2-1.5 4.5-2 7-1.5 2.5.5 4.5 2 6 4"/><polyline points="16 9 20 9 20 5"/><path d="M17 18c-2 1.5-4.5 2-7 1.5-2.5-.5-4.5-2-6-4"/><polyline points="8 15 4 15 4 19"/></svg></div></div>\');';
    $js .= '    $overlay=$w.find("' . $overlay_selector . '");';
    $js .= '  }';
    $js .= '}';

    // load360 — inicialização limpa sem resize loops
    $js .= 'function load360(color){';
    $js .= '  var imgs=bikeData[color];';
    $js .= '  if(!imgs||!imgs.length)return;';
    $js .= '  var probe=new Image();';
    $js .= '  probe.onload=function(){';
    $js .= '    var natW=probe.naturalWidth||' . $sprite_w . ';';
    $js .= '    var natH=probe.naturalHeight||' . $sprite_h . ';';
    $js .= '    $viewer.spritespin({';
    $js .= '      source:imgs,width:natW,height:natH,';
    $js .= '      responsive:true,';
    $js .= '      animate:false,touch:true,sense:-1.5,';
    $js .= '      renderer:"image",';
    $js .= '      onInit:function(){$overlay.addClass("visible");},';
    $js .= '      onFrame:function(){$overlay.removeClass("visible");clearTimeout(window._blkStopTimer);window._blkStopTimer=setTimeout(function(){$overlay.addClass("visible");},250);},';
    $js .= '      onDragStart:function(){$overlay.removeClass("visible");}';
    $js .= '    });';
    $js .= '  };';
    $js .= '  probe.onerror=function(){';
    $js .= '    $viewer.spritespin({';
    $js .= '      source:imgs,width:' . $sprite_w . ',height:' . $sprite_h . ',';
    $js .= '      responsive:true,';
    $js .= '      animate:false,touch:true,sense:-1.5,';
    $js .= '      renderer:"image",';
    $js .= '      onInit:function(){$overlay.addClass("visible");},';
    $js .= '      onFrame:function(){$overlay.removeClass("visible");clearTimeout(window._blkStopTimer);window._blkStopTimer=setTimeout(function(){$overlay.addClass("visible");},250);},';
    $js .= '      onDragStart:function(){$overlay.removeClass("visible");}';
    $js .= '    });';
    $js .= '  };';
    $js .= '  probe.src=imgs[0];';
    $js .= '}';

    // Inicializar com a primeira cor
    if ( $first_color ) {
        $js .= 'load360(' . wp_json_encode( $first_color ) . ');';
    }

    // Color button handlers — scoped ao wrapper
    $js .= '$w.find(".color-btn").on("click",function(){';
    $js .= '  $w.find(".color-btn").removeClass("active");';
    $js .= '  $(this).addClass("active");';
    $js .= '  var color=$(this).data("color");';
    $js .= '  var name=$(this).data("name")||colorNames[color]||color;';
    $js .= '  $w.find(".color-name-display span, .dc360-color-name").text(name);';
    $js .= '  load360(color);';
    $js .= '});';

    $js .= '})();';

    return $js;
}
endif;

// =============================================
// REGISTAR SHORTCODE
// =============================================
add_shortcode( 'cloned_block', 'blkcloner_render_shortcode' );

if ( ! function_exists( 'blkcloner_render_shortcode' ) ) :
function blkcloner_render_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'id'         => '',
        'max_width'  => '100%',
        'align'      => 'center',
        'overflow'   => 'hidden',
        'responsive' => 'yes',
        'lazy'       => 'yes',
        'background' => 'transparent',
        'debug'      => 'no',
    ), $atts, 'cloned_block' );

    $block_id = sanitize_text_field( $atts['id'] );

    if ( empty( $block_id ) ) {
        if ( current_user_can( 'manage_options' ) ) {
            return '<div style="padding:20px;background:#fcf0f1;border:1px solid #d63638;border-radius:4px;color:#8a2424;">'
                . '<strong>Block Cloner:</strong> Parâmetro "id" em falta. Uso: <code>[cloned_block id="blk_xxxxx"]</code>'
                . '</div>';
        }
        return '';
    }

    $saved = get_option( BLKCLONER_OPTION_KEY, array() );

    $block = null;
    if ( isset( $saved[ $block_id ] ) ) {
        $block = $saved[ $block_id ];
    } else {
        $block_id_lower = strtolower( $block_id );
        foreach ( $saved as $key => $b ) {
            if ( strtolower( $key ) === $block_id_lower ) {
                $block = $b;
                $block_id = $key;
                break;
            }
        }
    }

    if ( ! $block ) {
        if ( current_user_can( 'manage_options' ) ) {
            return '<div style="padding:20px;background:#fcf0f1;border:1px solid #d63638;border-radius:4px;color:#8a2424;">'
                . '<strong>Block Cloner:</strong> Bloco "' . esc_html( $block_id ) . '" não encontrado. '
                . '<a href="' . admin_url( 'admin.php?page=block-cloner' ) . '">Gerir blocos</a>'
                . '</div>';
        }
        return '';
    }

    // ---- MODO DEBUG (só admin): [cloned_block id="xxx" debug="yes"] ou debug="test" ----
    if ( ( $atts['debug'] === 'yes' || $atts['debug'] === 'test' ) && current_user_can( 'manage_options' ) ) {
        $js_raw  = $block['js'] ?? '';
        $css_raw = $block['css'] ?? '';
        $htm_raw = $block['html'] ?? '';

        $has_bike  = preg_match( '/(?:var|const|let)\s+bikeData\s*=\s*\{/', $js_raw ) ? 'SIM' : 'NAO';
        $has_load  = strpos( $js_raw, 'load360' ) !== false ? 'SIM' : 'NAO';
        $has_ss    = strpos( $js_raw, 'spritespin' ) !== false || strpos( $js_raw, 'SpriteSpin' ) !== false ? 'SIM' : 'NAO';
        $has_mv    = strpos( $htm_raw, 'moto-viewer' ) !== false ? 'SIM' : 'NAO';
        $has_mc    = strpos( $htm_raw, 'moto-container' ) !== false ? 'SIM' : 'NAO';
        $has_cb    = strpos( $htm_raw, 'color-btn' ) !== false ? 'SIM' : 'NAO';
        $has_dca   = strpos( $htm_raw, 'ducati-controls-area' ) !== false ? 'SIM' : 'NAO';
        $has_ds    = strpos( $htm_raw, 'ducati-selector' ) !== false ? 'SIM' : 'NAO';
        $has_cn    = strpos( $htm_raw, 'color-name-display' ) !== false ? 'SIM' : 'NAO';
        $has_wr    = strpos( $htm_raw, 'ducati-lisboa-360-wrapper' ) !== false ? 'SIM' : 'NAO';
        $cb_count  = substr_count( $htm_raw, 'color-btn' );
        $css_cb    = strpos( $css_raw, 'color-btn' ) !== false ? 'SIM' : 'NAO';
        $css_dca   = strpos( $css_raw, 'ducati-controls-area' ) !== false ? 'SIM' : 'NAO';

        // v1.8.6 — verificar se data-color existe no HTML guardado
        $has_data_color = strpos( $htm_raw, 'data-color' ) !== false ? 'SIM' : 'NAO';
        $has_data_name  = strpos( $htm_raw, 'data-name' ) !== false ? 'SIM' : 'NAO';

        // Extract bikeData keys
        $bike_keys_arr = array();
        $bike_keys = 'N/A';
        if ( preg_match( '/(?:var|const|let)\s+bikeData\s*=\s*(\{.+?\});/s', $js_raw, $bdm ) ) {
            preg_match_all( '/"([^"]+)"\s*:\s*\[/', $bdm[1], $km );
            $bike_keys_arr = $km[1] ?? array();
            $bike_keys = implode( ', ', $bike_keys_arr );
        }

        // Detectar estrutura do JS (tem wrapper ou não)
        $js_has_ready   = preg_match( '/\$\s*\(\s*(document|function)/', $js_raw ) || strpos( $js_raw, '.ready(' ) !== false ? 'SIM' : 'NAO';
        $js_has_iife    = preg_match( '/^\s*\(\s*function\s*\(/', $js_raw ) ? 'SIM' : 'NAO';
        $js_first_line  = esc_html( trim( strtok( $js_raw, "\n" ) ) );

        $js_len  = strlen( $js_raw );
        $css_len = strlen( $css_raw );
        $htm_len = strlen( $htm_raw );

        $dbg  = '<div style="padding:15px;background:#1e1e2e;color:#cdd6f4;border:2px solid #f38ba8;border-radius:8px;font-family:monospace;font-size:12px;line-height:1.8;margin:20px 0;overflow:auto;max-width:100%;">';
        $dbg .= '<div style="color:#f38ba8;font-size:14px;font-weight:700;margin-bottom:10px;">BLOCK CLONER DEBUG — v' . BLKCLONER_VERSION . '</div>';
        $dbg .= '<div style="color:#a6e3a1;">Block ID: ' . esc_html( $block_id ) . '</div>';

        // ─── DADOS GUARDADOS ───
        $dbg .= '<div style="color:#89b4fa;margin-top:8px;">─── DADOS GUARDADOS ───</div>';
        $dbg .= '<div>HTML: ' . $htm_len . ' bytes | CSS: ' . $css_len . ' bytes | JS: ' . $js_len . ' bytes</div>';

        // ─── HTML CONTÉM ───
        $dbg .= '<div style="color:#89b4fa;margin-top:8px;">─── HTML CONTÉM ───</div>';
        $dbg .= '<div>.ducati-lisboa-360-wrapper: <b>' . $has_wr . '</b></div>';
        $dbg .= '<div>.moto-container: <b>' . $has_mc . '</b> | #moto-viewer: <b>' . $has_mv . '</b></div>';
        $dbg .= '<div>.ducati-controls-area: <b>' . $has_dca . '</b></div>';
        $dbg .= '<div>.ducati-selector: <b>' . $has_ds . '</b></div>';
        $dbg .= '<div>.color-btn: <b>' . $has_cb . '</b> (×' . $cb_count . ')</div>';
        $dbg .= '<div>.color-name-display: <b>' . $has_cn . '</b></div>';
        $dbg .= '<div style="color:' . ( $has_data_color === 'SIM' ? '#a6e3a1' : '#f38ba8' ) . ';">data-color: <b>' . $has_data_color . '</b> | data-name: <b>' . $has_data_name . '</b>';
        if ( $has_data_color === 'NAO' && ! empty( $bike_keys_arr ) ) {
            $dbg .= ' — <span style="color:#fab387;">REPARADO: data-color será re-injetado a partir do bikeData (' . esc_html( $bike_keys ) . ')</span>';
        }
        $dbg .= '</div>';

        // ─── JS CONTÉM ───
        $dbg .= '<div style="color:#89b4fa;margin-top:8px;">─── JS CONTÉM ───</div>';
        $dbg .= '<div>bikeData: <b>' . $has_bike . '</b> | keys: <b>' . esc_html( $bike_keys ) . '</b></div>';
        $dbg .= '<div>load360: <b>' . $has_load . '</b> | spritespin: <b>' . $has_ss . '</b></div>';
        $dbg .= '<div>$(document).ready: <b>' . $js_has_ready . '</b> | IIFE wrapper: <b>' . $js_has_iife . '</b></div>';
        $dbg .= '<div style="color:#94e2d5;">JS linha 1: <span style="color:#cdd6f4;">' . ( strlen( $js_first_line ) > 120 ? substr( $js_first_line, 0, 120 ) . '...' : $js_first_line ) . '</span></div>';

        // ─── CSS CONTÉM ───
        $dbg .= '<div style="color:#89b4fa;margin-top:8px;">─── CSS CONTÉM ───</div>';
        $dbg .= '<div>.color-btn: <b>' . $css_cb . '</b> | .ducati-controls-area: <b>' . $css_dca . '</b></div>';
        $filtered_note = '';
        if ( $css_len > 50000 ) {
            $filtered_css_test = blkcloner_filter_relevant_css( $css_raw, $htm_raw );
            $filtered_len = strlen( $filtered_css_test );
            $filtered_note = ' (filtrado para ' . $filtered_len . ' bytes)';
        }
        $dbg .= '<div>Tamanho: ' . $css_len . ' bytes' . $filtered_note . '</div>';

        // ─── SPRITE DIMS ───
        $dbg .= '<div style="color:#89b4fa;margin-top:8px;">─── SPRITE DIMS ───</div>';
        $dbg .= '<div>sprite_width: <b>' . esc_html( $block['sprite_width'] ?? 'não definido' ) . '</b> | sprite_height: <b>' . esc_html( $block['sprite_height'] ?? 'não definido' ) . '</b></div>';

        // Extrair primeira URL de imagem do bikeData para teste
        $test_img_url = '';
        if ( preg_match( '/bikeData\s*=\s*\{[^"]*"[^"]*"\s*:\s*\["([^"]+)"/', $js_raw, $first_url_m ) ) {
            $test_img_url = $first_url_m[1];
        } elseif ( ! empty( $block['images'] ) && is_array( $block['images'] ) ) {
            $first_img = reset( $block['images'] );
            $test_img_url = ! empty( $first_img['local_url'] ) ? $first_img['local_url'] : ( ! empty( $first_img['original'] ) ? $first_img['original'] : '' );
        }

        // Extrair viewer ID do HTML guardado
        $viewer_id_stored = '';
        if ( preg_match( '/id="(moto-viewer-[^"]+)"/', $htm_raw, $vid_m ) ) {
            $viewer_id_stored = $vid_m[1];
        }

        // ─── RUNTIME TESTS ───
        $dbg .= '<div style="color:#89b4fa;margin-top:8px;">─── RUNTIME TESTS ───</div>';
        $dbg .= '<div id="blkcloner-rt-results" style="color:#fab387;">A aguardar carregamento completo da página...</div>';
        $dbg .= '</div>';

        // JavaScript de teste runtime
        $dbg .= '<script>';

        // Capturar erros da consola ANTES de tudo
        $dbg .= 'window._blkErrors=[];';
        $dbg .= 'var _origConsErr=console.error;';
        $dbg .= 'console.error=function(){_origConsErr.apply(console,arguments);window._blkErrors.push(Array.prototype.slice.call(arguments).join(" "));};';
        $dbg .= 'window.addEventListener("error",function(e){window._blkErrors.push(e.message+" @ "+e.filename+":"+e.lineno);});';

        $dbg .= 'window.addEventListener("load", function() {';
        $dbg .= '  setTimeout(function(){'; // 2s extra para SpriteSpin async init
        $dbg .= '  var results = [];';
        $dbg .= '  var el = document.getElementById("blkcloner-rt-results");';
        $dbg .= '  function log(label, ok, detail) { results.push("<div>" + (ok ? "✅" : "❌") + " " + label + (detail ? " — <b>" + detail + "</b>" : "") + "</div>"); }';
        $dbg .= '  function warn(label, detail) { results.push("<div>⚠️ " + label + (detail ? " — <b>" + detail + "</b>" : "") + "</div>"); }';
        $dbg .= '  function render() { if(el) el.innerHTML = results.join(""); }';

        // 1. jQuery
        $dbg .= '  var jqOK = typeof jQuery !== "undefined";';
        $dbg .= '  log("jQuery carregado", jqOK, jqOK ? "v" + jQuery.fn.jquery : "NÃO ENCONTRADO");';

        // 2. SpriteSpin plugin
        $dbg .= '  var ssOK = jqOK && jQuery.fn && jQuery.fn.spritespin;';
        $dbg .= '  log("SpriteSpin plugin", !!ssOK, ssOK ? "jQuery.fn.spritespin DISPONÍVEL" : "NÃO — spritespin.js não carregou");';

        // 3. Script tags no DOM
        $dbg .= '  var scripts = document.querySelectorAll("script[src]");';
        $dbg .= '  var hasSS = false; var hasJQ = false; var ssUrl = "";';
        $dbg .= '  scripts.forEach(function(s) { if (s.src.indexOf("spritespin") !== -1) { hasSS = true; ssUrl = s.src; } if (s.src.indexOf("jquery") !== -1) hasJQ = true; });';
        $dbg .= '  log("Script jQuery no DOM", hasJQ, hasJQ ? "encontrado" : "NÃO");';
        $dbg .= '  log("Script SpriteSpin no DOM", hasSS, hasSS ? ssUrl : "NÃO — wp_enqueue_script falhou?");';

        // 4. wp_footer
        $dbg .= '  log("wp_footer() executado", hasSS || hasJQ, hasSS || hasJQ ? "SIM" : "NÃO — o tema pode não chamar wp_footer()!");';

        // 5. Wrapper element
        $dbg .= '  var wrappers = document.querySelectorAll(".blkcloner-block");';
        $dbg .= '  var wInfo = [];';
        $dbg .= '  wrappers.forEach(function(w) { wInfo.push(w.id + " (" + w.offsetWidth + "×" + w.offsetHeight + "px)"); });';
        $dbg .= '  log("Wrapper .blkcloner-block", wrappers.length > 0, wrappers.length + " — " + wInfo.join(", "));';

        // 6. Viewer element
        if ( $viewer_id_stored ) {
            $dbg .= '  var viewerEl = document.getElementById("' . esc_js( $viewer_id_stored ) . '");';
            $dbg .= '  log("Viewer #' . esc_js( $viewer_id_stored ) . '", !!viewerEl, viewerEl ? "h=" + viewerEl.offsetHeight + "px w=" + viewerEl.offsetWidth + "px children=" + viewerEl.children.length : "NÃO ENCONTRADO");';
        } else {
            $dbg .= '  var viewerEl = document.querySelector("[id^=moto-viewer]") || document.querySelector(".moto-container > div:first-child");';
            $dbg .= '  log("Viewer (auto-detetado)", !!viewerEl, viewerEl ? "id=" + viewerEl.id + " h=" + viewerEl.offsetHeight + "px" : "NENHUM");';
        }

        // 7. .moto-container dims
        $dbg .= '  var mc = document.querySelector(".moto-container");';
        $dbg .= '  log(".moto-container", mc && mc.offsetHeight > 50, mc ? mc.offsetWidth + "×" + mc.offsetHeight + "px" : "NÃO ENCONTRADO");';

        // 8. data-color nos botões (NOVO v1.8.6)
        $dbg .= '  var btns = document.querySelectorAll(".color-btn");';
        $dbg .= '  var btnInfo = [];';
        $dbg .= '  btns.forEach(function(b,i) { btnInfo.push((b.dataset.color || "SEM-DATA-COLOR") + ":" + (b.dataset.name || "SEM-NOME")); });';
        $dbg .= '  var allHaveData = btns.length > 0 && btnInfo.every(function(s){return s.indexOf("SEM-DATA-COLOR")===-1;});';
        $dbg .= '  log("data-color nos .color-btn", allHaveData, btns.length + " botões: " + btnInfo.join(", "));';

        // 9. SpriteSpin renderizou?
        $dbg .= '  var ssRendered = false;';
        $dbg .= '  var ssDetail = "NÃO inicializou";';
        $dbg .= '  if (viewerEl) {';
        $dbg .= '    var ssEl = viewerEl.querySelector("canvas, img, .spritespin-stage, .spritespin-wrap");';
        $dbg .= '    if (ssEl) { ssRendered = true; ssDetail = ssEl.tagName + " " + ssEl.offsetWidth + "×" + ssEl.offsetHeight + "px"; }';
        $dbg .= '    else {';
        // Tentar via jQuery data
        $dbg .= '      if (jqOK && jQuery(viewerEl).data("spritespin")) { ssRendered = true; ssDetail = "SpriteSpin data presente (pode estar a carregar imagens)"; }';
        $dbg .= '    }';
        $dbg .= '  }';
        $dbg .= '  log("SpriteSpin RENDERIZOU", ssRendered, ssDetail);';

        // 10. Se não renderizou, tentar diagnosticar porquê
        $dbg .= '  if (!ssRendered && jqOK && ssOK && viewerEl) {';
        $dbg .= '    warn("DIAGNÓSTICO", "SpriteSpin disponível + viewer existe, mas não renderizou. A testar init manual...");';
        // Tentar chamar spritespin manualmente com a primeira imagem
        if ( $test_img_url ) {
            $dbg .= '    try {';
            $dbg .= '      jQuery("#" + viewerEl.id).spritespin({';
            $dbg .= '        source: ["' . esc_js( $test_img_url ) . '"],';
            $dbg .= '        width: ' . intval( $block['sprite_width'] ?? 2520 ) . ',';
            $dbg .= '        height: ' . intval( $block['sprite_height'] ?? 1420 ) . ',';
            $dbg .= '        animate: false, responsive: true';
            $dbg .= '      });';
            $dbg .= '      setTimeout(function(){';
            $dbg .= '        var testEl = viewerEl.querySelector("canvas, img, .spritespin-stage");';
            $dbg .= '        if (testEl) { log("INIT MANUAL TESTE", true, "SpriteSpin inicializou com 1 imagem! O problema é no JS guardado."); }';
            $dbg .= '        else { log("INIT MANUAL TESTE", false, "SpriteSpin também falhou com init manual — problema no CSS ou container."); }';
            $dbg .= '        render();';
            $dbg .= '      }, 2000);';
            $dbg .= '    } catch(e) {';
            $dbg .= '      log("INIT MANUAL TESTE", false, "ERRO: " + e.message);';
            $dbg .= '      render();';
            $dbg .= '    }';
        }
        $dbg .= '  }';

        // 11. rotation-overlay
        $dbg .= '  var overlay = document.querySelector(".rotation-overlay");';
        $dbg .= '  if (overlay) {';
        $dbg .= '    var cs = getComputedStyle(overlay);';
        $dbg .= '    var ow = parseFloat(cs.width);';
        $dbg .= '    log("rotation-overlay", ow < 200, "width=" + cs.width + (ow > 200 ? " — BUG: forçado a 100%!" : " — OK"));';
        $dbg .= '  }';

        // 12. Primeira imagem carrega
        if ( $test_img_url ) {
            $dbg .= '  var testImg = new Image();';
            $dbg .= '  testImg.onload = function() { log("Primeira imagem", true, testImg.naturalWidth + "×" + testImg.naturalHeight + "px — " + "' . esc_js( basename( $test_img_url ) ) . '"); render(); };';
            $dbg .= '  testImg.onerror = function() { log("Primeira imagem", false, "ERRO ao carregar URL"); render(); };';
            $dbg .= '  testImg.src = "' . esc_js( $test_img_url ) . '";';
        }

        // 13. Erros JS capturados
        $dbg .= '  if (window._blkErrors.length > 0) {';
        $dbg .= '    window._blkErrors.forEach(function(e) { log("JS ERROR capturado", false, e); });';
        $dbg .= '  } else {';
        $dbg .= '    log("Erros JS na consola", true, "Nenhum erro capturado");';
        $dbg .= '  }';

        // 14. Inline scripts com BlockCloner
        $dbg .= '  var inlineScripts = document.querySelectorAll("script:not([src])");';
        $dbg .= '  var blkScripts = 0;';
        $dbg .= '  inlineScripts.forEach(function(s) { if (s.textContent.indexOf("_blkWait") !== -1 || s.textContent.indexOf("waitForSpriteSpin") !== -1 || s.textContent.indexOf("bikeData") !== -1) blkScripts++; });';
        $dbg .= '  log("Inline scripts BlockCloner", blkScripts > 0, blkScripts + " script(s) encontrado(s)");';

        // 15. Versão e IDs
        $dbg .= '  log("Plugin versão", true, "' . esc_js( BLKCLONER_VERSION ) . '");';
        $dbg .= '  log("Bloco ID", true, "' . esc_js( $block_id ) . '");';

        // 16. CSS computed do viewer (para ver se algo esconde)
        $dbg .= '  if (viewerEl) {';
        $dbg .= '    var vcs = getComputedStyle(viewerEl);';
        $dbg .= '    var vHidden = vcs.display === "none" || vcs.visibility === "hidden" || vcs.opacity === "0" || parseFloat(vcs.height) < 1;';
        $dbg .= '    log("Viewer CSS visibilidade", !vHidden, "display:" + vcs.display + " visibility:" + vcs.visibility + " opacity:" + vcs.opacity + " height:" + vcs.height + " overflow:" + vcs.overflow);';
        $dbg .= '  }';

        // 17. Viewer parent chain (ver se algum pai esconde)
        $dbg .= '  if (viewerEl) {';
        $dbg .= '    var hiddenParent = null;';
        $dbg .= '    var p = viewerEl.parentElement;';
        $dbg .= '    while (p && p !== document.body) {';
        $dbg .= '      var pcs = getComputedStyle(p);';
        $dbg .= '      if (pcs.display === "none" || pcs.visibility === "hidden" || pcs.opacity === "0") {';
        $dbg .= '        hiddenParent = p.tagName + (p.className ? "." + p.className.split(" ")[0] : "") + (p.id ? "#" + p.id : "") + " — display:" + pcs.display + " vis:" + pcs.visibility + " opacity:" + pcs.opacity;';
        $dbg .= '        break;';
        $dbg .= '      }';
        $dbg .= '      p = p.parentElement;';
        $dbg .= '    }';
        $dbg .= '    log("Pai visível (parent chain)", !hiddenParent, hiddenParent ? "ESCONDIDO por: " + hiddenParent : "Todos os pais visíveis");';
        $dbg .= '  }';

        $dbg .= '  render();';
        $dbg .= '  },2000);'; // fim setTimeout 2s
        $dbg .= '});'; // fim window load
        $dbg .= '</script>';

        // Se debug="test", renderizar TAMBÉM o bloco (para ver o resultado + diagnóstico)
        if ( $atts['debug'] === 'test' ) {
            // Não retornar — continuar para renderizar o bloco normalmente abaixo do painel debug
        } else {
            return $dbg;
        }
        // Para debug="test", prepend o painel e continuar com renderização normal
        $debug_panel = $dbg;
    }

    $wrapper_id = 'blkcloner-' . $block_id . '-' . wp_rand( 1000, 9999 );

    // Estilos do wrapper
    $margin = '0 auto';
    if ( $atts['align'] === 'left' ) {
        $margin = '0 auto 0 0';
    } elseif ( $atts['align'] === 'right' ) {
        $margin = '0 0 0 auto';
    }
    $style_str = 'width:100%;display:block;max-width:' . esc_attr( $atts['max_width'] ) . ';overflow:visible;margin:' . $margin . ';position:relative;z-index:9999;background:' . esc_attr( $atts['background'] ) . ';isolation:isolate;min-height:200px;';

    $raw_css      = $block['css'] ?? '';
    $html         = $block['html'] ?? '';
    $js_raw       = $block['js'] ?? '';
    $block_config = $block['config'] ?? array();

    // ---- REPARAR BLOCOS EXISTENTES: re-injetar data-* attributes se em falta ----
    // wp_kses_post() nas versões anteriores apagava data-color/data-name dos color-btn
    if ( strpos( $html, 'color-btn' ) !== false && strpos( $html, 'data-color' ) === false ) {
        // Extrair chaves do bikeData no JS
        $bike_keys = array();
        $bike_names = array();
        if ( preg_match( '/(?:var|const|let)\s+bikeData\s*=\s*\{(.+?)\};/s', $js_raw, $bd_m ) ) {
            if ( preg_match_all( '/"([^"]+)"\s*:\s*\[/', $bd_m[1], $km ) ) {
                $bike_keys = $km[1];
            }
        }
        // Extrair nomes das cores (do JS colorNames se existir, ou usar as keys)
        if ( preg_match_all( '/colorNames\s*[=:]\s*\{[^}]*"([^"]+)"\s*:\s*"([^"]+)"/', $js_raw, $cn_m, PREG_SET_ORDER ) ) {
            foreach ( $cn_m as $cn ) {
                $bike_names[ $cn[1] ] = $cn[2];
            }
        }

        // Reinjetar data-color e data-name nos color-btn por ordem
        $btn_idx = 0;
        $html = preg_replace_callback( '/(<(?:div|button)[^>]*class="[^"]*color-btn[^"]*"[^>]*)(>)/i', function( $m ) use ( $bike_keys, $bike_names, &$btn_idx ) {
            $tag = $m[1];
            $close = $m[2];
            if ( isset( $bike_keys[ $btn_idx ] ) ) {
                $key = esc_attr( $bike_keys[ $btn_idx ] );
                $name = esc_attr( $bike_names[ $bike_keys[ $btn_idx ] ] ?? ucfirst( str_replace( '_', ' ', $bike_keys[ $btn_idx ] ) ) );
                $tag .= ' data-color="' . $key . '" data-name="' . $name . '"';
            }
            $btn_idx++;
            return $tag . $close;
        }, $html );
    }

    // Filter oversized CSS: keep only rules relevant to block HTML
    if ( strlen( $raw_css ) > 50000 ) {
        $raw_css = blkcloner_filter_relevant_css( $raw_css, $html );
    }

    // Scope stored CSS with wrapper ID to prevent leaking to page
    $css = blkcloner_scope_css( $raw_css, $wrapper_id );
    $has_spritespin = ( strpos( $js_raw, 'spritespin' ) !== false
        || strpos( $js_raw, 'SpriteSpin' ) !== false
        || strpos( $html, 'moto-viewer' ) !== false
        || strpos( $html, 'moto-container' ) !== false
        || strpos( $html, 'blk-360-spritespin' ) !== false
        || strpos( $html, 'ducati-lisboa-360-wrapper' ) !== false );

    // ---- RECOLHER TODO O CSS ANTES DE OUTPUT ----
    $extra_css = '';

    if ( $atts['lazy'] === 'yes' ) {
        $html = preg_replace( '/<img(?![^>]*loading)(\s)/i', '<img loading="lazy"$1', $html );
    }
    if ( $atts['responsive'] === 'yes' ) {
        // Responsive: use max-width instead of width to not stretch small images/icons
        $extra_css .= "
            #{$wrapper_id} img {
                max-width: 100%;
                height: auto;
                display: block;
            }
            #{$wrapper_id} video {
                max-width: 100%;
                height: auto;
                display: block;
            }
            #{$wrapper_id} iframe {
                max-width: 100%;
                height: auto;
            }
            #{$wrapper_id} picture,
            #{$wrapper_id} figure {
                max-width: 100%;
                display: block;
            }
            #{$wrapper_id} picture img,
            #{$wrapper_id} figure img {
                max-width: 100%;
                height: auto;
            }
        ";
    }

    // SpriteSpin + Color selectors CSS — ALWAYS included when 360° detected (outside responsive check)
    if ( $has_spritespin ) {
        // Controls position from saved config
        $ctrl_pos = ! empty( $block_config['controls_position'] ) ? $block_config['controls_position'] : 'bottom';

        $extra_css .= "
            #{$wrapper_id} .moto-container {
                position: relative;
                overflow: hidden !important;
                aspect-ratio: auto !important;
                z-index: 9999;
                min-height: 200px;
            }
            #{$wrapper_id} .moto-container > div:not(.rotation-overlay) {
                width: 100% !important; max-width: 100% !important;
                display: block !important; visibility: visible !important;
                opacity: 1 !important; overflow: hidden !important;
                min-height: 50px;
                z-index: 9999;
            }
            #{$wrapper_id} .spritespin-stage,
            #{$wrapper_id} .spritespin-canvas {
                display: block !important; visibility: visible !important;
                opacity: 1 !important; overflow: hidden !important;
                z-index: 9999;
            }
            #{$wrapper_id} .spritespin-stage img {
                max-width: 100% !important;
                height: auto !important;
                display: block;
                object-fit: contain;
            }
            #{$wrapper_id} .rotation-overlay {
                position: absolute;
                top: 0; left: 0;
                width: 100%; height: 100%;
                z-index: 9999;
                pointer-events: none;
                opacity: 0; visibility: hidden;
                transition: opacity 0.4s ease-in-out;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            #{$wrapper_id} .rotation-overlay.visible {
                opacity: 1; visibility: visible;
            }
            #{$wrapper_id} .drag-indicator {
                background: rgba(0, 0, 0, 0.3);
                width: 70px; height: 70px;
                border-radius: 50%;
                border: 1px solid rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
                display: flex; align-items: center; justify-content: center;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3);
                z-index: 9999;
            }
            #{$wrapper_id} .drag-indicator svg {
                width: 45px; height: 45px;
                filter: drop-shadow(0px 0px 3px rgba(0,0,0,0.8));
            }
            #{$wrapper_id} .ducati-lisboa-360-wrapper {
                display: flex; flex-direction: column; align-items: center;
                overflow: visible;
                position: relative;
                z-index: 9999;
            }
            #{$wrapper_id} .ducati-selector img {
                max-width: none; display: inline-block;
            }
            #{$wrapper_id} .ducati-controls-area {
                display: flex !important; flex-direction: column; align-items: center;
                gap: 15px; margin-top: -20px; padding-bottom: 40px;
                position: relative; z-index: 9999;
                " . blkcloner_controls_position_css( $block_config ) . "
            }
            #{$wrapper_id} .ducati-selector { display: flex !important; gap: 20px;" . ( in_array( $ctrl_pos, array( 'left', 'right' ), true ) ? ' flex-direction: column;' : '' ) . " }
            #{$wrapper_id} .color-btn {
                width: 45px !important; height: 45px !important; background-size: cover;
                background-position: center;
                border-radius: 50%; cursor: pointer; border: 2px solid #ddd;
                transition: 0.3s ease; display: block !important;
                position: relative; z-index: 9999;
            }
            #{$wrapper_id} .color-btn.active { border-color: #E32219; transform: scale(1.1); }
            #{$wrapper_id} .color-name-display {
                font-size: 13px; font-weight: 700; text-transform: uppercase; color: #333;
                display: block !important;
            }
            #{$wrapper_id} .color-name-display span,
            #{$wrapper_id} .dc360-color-name { color: #E32219; margin-left: 5px; }
        ";

        // Contar cores do bikeData
        $num_colors = 0;
        if ( preg_match_all( '/"([^"]+)"\s*:\s*\[/', $js_raw, $color_keys ) ) {
            $num_colors = count( $color_keys[1] );
        }
        // Se só 1 cor e config diz para esconder seletor de cor única
        $show_single = isset( $block_config['show_single_color'] ) ? $block_config['show_single_color'] : true;
        if ( $num_colors <= 1 && ! $show_single ) {
            $extra_css .= "
            #{$wrapper_id} .ducati-controls-area,
            #{$wrapper_id} .ducati-selector,
            #{$wrapper_id} .color-name-display { display: none !important; }
        ";
        }
    }
    if ( $atts['background'] === 'transparent' ) {
        $extra_css .= "
            #{$wrapper_id},
            #{$wrapper_id} > div { background: transparent !important; }
        ";
    }

    // Licença e marca d'água
    $is_licensed = blkcloner_is_licensed();
    $watermark_html = '';
    if ( ! $is_licensed ) {
        $extra_css .= "
            #{$wrapper_id} .blkcloner-watermark {
                position: absolute;
                top: 0; left: 0; right: 0; bottom: 0;
                z-index: 50;
                pointer-events: none;
                overflow: hidden;
            }
            #{$wrapper_id} .blkcloner-watermark::before {
                content: 'NETSEG.AI';
                position: absolute;
                top: 50%; left: 50%;
                transform: translate(-50%,-50%) rotate(-25deg);
                font-size: 4vw;
                font-weight: 900;
                color: rgba(227, 34, 25, 0.12);
                letter-spacing: 8px;
                text-transform: uppercase;
                white-space: nowrap;
                font-family: 'Arial Black', Impact, sans-serif;
                pointer-events: none;
            }
            #{$wrapper_id} .blkcloner-watermark::after {
                content: 'NETSEG.AI  \\00B7  NETSEG.AI  \\00B7  NETSEG.AI';
                position: absolute;
                top: 65%; left: 50%;
                transform: translate(-50%,-50%) rotate(-25deg);
                font-size: 2vw;
                font-weight: 900;
                color: rgba(227, 34, 25, 0.08);
                letter-spacing: 6px;
                white-space: nowrap;
                font-family: 'Arial Black', Impact, sans-serif;
                pointer-events: none;
            }
        ";
        $watermark_html = '<div class="blkcloner-watermark"></div>';
    }

    // ---- CONSTRUIR OUTPUT ----
    $output = '';

    // Todos os CSS num único <style> tag com isolamento
    if ( ! empty( $css ) || ! empty( $extra_css ) ) {
        $output .= '<style>' . "\n";
        $output .= "/* Block Cloner: {$block_id} — isolated */\n";
        $output .= $css . "\n";
        $output .= $extra_css . "\n";
        $output .= '</style>';
    }

    // HTML wrapper
    $output .= '<div id="' . esc_attr( $wrapper_id ) . '" class="blkcloner-block" data-block-id="' . esc_attr( $block_id ) . '" style="' . esc_attr( $style_str ) . '">';
    $output .= $html;
    $output .= $watermark_html;
    $output .= '</div>';

    // ---- JAVASCRIPT INLINE ----
    $js = $block['js'] ?? '';

    // Detetar SpriteSpin — from JS OR from HTML structure
    $has_spritespin_js = ( strpos( $js, 'spritespin' ) !== false
        || strpos( $js, 'SpriteSpin' ) !== false
        || strpos( $js, 'bikeData' ) !== false
        || strpos( $html, 'moto-viewer' ) !== false
        || strpos( $html, 'moto-container' ) !== false
        || strpos( $html, 'blk-360-spritespin' ) !== false
        || strpos( $html, 'ducati-lisboa-360-wrapper' ) !== false );

    if ( $has_spritespin_js ) {
            // v1.9.2: Renderização via iframe isolado (mesmo método do preview).
            // O preview funciona a 100% porque cria um documento HTML completo
            // com jQuery e SpriteSpin carregados no <head> de forma síncrona.
            // Replicamos essa abordagem no front-end para garantir que o
            // script 360° carrega sempre, independentemente de wp_footer().
            $iframe_id = $wrapper_id . '-iframe';

            // Construir documento HTML completo (como buildFullPreviewIframe)
            $iframe_doc  = '<!DOCTYPE html><html><head><meta charset="UTF-8">';
            $iframe_doc .= '<meta name="viewport" content="width=1200, initial-scale=1.0">';
            $iframe_bg = ( $atts['background'] === 'transparent' ) ? 'transparent' : '#fff';
            $iframe_doc .= '<style>html,body{margin:0;padding:0;font-family:Arial,sans-serif;background:' . $iframe_bg . ';}body{overflow-x:hidden;}</style>';

            // jQuery + SpriteSpin no <head> — carregam ANTES do body (síncrono)
            $iframe_doc .= '<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>';
            $iframe_doc .= '<script src="https://unpkg.com/spritespin@4.1.0/release/spritespin.js"></script>';

            // CSS para 360° proporcional — overflow:hidden evita trail/arrasto
            $iframe_doc .= '<style>';
            $iframe_doc .= '.moto-container{overflow:hidden!important;aspect-ratio:auto!important;position:relative;min-height:200px;}';
            $iframe_doc .= '.moto-container>div:not(.rotation-overlay){width:100%!important;max-width:100%!important;overflow:hidden!important;}';
            $iframe_doc .= '.spritespin-stage{overflow:hidden!important;}';
            $iframe_doc .= '.spritespin-stage img{max-width:100%!important;height:auto!important;display:block;object-fit:contain;}';
            $iframe_doc .= '.ducati-lisboa-360-wrapper{overflow:visible!important;}';
            $iframe_doc .= '.spritespin-stage img{-webkit-user-drag:none;user-select:none;-webkit-user-select:none;pointer-events:none;}';
            $iframe_doc .= '.rotation-overlay{position:absolute;top:0;left:0;width:100%;height:100%;z-index:9999;pointer-events:none;opacity:0;visibility:hidden;transition:opacity 0.4s ease-in-out;display:flex;align-items:center;justify-content:center;}';
            $iframe_doc .= '.rotation-overlay.visible{opacity:1;visibility:visible;}';
            $iframe_doc .= '.drag-indicator{background:rgba(0,0,0,0.3);width:70px;height:70px;border-radius:50%;border:1px solid rgba(255,255,255,0.4);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 32px rgba(0,0,0,0.3);z-index:9999;}';
            $iframe_doc .= '.drag-indicator svg{width:45px;height:45px;filter:drop-shadow(0px 0px 3px rgba(0,0,0,0.8));}';
            $iframe_doc .= '.ducati-controls-area{position:relative;z-index:9999;}';
            $iframe_doc .= '.color-btn{position:relative;z-index:9999;}';
            $iframe_doc .= '</style>';

            // CSS original + extra (com selectores #{wrapper_id} que funcionam dentro do iframe)
            if ( ! empty( $css ) || ! empty( $extra_css ) ) {
                $iframe_doc .= '<style>' . $css . "\n" . $extra_css . '</style>';
            }

            $iframe_doc .= '</head><body>';
            $iframe_doc .= '<div id="' . esc_attr( $wrapper_id ) . '" class="blkcloner-block" data-block-id="' . esc_attr( $block_id ) . '" style="width:100%;max-width:100%;">';
            $iframe_doc .= $html;
            $iframe_doc .= $watermark_html;
            $iframe_doc .= '</div>';

            // v2.0.1: Regenerar JS limpo a partir do bikeData extraído.
            // O JS raw do site original contém resize loops, $(document).ready nesting
            // e event handlers cascading que causam "too much recursion" no jQuery.
            // Extraímos apenas o bikeData e geramos JS limpo (mesmo padrão do [ducati_360]).
            $clean_js = blkcloner_generate_clean_360_js( $js, $html, $block, $wrapper_id );
            if ( ! empty( $clean_js ) ) {
                $iframe_doc .= '<script>' . $clean_js . '</script>';
            } elseif ( ! empty( $js ) ) {
                // Fallback: bloco não-360° ou sem bikeData — usar JS raw
                $iframe_doc .= '<script>var $=jQuery;' . $js . '</script>';
            }

            $iframe_doc .= '</body></html>';

            // Codificar para embedding seguro em JS

            // Substituir output — usar iframe via srcdoc (mais fiável que d.write)
            $output = '';
            $output .= '<div class="blkcloner-360-wrap" style="' . esc_attr( $style_str ) . '">';
            $iframe_style = 'width:100%;min-height:500px;border:none;display:block;visibility:visible!important;opacity:1!important;' . ( $atts['background'] === 'transparent' ? 'background:transparent;' : '' );

            // Método principal: srcdoc (funciona mesmo com plugins de cache/defer)
            $srcdoc = htmlspecialchars( $iframe_doc, ENT_QUOTES, 'UTF-8' );
            $output .= '<iframe id="' . esc_attr( $iframe_id ) . '" srcdoc="' . $srcdoc . '" style="' . esc_attr( $iframe_style ) . '" sandbox="allow-scripts allow-same-origin" allowtransparency="true" loading="eager"></iframe>';
            $output .= '</div>';

            // Auto-resize script — funciona com srcdoc
            $output .= '<script data-cfasync="false" data-no-lazy="1" data-no-optimize="1" data-pagespeed-no-defer>';
            $output .= '(function(){';
            $output .= 'var _t=0;';
            $output .= 'function _blkInit(){';
            $output .= 'var f=document.getElementById(' . wp_json_encode( $iframe_id ) . ');';
            $output .= 'if(!f){if(_t++<20){setTimeout(_blkInit,Math.min(_t*200,3000));return;}return;}';
            $output .= 'function rz(){try{var bd=f.contentDocument||f.contentWindow.document;if(!bd||!bd.body)return;var h=Math.max(bd.body.scrollHeight,bd.documentElement.scrollHeight);if(h>50)f.style.height=Math.max(h+30,400)+"px";}catch(e){}}';
            $output .= 'f.onload=function(){rz();setTimeout(rz,500);setTimeout(rz,1500);setTimeout(rz,3000);setTimeout(rz,6000);setTimeout(rz,10000);};';
            $output .= 'try{if(f.contentDocument&&f.contentDocument.body&&f.contentDocument.body.innerHTML.length>100){rz();setTimeout(rz,1000);setTimeout(rz,3000);}}catch(e){}';
            $output .= 'setTimeout(rz,800);';
            $output .= '}';
            // Register in global pending map for wp_footer fallback
            $output .= 'window._blkPending=window._blkPending||{};';
            $output .= 'window._blkPending[' . wp_json_encode( $iframe_id ) . ']=_blkInit;';
            $output .= '_blkInit();';
            // Fallback: DOMContentLoaded + load events for deferred script scenarios
            $output .= 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){setTimeout(_blkInit,100);});}';
            $output .= 'window.addEventListener("load",function(){setTimeout(_blkInit,200);});';
            $output .= '})();';
            $output .= '</script>';
            // Flag for wp_footer fallback script
            $GLOBALS['blkcloner_has_frontend_iframe'] = true;
    } elseif ( ! empty( $js ) ) {
        // Non-SpriteSpin JS — output as-is
        $output .= '<script>' . "\n";
        $output .= $js . "\n";
        $output .= '</script>' . "\n";
    }

    // Se debug="test", prefixar painel de diagnóstico
    if ( isset( $debug_panel ) ) {
        $output = $debug_panel . $output;
    }

    return $output;
}
endif;

// =============================================
// SHORTCODES PARA SECÇÕES DE APRESENTAÇÃO
// =============================================

// [ducati_specs_bar] — Barra de destaques rápidos
add_shortcode( 'ducati_specs_bar', function( $atts ) {
    $atts = shortcode_atts( array(
        'potencia'   => '170',
        'unid_pot'   => 'cv',
        'cilindrada' => '1158',
        'unid_cil'   => 'cc',
        'peso'       => '215',
        'unid_peso'  => 'kg',
        'deposito'   => '22',
        'unid_dep'   => 'L',
        'bg'         => '#1a1a1a',
        'cor'        => '#E32219',
    ), $atts, 'ducati_specs_bar' );

    $uid = 'dspec-' . wp_rand( 1000, 9999 );
    $items = array(
        array( $atts['potencia'], $atts['unid_pot'], 'Pot&ecirc;ncia' ),
        array( $atts['cilindrada'], $atts['unid_cil'], 'Cilindrada' ),
        array( $atts['peso'], $atts['unid_peso'], 'Peso' ),
        array( $atts['deposito'], $atts['unid_dep'], 'Dep&oacute;sito' ),
    );

    $o = '<style>';
    $o .= "#{$uid}{background:{$atts['bg']};padding:40px 20px}";
    $o .= "#{$uid} .sb-inner{max-width:1100px;margin:0 auto;display:grid;grid-template-columns:repeat(4,1fr);gap:30px;text-align:center}";
    $o .= "#{$uid} .sv{font-size:clamp(28px,4vw,42px);font-weight:800;color:{$atts['cor']};line-height:1;margin-bottom:6px}";
    $o .= "#{$uid} .sv span{font-size:.5em;color:rgba(255,255,255,.5)}";
    $o .= "#{$uid} .sl{font-size:12px;font-weight:600;color:rgba(255,255,255,.6);text-transform:uppercase;letter-spacing:2px}";
    $o .= "@media(max-width:768px){#{$uid} .sb-inner{grid-template-columns:repeat(2,1fr);gap:25px}}";
    $o .= '</style>';
    $o .= '<section id="' . $uid . '">';
    $o .= '<div class="sb-inner">';
    foreach ( $items as $item ) {
        $o .= '<div><div class="sv">' . esc_html( $item[0] ) . '<span>' . esc_html( $item[1] ) . '</span></div><div class="sl">' . $item[2] . '</div></div>';
    }
    $o .= '</div></section>';
    return $o;
});

// [ducati_features] — Cards de features
add_shortcode( 'ducati_features', function( $atts ) {
    $atts = shortcode_atts( array(
        'titulo'   => 'Tecnologia de Refer&ecirc;ncia',
        'subtitulo' => '',
        'cor'      => '#E32219',
    ), $atts, 'ducati_features' );

    $uid = 'dfeat-' . wp_rand( 1000, 9999 );
    $features = array(
        array( 'Radar Dianteiro e Traseiro', 'Cruise control adaptativo e dete&ccedil;&atilde;o de &acirc;ngulo morto para m&aacute;xima seguran&ccedil;a em viagem.', '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>' ),
        array( 'Motor V4 Granturismo', '170 cv de pot&ecirc;ncia com intervalos de manuten&ccedil;&atilde;o de 60.000 km gra&ccedil;as &agrave; distribui&ccedil;&atilde;o Desmodr&oacute;mica.', '<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>' ),
        array( 'Suspens&atilde;o Eletr&oacute;nica Skyhook', 'Ajuste semi-ativo em tempo real para conforto em estrada e controlo em todo-o-terreno.', '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' ),
        array( 'Display TFT 6.5&quot;', 'Ecr&atilde; a cores com conectividade Bluetooth e navega&ccedil;&atilde;o integrada via Ducati Connect.', '<rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>' ),
        array( '4 Modos de Condu&ccedil;&atilde;o', 'Sport, Touring, Urban e Enduro &mdash; cada modo ajusta pot&ecirc;ncia, tra&ccedil;&atilde;o e suspens&atilde;o.', '<path d="M14 9V5a3 3 0 0 0-6 0v4"/><rect x="4" y="9" width="16" height="12" rx="2"/>' ),
        array( 'Ilumina&ccedil;&atilde;o Full LED', 'Farol DRL com cornering lights que acompanham a inclina&ccedil;&atilde;o da moto nas curvas.', '<circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>' ),
    );

    $o = '<style>';
    $o .= "#{$uid}{max-width:1100px;margin:0 auto;padding:70px 20px;font-family:'Segoe UI',Arial,sans-serif}";
    $o .= "#{$uid} .sh{text-align:center;margin-bottom:50px}";
    $o .= "#{$uid} .sh h2{font-size:clamp(24px,3vw,36px);font-weight:800;color:#1a1a1a;margin:0 0 10px}";
    $o .= "#{$uid} .sh p{font-size:16px;color:#666;max-width:600px;margin:0 auto}";
    $o .= "#{$uid} .fg{display:grid;grid-template-columns:repeat(3,1fr);gap:30px}";
    $o .= "#{$uid} .fc{background:#fafafa;border:1px solid #eee;border-radius:12px;padding:35px 25px;transition:transform .3s,box-shadow .3s}";
    $o .= "#{$uid} .fc:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(0,0,0,.08)}";
    $o .= "#{$uid} .fi{width:50px;height:50px;background:{$atts['cor']};border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:20px}";
    $o .= "#{$uid} .fi svg{width:24px;height:24px}";
    $o .= "#{$uid} .fc h3{font-size:18px;font-weight:700;color:#1a1a1a;margin:0 0 10px}";
    $o .= "#{$uid} .fc p{font-size:14px;color:#666;line-height:1.6;margin:0}";
    $o .= "@media(max-width:768px){#{$uid} .fg{grid-template-columns:1fr}}";
    $o .= '</style>';
    $o .= '<section id="' . $uid . '">';
    $o .= '<div class="sh"><h2>' . $atts['titulo'] . '</h2>';
    if ( ! empty( $atts['subtitulo'] ) ) {
        $o .= '<p>' . $atts['subtitulo'] . '</p>';
    }
    $o .= '</div><div class="fg">';
    foreach ( $features as $f ) {
        $o .= '<div class="fc"><div class="fi"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">' . $f[2] . '</svg></div>';
        $o .= '<h3>' . $f[0] . '</h3><p>' . $f[1] . '</p></div>';
    }
    $o .= '</div></section>';
    return $o;
});

// [ducati_cta] — Call to Action
add_shortcode( 'ducati_cta', function( $atts ) {
    $atts = shortcode_atts( array(
        'titulo'       => 'Pronto para a Aventura?',
        'subtitulo'    => 'Agende um test-ride e descubra em primeira m&atilde;o.',
        'btn1_texto'   => 'Agendar Test-Ride',
        'btn1_url'     => '#',
        'btn2_texto'   => 'Download Brochura',
        'btn2_url'     => '#',
        'cor'          => '#E32219',
        'bg'           => '#1a1a1a',
    ), $atts, 'ducati_cta' );

    $uid = 'dcta-' . wp_rand( 1000, 9999 );

    $o = '<style>';
    $o .= "#{$uid}{background:linear-gradient(160deg,{$atts['bg']} 0%,#2d0a08 60%,#4a0e0b 100%);padding:70px 20px;text-align:center;font-family:'Segoe UI',Arial,sans-serif}";
    $o .= "#{$uid} h2{font-size:clamp(24px,3vw,36px);font-weight:800;color:#fff;margin:0 0 15px}";
    $o .= "#{$uid} p{font-size:16px;color:rgba(255,255,255,.6);margin:0 auto 35px;max-width:500px}";
    $o .= "#{$uid} .cta-btns{display:flex;gap:15px;justify-content:center;flex-wrap:wrap}";
    $o .= "#{$uid} .btn-p{display:inline-flex;align-items:center;gap:8px;background:{$atts['cor']};color:#fff;font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:1px;padding:16px 35px;border-radius:4px;text-decoration:none;transition:.3s}";
    $o .= "#{$uid} .btn-p:hover{filter:brightness(.9);transform:translateY(-2px)}";
    $o .= "#{$uid} .btn-s{display:inline-flex;align-items:center;gap:8px;background:transparent;color:#fff;font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:1px;padding:16px 35px;border-radius:4px;border:1px solid rgba(255,255,255,.3);text-decoration:none;transition:.3s}";
    $o .= "#{$uid} .btn-s:hover{border-color:#fff;background:rgba(255,255,255,.05)}";
    $o .= '</style>';
    $o .= '<section id="' . $uid . '">';
    $o .= '<h2>' . $atts['titulo'] . '</h2>';
    $o .= '<p>' . $atts['subtitulo'] . '</p>';
    $o .= '<div class="cta-btns">';
    $o .= '<a href="' . esc_url( $atts['btn1_url'] ) . '" class="btn-p">' . esc_html( $atts['btn1_texto'] ) . '</a>';
    if ( ! empty( $atts['btn2_texto'] ) ) {
        $o .= '<a href="' . esc_url( $atts['btn2_url'] ) . '" class="btn-s">' . esc_html( $atts['btn2_texto'] ) . '</a>';
    }
    $o .= '</div></section>';
    return $o;
});

// =============================================
// [ducati_360] — Visualizador 360° SpriteSpin com seletor de cores
// Uso: [ducati_360] (config global) ou [ducati_360 id="multistrada-v4"] (config por bloco)
// =============================================
add_shortcode( 'ducati_360', 'blkcloner_ducati_360_shortcode' );

if ( ! function_exists( 'blkcloner_ducati_360_shortcode' ) ) :
function blkcloner_ducati_360_shortcode( $atts ) {
    $atts = shortcode_atts( array( 'id' => '' ), $atts, 'ducati_360' );

    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'spritespin', 'https://unpkg.com/spritespin@4.1.0/release/spritespin.js', array( 'jquery' ), '4.1.0', true );

    // Carregar config: per-block (se id fornecido) ou global
    $block_id = sanitize_key( $atts['id'] );
    if ( ! empty( $block_id ) ) {
        $config = get_option( 'blkcloner_360_config_' . $block_id, array() );
        // Fallback para config global se não existir config per-block
        if ( empty( $config ) ) {
            $config = get_option( 'blkcloner_360_config', array() );
        }
    } else {
        $config = get_option( 'blkcloner_360_config', array() );
    }

    // Default bike data (user's exact URLs)
    $default_bike_data = array(
        'red' => array(
            'https://images.ctfassets.net/x7j9qwvpvr5s/24z719U8U2MXuHs6MyzRH5/2e4be4fa3bda51f7b76ae0e951352ec9/Multistrada-V4-S-Red-MY25-360_0017_it-15.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3bPKFh8jn5iqwmK7yA3qWS/b1069651adf9e059c20f3ca4e1cf682e/Multistrada-V4-S-Red-MY25-360_0018_it-16.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4Ebh1OmLXvMONI8kZRmsUl/960a14181d10a5ce8f43dd51f1ab2abd/Multistrada-V4-S-Red-MY25-360_0019_it-17.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1TZeuprhzw3Fos4Prbt3Gq/beac95a14b16d11ce402e3ae13e27193/Multistrada-V4-S-Red-MY25-360_0000_it-18.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4NoK72261BNFcKG6d2ZQvn/5629e25dadc1a8fc4a3b89f051390202/Multistrada-V4-S-Red-MY25-360_0001_it-19.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6pOZD1nSa7JN5BFnOK8fsM/80ca2c18a66c6858c01dc13a4236c100/Multistrada-V4-S-Red-MY25-360_0002_it.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6IkPU9lWoDu1CTwZwkb95s/5f1bb6254a5156c10980bf0642281459/Multistrada-V4-S-Red-MY25-360_0003_it-1.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6vlxOPXluPTNWMlB0jJQtu/2a6c39e3d3f26a9949b027c8b50dde4e/Multistrada-V4-S-Red-MY25-360_0004_it-2.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4D8Mg1NLZ6kzYVOtqtqSCv/08727aa2d1c62ad0201670011899f5af/Multistrada-V4-S-Red-MY25-360_0005_it-3.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4GB70WsPHwN84eaQNlIRkH/29ee3ad59b7ca3fae4731a240882dcd9/Multistrada-V4-S-Red-MY25-360_0006_it-4.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6tCV7l2SqwjxIOzrqFozS2/dbf53fb733af9d2faed49bcfa4bb4900/Multistrada-V4-S-Red-MY25-360_0007_it-5.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/ZhH3d1UwDPz5fbuNesDnX/20a2e6ebf02acd3d2820d34ec1d79053/Multistrada-V4-S-Red-MY25-360_0008_it-6.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3tcYzZwtHe1fUzq7YXwwgt/cb5d44cc78f03d913edde5bcb96201b5/Multistrada-V4-S-Red-MY25-360_0009_it-7.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1zBOZbAf7QYDMooRc9HxDa/023ecace1257caffac3fa9928e1d5c41/Multistrada-V4-S-Red-MY25-360_0010_it-8.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/2PmbBimUCLsPqQ2nUGNm5t/5cea728f8f98ecbb4e63537d6097e487/Multistrada-V4-S-Red-MY25-360_0011_it-9.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/2cXaxqfBNy7n7XbSDopEI9/43ad9125aed30df60105e354e7ea97ad/Multistrada-V4-S-Red-MY25-360_0012_it-10.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6yLH0urLDwNPyNXTk1MyJ6/13d4a713177b10012326da2bc49950da/Multistrada-V4-S-Red-MY25-360_0013_it-11.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/5yoJQeBiZ7zUTWVuSx6zaS/259f8d41d5f1d1aa8f5f058d2b169486/Multistrada-V4-S-Red-MY25-360_0014_it-12.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/7k6WmjBYUbHT7sXEN8Jnzd/c2cfc3631b51bc6019317dfe7c526ef7/Multistrada-V4-S-Red-MY25-360_0015_it-13.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6JSqkGgxFCkYjrJfvqo0UH/422be16daae832ee6b330380f5a75baf/Multistrada-V4-S-Red-MY25-360_0016_it-14.png',
        ),
        'black' => array(
            'https://images.ctfassets.net/x7j9qwvpvr5s/1NwzcgiivZs7gRMuIIKTq1/79853368e815b29c8ce5e8852bf6f37c/Multistrada-V4-S-TB-MY25-360_0017_it-15.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3z84QuuL26dFCpZXXWhfYs/11adbf56d8e14ab4c1e7a08835c6bb85/Multistrada-V4-S-TB-MY25-360_0018_it-16.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1IcWINYmlKCJpDUz04G7CW/a516e4473ae37674f21f2d9eadf49fac/Multistrada-V4-S-TB-MY25-360_0019_it-17.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6ttdtYxVJbHTbeLEkXYY6c/7ca2b9fe99cccd5f27d79a60701659c0/Multistrada-V4-S-TB-MY25-360_0000_it-18.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/Er6Q1uyrXGe1qlc7kzsXk/4ccc68c42872b43a7b9398f3149def55/Multistrada-V4-S-TB-MY25-360_0001_it-19.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4QT4n5hGxjM9okzKGeHPN3/4a090bbebfc07562e79d19c9196897f1/Multistrada-V4-S-TB-MY25-360_0002_it.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/7kvyBm8l3pDxYsLdZt0fsb/9648101b50179fea297068c7fefb8e25/Multistrada-V4-S-TB-MY25-360_0003_it-1.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/k23IqFk9x4soc7dQQSOba/9afbec3e3860500389ce454db24676d5/Multistrada-V4-S-TB-MY25-360_0004_it-2.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/2noDntePzDWr0NHbJWgLGv/6f5c2332044406da3602c395a8326c9a/Multistrada-V4-S-TB-MY25-360_0005_it-3.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1gkdvjAWumvx2W6ywdorbQ/d9c9ebbc18833338105e3368ed754160/Multistrada-V4-S-TB-MY25-360_0006_it-4.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1Vi3yX8sJ8SS5VAO94G7qP/719e454e77d4c0e6acf05beafc91fee0/Multistrada-V4-S-TB-MY25-360_0007_it-5.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/63dwnOsNG8eMiGwQU53Qt/ff4a98bdea9e91fab951b9453db5df47/Multistrada-V4-S-TB-MY25-360_0008_it-6.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/5rwPycQCxCeOyQptaNs9Kx/1eee67442f7bfa9ae947a8624ce49121/Multistrada-V4-S-TB-MY25-360_0009_it-7.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1DNZDyHHjzWCHnkLOpkavW/4eeb92da9095832851b5a48adfddca73/Multistrada-V4-S-TB-MY25-360_0010_it-8.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/2o8jhGeqzjIPBxOQJEqEen/507f0c69521e43c310c325fe10fb1d8c/Multistrada-V4-S-TB-MY25-360_0011_it-9.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/5bk0GFaQn1eq6qaUordvXr/7ad895883da90534074eb22c64448faf/Multistrada-V4-S-TB-MY25-360_0012_it-10.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/5Ei2OMCfugsgQ2zviPahc7/da2acefd99c7d10954a15831a0baf1c8/Multistrada-V4-S-TB-MY25-360_0013_it-11.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1HsXhdZgj67DiPYaZiNPG6/e158d4156f6b58e4240b0f128d70f9ed/Multistrada-V4-S-TB-MY25-360_0014_it-12.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/7CobxzYd7kRCjhGDa6ZRiF/fd4ef5a36997274c40cdd7f5b3463ecb/Multistrada-V4-S-TB-MY25-360_0015_it-13.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/20Xj7gxOTXdt6UwBzLYCd/1e9734a471615fad6b00334fdf4aa760/Multistrada-V4-S-TB-MY25-360_0016_it-14.png',
        ),
        'white' => array(
            'https://images.ctfassets.net/x7j9qwvpvr5s/3AljQrgo9fhA0AuwZCQjXl/480aa1b3dc82fe725cfdf9010a14b3ca/Multistrada-V4-S-AW-MY25-360_0017_it-14.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3oX5y56QVntmmS8AoYGQbB/c21178735f0e8ec8a5c18d0ba4f0fc2b/Multistrada-V4-S-AW-MY25-360_0018_it-15.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/6Yev22pmSeyokmnPlBWIhu/819e84f92f65b38fd9b43503b882b250/Multistrada-V4-S-AW-MY25-360_0019_it-16.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/7dhShE4Yx7YRfDqkVtYUO4/a85511b008df3a7dbfa900696f8e03d0/Multistrada-V4-S-AW-MY25-360_0000_it-17.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/303RW4q5vqXacdHCLot8UF/0c771617aa8978b89987f161b3f0ec2b/Multistrada-V4-S-AW-MY25-360_0001_it-18.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/IVfmOH9n9O9IiQWCVigGe/c8fc8fc30634c350b7b90c21d6ae29d7/Multistrada-V4-S-AW-MY25-360_0002_it.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4tD9WPUVYFsc5T9H0ED0ub/daa7988a1b52e916cb445b24bf8dbeb0/Multistrada-V4-S-AW-MY25-360_0003_it-1.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/5IPZGQcuu0TPHizN3SZz80/9ee219bdc5aac90b08086d0f792ac0dc/Multistrada-V4-S-AW-MY25-360_0004_it-2-1.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3B9VC66OG5WbBKzQBdkMVC/91b349f700390bb5f301fad03a8180ec/Multistrada-V4-S-AW-MY25-360_0005_it-2.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1wRc7UkJ0aAteTaqqkNZHj/2cbcf1c6e9672835ac35abac1ae79ff1/Multistrada-V4-S-AW-MY25-360_0006_it-3.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4p5yjguGanF37RYdwnTVX/8134f8d6e80f92959ceedd8b03070ef4/Multistrada-V4-S-AW-MY25-360_0007_it-4.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3SDmRwmcGYeLe7cQbLcrgo/16b33d70c359a8ec43f428dc8c932c50/Multistrada-V4-S-AW-MY25-360_0008_it-5.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/1z1Fo4BSVG1LQlYns5VUxJ/61f420cf56a3a75697bda2acd6b3778e/Multistrada-V4-S-AW-MY25-360_0009_it-6.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/4oL9KQdVKiKhJdRp1cz6J8/7d72262a2c3c0577828bdd28ed96cd00/Multistrada-V4-S-AW-MY25-360_0010_it-7.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/5Ndat6WFM0NoDK9gDSJGAC/c6ab2166eed72bd82eca4e311cff40df/Multistrada-V4-S-AW-MY25-360_0011_it-8.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3zuAnsDVVZIaDztewSuNS6/adfcb87068e791e76fb64ae486a4edc1/Multistrada-V4-S-AW-MY25-360_0012_it-9.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/2uMVV9PExqj7zn9AostbbF/9d3f118c86ecd3518bfa4560bbf646d3/Multistrada-V4-S-AW-MY25-360_0013_it-10.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/3eaboKTlyF1AlV2PtPpmi4/7f50a095c4d869880dced8b35ab6932e/Multistrada-V4-S-AW-MY25-360_0014_it-11.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/2i3V2TSgVpwbKbS5X44tFE/bcc2d0704e0a0b18ff191219f8b45405/Multistrada-V4-S-AW-MY25-360_0015_it-12.png',
            'https://images.ctfassets.net/x7j9qwvpvr5s/29jubc2v9GdUSW77Ixh4kc/5aae4e7b978a344eb3096d824ec70adc/Multistrada-V4-S-AW-MY25-360_0016_it-13.png',
        ),
    );

    // Default color buttons config
    $default_colors = array(
        array( 'key' => 'red',   'name' => 'Ducati Red',      'icon' => 'https://images.ctfassets.net/x7j9qwvpvr5s/5tWHLQRM7PCisPbtrp9whY/942a0d43734b0c593c31c6dd310b1e41/Multistrada-V4-Red-Alloy-icone-Colore-100x100.png' ),
        array( 'key' => 'black', 'name' => 'Thrilling Black', 'icon' => 'https://images.ctfassets.net/x7j9qwvpvr5s/2nI2hqmvUpDiLa0p9v3dQE/3ea548be7b2fba2b14fbbde405755e70/Multistrada-V4-TB-Alloy-icone-Colore-100x100.png' ),
        array( 'key' => 'white', 'name' => 'Arctic White',    'icon' => 'https://images.ctfassets.net/x7j9qwvpvr5s/5zTBDlGM7mOV1P0kPzXIYl/d886d8771db61e160cb9be6093de605e/Multistrada-V4-AW-Alloy-icone-Colore-100x100.png' ),
    );

    // Use saved config or defaults
    $bike_data = ! empty( $config['bike_data'] ) ? $config['bike_data'] : $default_bike_data;
    $colors    = ! empty( $config['colors'] )    ? $config['colors']    : $default_colors;
    $bg_url    = ! empty( $config['bg_url'] )    ? $config['bg_url']    : '';
    $bg_pos    = ! empty( $config['bg_position'] ) ? $config['bg_position'] : 'center';

    // Dimensões configuráveis
    $container_w  = ! empty( $config['container_width'] ) ? $config['container_width'] : '1100px';
    $sprite_w     = ! empty( $config['sprite_width'] )    ? intval( $config['sprite_width'] )  : 1920;
    $sprite_h     = ! empty( $config['sprite_height'] )   ? intval( $config['sprite_height'] ) : 1080;
    $btn_size     = ! empty( $config['btn_size'] )        ? intval( $config['btn_size'] )      : 45;
    $active_color = ! empty( $config['active_color'] )    ? $config['active_color']            : '#E32219';
    $name_color   = ! empty( $config['name_color'] )      ? $config['name_color']              : '#E32219';

    $first_color = $colors[0]['key'];
    $first_name  = $colors[0]['name'];

    // Unique IDs per instance (prevent conflicts with multiple shortcodes)
    $uid      = 'dc360-' . wp_rand( 1000, 9999 );
    $viewer_uid = $uid . '-viewer';
    $hint_uid   = $uid . '-hint';
    $name_uid   = $uid . '-name';

    // Controls position from config
    $controls_pos = ! empty( $config['controls_position'] ) ? $config['controls_position'] : 'bottom';
    $controls_offset_x = isset( $config['controls_offset_x'] ) ? intval( $config['controls_offset_x'] ) : 0;
    $controls_offset_y = isset( $config['controls_offset_y'] ) ? intval( $config['controls_offset_y'] ) : 0;

    // Build controls positioning CSS
    $controls_css = '';
    switch ( $controls_pos ) {
        case 'top':
            $controls_css = "order: -1; margin-bottom: -20px; margin-top: 0;";
            break;
        case 'left':
            $controls_css = "position: absolute; left: 0; top: 50%; transform: translateY(-50%); flex-direction: column;";
            break;
        case 'right':
            $controls_css = "position: absolute; right: 0; top: 50%; transform: translateY(-50%); flex-direction: column;";
            break;
        default: // bottom
            $controls_css = '';
            break;
    }
    if ( $controls_offset_x || $controls_offset_y ) {
        $controls_css .= " margin-left: {$controls_offset_x}px; margin-top: {$controls_offset_y}px;";
    }

    ob_start();
    ?>
<style>
#<?php echo $uid; ?> .ducati-lisboa-360-wrapper { width: 100%; display: flex; flex-direction: column; align-items: center; position: relative; z-index: 9999; font-family: Arial, sans-serif; overflow: visible; }
#<?php echo $uid; ?> .moto-container { width: 100%; max-width: <?php echo esc_attr( $container_w ); ?>; position: relative; z-index: 9999; cursor: grab; overflow: hidden; min-height: 200px; }
#<?php echo $uid; ?> .spritespin-stage { overflow: hidden !important; }
#<?php echo $uid; ?> .spritespin-stage img { max-width: 100%; height: auto; display: block; }
#<?php echo $uid; ?> .moto-container:active { cursor: grabbing; }
#<?php echo $uid; ?> .moto-container > div:not(.rotation-overlay) { width: 100% !important; max-width: 100% !important; z-index: 9999; }
#<?php echo $uid; ?> .moto-container img, #<?php echo $uid; ?> .spritespin-stage img { -webkit-user-drag: none; user-select: none; -webkit-user-select: none; }
#<?php echo $uid; ?> .rotation-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; pointer-events: none; opacity: 0; visibility: hidden; transition: opacity 0.4s ease-in-out; display: flex; align-items: center; justify-content: center; }
#<?php echo $uid; ?> .rotation-overlay.visible { opacity: 1; visibility: visible; }
#<?php echo $uid; ?> .drag-indicator { background: rgba(0, 0, 0, 0.3); width: 70px; height: 70px; border-radius: 50%; border: 1px solid rgba(255, 255, 255, 0.4); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 9999; }
#<?php echo $uid; ?> .drag-indicator svg { width: 45px; height: 45px; filter: drop-shadow(0px 0px 3px rgba(0,0,0,0.8)); }
#<?php echo $uid; ?> .ducati-controls-area { display: flex; flex-direction: column; align-items: center; gap: 15px; margin-top: -20px; padding-bottom: 40px; position: relative; z-index: 9999; <?php echo $controls_css; ?> }
#<?php echo $uid; ?> .ducati-selector { display: flex; gap: 20px; }
#<?php echo $uid; ?> .color-btn { width: <?php echo intval( $btn_size ); ?>px; height: <?php echo intval( $btn_size ); ?>px; background-size: cover; border-radius: 50%; cursor: pointer; border: 2px solid #ddd; transition: 0.3s ease; position: relative; z-index: 9999; }
#<?php echo $uid; ?> .color-btn.active { border-color: <?php echo esc_attr( $active_color ); ?>; transform: scale(1.1); }
#<?php echo $uid; ?> .color-name-display { font-size: 13px; font-weight: 700; text-transform: uppercase; color: #333; }
#<?php echo $uid; ?> .dc360-color-name { color: <?php echo esc_attr( $name_color ); ?>; margin-left: 5px; }
#<?php echo $uid; ?> .ducati-lisboa-360-wrapper::after { content: "\00A9 Netseg Ib\00E9rica 2026 - C\00F3pia Proibida"; display: block; font-size: 1px; color: transparent; }
<?php if ( $controls_pos === 'left' || $controls_pos === 'right' ) : ?>
#<?php echo $uid; ?> .ducati-lisboa-360-wrapper { position: relative; }
#<?php echo $uid; ?> .ducati-selector { flex-direction: column; }
<?php endif; ?>
</style>
<div id="<?php echo esc_attr( $uid ); ?>" style="position:relative;z-index:9999;width:100%;display:block;">
<div class="ducati-lisboa-360-wrapper">
    <div class="moto-container">
        <div id="<?php echo esc_attr( $viewer_uid ); ?>"></div>
        <div class="rotation-overlay visible" id="<?php echo esc_attr( $hint_uid ); ?>">
            <div class="drag-indicator">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M7 6c2-1.5 4.5-2 7-1.5 2.5.5 4.5 2 6 4"/>
                    <polyline points="16 9 20 9 20 5"/>
                    <path d="M17 18c-2 1.5-4.5 2-7 1.5-2.5-.5-4.5-2-6-4"/>
                    <polyline points="8 15 4 15 4 19"/>
                </svg>
            </div>
        </div>
    </div>
    <div class="ducati-controls-area">
        <div class="ducati-selector">
            <?php foreach ( $colors as $i => $c ) : ?>
            <div class="color-btn<?php echo $i === 0 ? ' active' : ''; ?>" data-color="<?php echo esc_attr( $c['key'] ); ?>" data-name="<?php echo esc_attr( $c['name'] ); ?>" style="background-image: url('<?php echo esc_url( $c['icon'] ); ?>')"></div>
            <?php endforeach; ?>
        </div>
        <div class="color-name-display">
            COR: <span class="dc360-color-name" id="<?php echo esc_attr( $name_uid ); ?>"><?php echo esc_html( $first_name ); ?></span>
        </div>
    </div>
</div>
</div>
<script>
(function waitFor360(){
    if(typeof jQuery==="undefined"||!jQuery.fn.spritespin){setTimeout(waitFor360,100);return;}
    var $ = jQuery;
    var bikeData = <?php echo wp_json_encode( $bike_data, JSON_UNESCAPED_SLASHES ); ?>;
    var $wrapper = $("#<?php echo esc_js( $uid ); ?>");
    var $viewer = $("#<?php echo esc_js( $viewer_uid ); ?>");
    var $overlay = $("#<?php echo esc_js( $hint_uid ); ?>");
    function load360(color) {
        var stopTimer;
        var imgs = bikeData[color];
        if (!imgs || !imgs.length) return;
        var probe = new Image();
        probe.onload = function() {
            var natW = probe.naturalWidth || <?php echo intval( $sprite_w ); ?>;
            var natH = probe.naturalHeight || <?php echo intval( $sprite_h ); ?>;
            $viewer.spritespin({
                source: imgs,
                width: natW,
                height: natH,
                responsive: true,
                animate: false,
                touch: true,
                sense: -1.5,
                renderer: 'image',
                onInit: function() { $overlay.addClass('visible'); },
                onFrame: function() { $overlay.removeClass('visible'); clearTimeout(stopTimer); stopTimer = setTimeout(function() { $overlay.addClass('visible'); }, 250); },
                onDragStart: function() { $overlay.removeClass('visible'); }
            });
        };
        probe.onerror = function() {
            $viewer.spritespin({
                source: imgs,
                width: <?php echo intval( $sprite_w ); ?>,
                height: <?php echo intval( $sprite_h ); ?>,
                responsive: true,
                animate: false,
                touch: true,
                sense: -1.5,
                renderer: 'image',
                onInit: function() { $overlay.addClass('visible'); },
                onFrame: function() { $overlay.removeClass('visible'); clearTimeout(stopTimer); stopTimer = setTimeout(function() { $overlay.addClass('visible'); }, 250); },
                onDragStart: function() { $overlay.removeClass('visible'); }
            });
        };
        probe.src = imgs[0];
    }
    load360('<?php echo esc_js( $first_color ); ?>');
    $wrapper.find('.color-btn').on('click', function() {
        $wrapper.find('.color-btn').removeClass('active');
        $(this).addClass('active');
        var color = $(this).data('color');
        var name = $(this).data('name');
        $("#<?php echo esc_js( $name_uid ); ?>").text(name);
        load360(color);
    });
})();
</script>
    <?php
    return ob_get_clean();
}
endif;

// =============================================
// ALIAS: [blk-360-spritespin-render] → [ducati_360]
// =============================================
if ( ! shortcode_exists( 'blk-360-spritespin-render' ) ) {
    add_shortcode( 'blk-360-spritespin-render', 'blkcloner_ducati_360_shortcode' );
}

// =============================================
// PROXY DE IMAGENS (endpoint para servir imagens remotas)
// =============================================
add_action( 'init', function () {
    if ( ! isset( $_GET['blkcloner_proxy'] ) || empty( $_GET['url'] ) ) {
        return;
    }

    $url = esc_url_raw( urldecode( $_GET['url'] ) );

    if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
        status_header( 400 );
        exit( 'URL inválido' );
    }

    $allowed_ext = array( 'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'avif', 'ico', 'bmp' );
    $ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
    if ( ! in_array( $ext, $allowed_ext, true ) ) {
        status_header( 403 );
        exit( 'Tipo de ficheiro não permitido' );
    }

    $cache_dir = WP_CONTENT_DIR . '/cache/block-cloner/';
    $filename  = md5( $url ) . '.' . $ext;
    $cache_file = $cache_dir . $filename;

    if ( file_exists( $cache_file ) && ( time() - filemtime( $cache_file ) ) < DAY_IN_SECONDS ) {
        $mime = wp_check_filetype( $cache_file );
        header( 'Content-Type: ' . ( $mime['type'] ?: 'image/jpeg' ) );
        header( 'Cache-Control: public, max-age=86400' );
        readfile( $cache_file );
        exit;
    }

    $response = wp_remote_get( $url, array(
        'timeout'    => 15,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'sslverify'  => false,
    ));

    if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
        status_header( 502 );
        exit( 'Não foi possível descarregar a imagem' );
    }

    $body = wp_remote_retrieve_body( $response );
    $content_type = wp_remote_retrieve_header( $response, 'content-type' );

    if ( ! file_exists( $cache_dir ) ) {
        wp_mkdir_p( $cache_dir );
    }
    file_put_contents( $cache_file, $body );

    header( 'Content-Type: ' . ( $content_type ?: 'image/jpeg' ) );
    header( 'Content-Length: ' . strlen( $body ) );
    header( 'Cache-Control: public, max-age=86400' );
    echo $body;
    exit;
});

// =============================================
// ELEMENTOR: CATEGORIA NETSEG WIDGET
// =============================================
add_action( 'elementor/elements/categories_registered', function ( $elements_manager ) {
    $elements_manager->add_category( 'netseg-widget', array(
        'title' => 'Netseg Widget',
        'icon'  => 'eicon-globe',
    ));
});

// =============================================
// ELEMENTOR WIDGETS
// =============================================
add_action( 'elementor/widgets/register', function ( $widgets_manager ) {
    if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
        return;
    }

    // ---- WIDGET 1: Netseg Block Cloner Ducati ----
    if ( ! class_exists( 'Blkcloner_Elementor_Widget' ) ) :
    class Blkcloner_Elementor_Widget extends \Elementor\Widget_Base {
        public function get_name() { return 'cloned_block'; }
        public function get_title() { return 'Netseg Block Cloner Ducati'; }
        public function get_icon() { return 'eicon-download-bold'; }
        public function get_categories() { return array( 'netseg-widget' ); }
        public function get_keywords() { return array( 'netseg', 'clone', 'block', 'scrape', 'copy', 'ducati' ); }

        protected function register_controls() {
            $this->start_controls_section( 'section_content', array( 'label' => 'Block Cloner' ));

            $saved = get_option( BLKCLONER_OPTION_KEY, array() );
            $options = array( '' => 'Selecionar bloco...' );
            if ( is_array( $saved ) ) {
                foreach ( $saved as $id => $block ) {
                    $options[ $id ] = ( $block['name'] ?? 'Sem nome' ) . ' (' . $id . ')';
                }
            }

            $this->add_control( 'block_id', array(
                'label' => 'Bloco', 'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $options, 'default' => '',
            ));
            $this->add_control( 'max_width', array(
                'label' => 'Largura Máxima', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '100%',
            ));
            $this->add_control( 'align', array(
                'label' => 'Alinhamento', 'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(
                    'left'   => array( 'title' => 'Esquerda', 'icon' => 'eicon-text-align-left' ),
                    'center' => array( 'title' => 'Centro', 'icon' => 'eicon-text-align-center' ),
                    'right'  => array( 'title' => 'Direita', 'icon' => 'eicon-text-align-right' ),
                ),
                'default' => 'center',
            ));
            $this->add_control( 'responsive', array(
                'label' => 'Responsivo', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes',
            ));

            $this->end_controls_section();
        }

        protected function render() {
            $settings = $this->get_settings_for_display();
            $block_id = $settings['block_id'] ?? '';
            if ( empty( $block_id ) ) {
                if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                    echo '<div style="padding:40px;text-align:center;background:#f0f6fc;border:2px dashed #72aee6;border-radius:8px;">'
                        . '<span class="dashicons dashicons-download" style="font-size:40px;color:#72aee6;"></span>'
                        . '<p style="margin:10px 0 0;color:#2271b1;">Selecione um bloco clonado nas configurações.</p></div>';
                }
                return;
            }

            // No editor Elementor, mostrar placeholder (inline scripts não funcionam via AJAX/innerHTML)
            if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                $saved = get_option( BLKCLONER_OPTION_KEY, array() );
                $block_name = isset( $saved[ $block_id ] ) ? ( $saved[ $block_id ]['name'] ?? $block_id ) : $block_id;
                echo '<div style="padding:30px;text-align:center;background:#f0f6fc;border:2px solid #72aee6;border-radius:8px;">'
                    . '<span class="dashicons dashicons-visibility" style="font-size:32px;color:#2271b1;"></span>'
                    . '<p style="margin:10px 0 5px;color:#1d2327;font-weight:600;">Block Cloner: ' . esc_html( $block_name ) . '</p>'
                    . '<p style="margin:0;color:#646970;font-size:12px;">O bloco será visível na página publicada (frontend).</p>'
                    . '<code style="display:inline-block;margin-top:8px;padding:4px 10px;background:#fff;border:1px solid #c3c4c7;border-radius:3px;font-size:11px;color:#1d2327;">[cloned_block id="' . esc_attr( $block_id ) . '"]</code>'
                    . '</div>';
                return;
            }

            echo do_shortcode( '[cloned_block id="' . esc_attr( $block_id ) . '" max_width="' . esc_attr( $settings['max_width'] ?? '100%' ) . '" align="' . esc_attr( $settings['align'] ?? 'center' ) . '" responsive="' . ( ( $settings['responsive'] ?? 'yes' ) === 'yes' ? 'yes' : 'no' ) . '"]' );
        }
    }
    endif;
    $widgets_manager->register( new Blkcloner_Elementor_Widget() );

    // ---- WIDGET 2: Netseg Hero Ducati (Background + Overlay) ----
    if ( ! class_exists( 'Blkcloner_Hero_Widget' ) ) :
    class Blkcloner_Hero_Widget extends \Elementor\Widget_Base {
        public function get_name() { return 'cloned_block_hero'; }
        public function get_title() { return 'Netseg Hero Ducati'; }
        public function get_icon() { return 'eicon-image-bold'; }
        public function get_categories() { return array( 'netseg-widget' ); }
        public function get_keywords() { return array( 'netseg', 'clone', 'hero', 'background', 'video', 'ducati' ); }

        protected function register_controls() {
            // SECÇÃO: BACKGROUND
            $this->start_controls_section( 'section_bg', array( 'label' => 'Background' ));

            $this->add_control( 'bg_type', array(
                'label' => 'Tipo', 'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array( 'image' => 'Imagem', 'video' => 'Vídeo' ), 'default' => 'image',
            ));
            $this->add_control( 'bg_image', array(
                'label' => 'Imagem de Background', 'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => array( 'url' => '' ), 'condition' => array( 'bg_type' => 'image' ),
            ));
            $this->add_control( 'bg_image_url', array(
                'label' => 'Ou URL da Imagem', 'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => 'https://...', 'condition' => array( 'bg_type' => 'image' ),
            ));
            $this->add_control( 'bg_video_media', array(
                'label' => 'Vídeo da Galeria', 'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => array( 'video' ), 'default' => array( 'url' => '' ),
                'condition' => array( 'bg_type' => 'video' ),
            ));
            $this->add_control( 'bg_video_url', array(
                'label' => 'Ou URL do Vídeo', 'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => 'https://...mp4', 'condition' => array( 'bg_type' => 'video' ),
            ));
            $this->add_control( 'bg_height', array(
                'label' => 'Altura', 'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array( 'px' => array( 'min' => 300, 'max' => 1200, 'step' => 10 ), 'vh' => array( 'min' => 30, 'max' => 100 ) ),
                'size_units' => array( 'px', 'vh' ), 'default' => array( 'size' => 70, 'unit' => 'vh' ),
            ));

            $this->end_controls_section();

            // SECÇÃO: OVERLAY
            $this->start_controls_section( 'section_overlay', array( 'label' => 'Block Cloner Overlay' ));

            $saved = get_option( BLKCLONER_OPTION_KEY, array() );
            $options = array( '' => 'Selecionar bloco...' );
            if ( is_array( $saved ) ) {
                foreach ( $saved as $id => $block ) {
                    $options[ $id ] = ( $block['name'] ?? 'Sem nome' ) . ' (' . $id . ')';
                }
            }

            $this->add_control( 'block_id', array(
                'label' => 'Bloco Clonado', 'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $options, 'default' => '',
            ));
            $this->add_control( 'overlay_width', array(
                'label' => 'Largura do Overlay', 'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array( '%' => array( 'min' => 30, 'max' => 100 ) ),
                'size_units' => array( '%' ), 'default' => array( 'size' => 60, 'unit' => '%' ),
            ));
            $this->add_control( 'overlay_offset', array(
                'label' => 'Saída pelo Rodapé (%)',
                'description' => 'Quanto do bloco sai para fora do background pelo fundo.',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array( '%' => array( 'min' => 0, 'max' => 50 ) ),
                'size_units' => array( '%' ), 'default' => array( 'size' => 25, 'unit' => '%' ),
            ));

            $this->end_controls_section();
        }

        protected function render() {
            $s = $this->get_settings_for_display();
            $block_id = $s['block_id'] ?? '';
            $bg_type = $s['bg_type'] ?? 'image';

            $bg_url = '';
            if ( $bg_type === 'image' ) {
                $bg_url = $s['bg_image']['url'] ?? '';
                if ( empty( $bg_url ) && ! empty( $s['bg_image_url']['url'] ) ) {
                    $bg_url = $s['bg_image_url']['url'];
                }
            } else {
                $bg_url = $s['bg_video_media']['url'] ?? '';
                if ( empty( $bg_url ) && ! empty( $s['bg_video_url']['url'] ) ) {
                    $bg_url = $s['bg_video_url']['url'];
                }
            }

            $height = ( $s['bg_height']['size'] ?? 70 ) . ( $s['bg_height']['unit'] ?? 'vh' );
            $overlay_w = ( $s['overlay_width']['size'] ?? 60 ) . '%';
            $offset = ( $s['overlay_offset']['size'] ?? 25 );
            $uid = 'blkcloner-hero-' . $this->get_id();

            echo '<div id="' . esc_attr( $uid ) . '" style="position:relative;width:100%;overflow:visible;margin-bottom:' . intval( $offset * 3 ) . 'px;">';

            // Background
            echo '<div style="position:relative;width:100%;height:' . esc_attr( $height ) . ';overflow:hidden;">';
            if ( $bg_type === 'video' && ! empty( $bg_url ) ) {
                echo '<video autoplay muted loop playsinline style="position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;transform:translate(-50%,-50%);object-fit:cover;">';
                echo '<source src="' . esc_url( $bg_url ) . '" type="video/mp4"></video>';
            } elseif ( ! empty( $bg_url ) ) {
                echo '<div style="position:absolute;top:0;left:0;right:0;bottom:0;background:url(' . esc_url( $bg_url ) . ') center/cover no-repeat;"></div>';
            } else {
                echo '<div style="position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(135deg,#1d2327,#2271b1);"></div>';
            }
            echo '</div>';

            // Overlay
            if ( ! empty( $block_id ) ) {
                echo '<div style="position:absolute;bottom:-' . intval( $offset ) . '%;left:50%;transform:translateX(-50%);width:' . esc_attr( $overlay_w ) . ';z-index:10;">';
                echo do_shortcode( '[cloned_block id="' . esc_attr( $block_id ) . '" max_width="100%" overflow="visible" background="transparent"]' );
                echo '</div>';
            } elseif ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                echo '<div style="position:absolute;bottom:-10%;left:50%;transform:translateX(-50%);width:60%;z-index:10;">';
                echo '<div style="padding:40px;text-align:center;background:rgba(255,255,255,0.9);border:2px dashed #72aee6;border-radius:8px;">';
                echo '<p style="margin:0;color:#2271b1;">Selecione um bloco clonado nas configurações.</p></div></div>';
            }

            echo '</div>';
        }
    }
    endif;
    $widgets_manager->register( new Blkcloner_Hero_Widget() );

}, 10 );

// =============================================
// [cloned_block_test] — Diagnóstico de front page
// Uso: [cloned_block_test id="blk_xxxxx"]
// Mostra painel de diagnóstico para verificar por que o bloco não aparece
// =============================================
add_shortcode( 'cloned_block_test', function( $atts ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return '';
    }

    $atts = shortcode_atts( array( 'id' => '' ), $atts, 'cloned_block_test' );
    $block_id = sanitize_text_field( $atts['id'] );

    $tests = array();

    // 1. Verificar se o plugin está carregado
    $tests[] = array( true, 'Plugin carregado', 'v' . BLKCLONER_VERSION );

    // 2. Verificar contexto da página
    $page_type = 'desconhecido';
    if ( function_exists( 'is_front_page' ) && is_front_page() ) $page_type = 'front_page';
    elseif ( function_exists( 'is_home' ) && is_home() ) $page_type = 'home (blog)';
    elseif ( function_exists( 'is_singular' ) && is_singular() ) $page_type = 'singular (post/page)';
    elseif ( function_exists( 'is_archive' ) && is_archive() ) $page_type = 'archive';
    $tests[] = array( true, 'Tipo de página', $page_type );

    // 3. Verificar se Elementor está ativo
    $elementor_active = class_exists( '\Elementor\Plugin' );
    $tests[] = array( $elementor_active, 'Elementor', $elementor_active ? 'ativo' : 'NÃO ENCONTRADO' );

    // 4. Verificar se bloco existe
    if ( ! empty( $block_id ) ) {
        $saved = get_option( BLKCLONER_OPTION_KEY, array() );
        $block_exists = isset( $saved[ $block_id ] );
        $tests[] = array( $block_exists, 'Bloco "' . $block_id . '"', $block_exists ? 'encontrado' : 'NÃO ENCONTRADO na BD' );

        if ( $block_exists ) {
            $block = $saved[ $block_id ];
            $has_html = ! empty( $block['html'] );
            $has_js   = ! empty( $block['js'] );
            $has_css  = ! empty( $block['css'] );
            $tests[] = array( $has_html, 'HTML do bloco', $has_html ? strlen( $block['html'] ) . ' bytes' : 'VAZIO' );
            $tests[] = array( $has_js, 'JS do bloco', $has_js ? strlen( $block['js'] ) . ' bytes' : 'VAZIO' );
            $tests[] = array( $has_css, 'CSS do bloco', $has_css ? strlen( $block['css'] ) . ' bytes' : 'VAZIO' );

            $has_360 = strpos( $block['html'] ?? '', 'moto-container' ) !== false
                || strpos( $block['html'] ?? '', 'ducati-lisboa-360-wrapper' ) !== false
                || strpos( $block['js'] ?? '', 'spritespin' ) !== false;
            $tests[] = array( true, 'Tipo 360°', $has_360 ? 'SIM (renderiza via iframe)' : 'NÃO (renderiza inline)' );
        }
    } else {
        $tests[] = array( false, 'Block ID', 'não fornecido — uso: [cloned_block_test id="blk_xxxxx"]' );
    }

    // 5. Verificar wp_footer
    $tests[] = array( true, 'do_shortcode', 'funciona (este teste prova-o)' );

    // 6. Licença
    $is_licensed = blkcloner_is_licensed();
    $tests[] = array( true, 'Licença', $is_licensed ? 'ativa' : 'não ativa (watermark visível)' );

    // 7. Tema e wp_footer
    $theme = wp_get_theme();
    $tests[] = array( true, 'Tema ativo', $theme->get( 'Name' ) . ' v' . $theme->get( 'Version' ) );

    // 8. Shortcodes registados
    $shortcodes = array( 'cloned_block', 'blk-360-spritespin-render' );
    foreach ( $shortcodes as $sc ) {
        $exists = shortcode_exists( $sc );
        $tests[] = array( $exists, 'Shortcode [' . $sc . ']', $exists ? 'registado' : 'NÃO REGISTADO' );
    }

    // 9. Verificar se o bloco está dentro de Elementor ou do conteúdo normal
    global $post;
    $in_elementor = false;
    $in_content   = false;
    if ( $post ) {
        $content = $post->post_content ?? '';
        if ( strpos( $content, 'cloned_block' ) !== false ) {
            $in_content = true;
        }
        $elementor_data = get_post_meta( $post->ID, '_elementor_data', true );
        if ( ! empty( $elementor_data ) && strpos( $elementor_data, 'cloned_block' ) !== false ) {
            $in_elementor = true;
        }
        $tests[] = array( true, 'Post ID', $post->ID . ' (' . $post->post_type . ')' );
        $tests[] = array( $in_content || $in_elementor, 'Shortcode no conteúdo', $in_elementor ? 'encontrado no Elementor data' : ( $in_content ? 'encontrado no post_content' : 'NÃO encontrado nesta página' ) );
    }

    // 10. Verificar se a página usa Elementor para renderizar
    $uses_elementor_render = false;
    if ( $post && class_exists( '\Elementor\Plugin' ) ) {
        $uses_elementor_render = \Elementor\Plugin::$instance->documents->get( $post->ID ) && get_post_meta( $post->ID, '_elementor_edit_mode', true ) === 'builder';
        $tests[] = array( true, 'Renderização', $uses_elementor_render ? 'Elementor Builder' : 'WordPress padrão (the_content)' );
    }

    // Construir painel HTML
    $html_top = '<div style="padding:15px;background:#1e1e2e;color:#cdd6f4;border:2px solid #89b4fa;border-radius:8px;font-family:monospace;font-size:12px;line-height:1.8;margin:20px 0;max-width:800px;">';
    $html_top .= '<div style="color:#89b4fa;font-size:14px;font-weight:700;margin-bottom:10px;">BLOCK CLONER TEST — v' . BLKCLONER_VERSION . '</div>';

    foreach ( $tests as $t ) {
        $icon = $t[0] ? '<span style="color:#a6e3a1;">&#10004;</span>' : '<span style="color:#f38ba8;">&#10008;</span>';
        $html_top .= '<div>' . $icon . ' <b>' . esc_html( $t[1] ) . ':</b> ' . esc_html( $t[2] ) . '</div>';
    }

    $html_top .= '<div style="margin-top:10px;color:#fab387;">Se tudo está OK acima, o bloco deve aparecer abaixo:</div>';
    $html_top .= '</div>';

    // JS diagnostic — executa no browser e mostra resultados na consola + no painel
    $js_diag_id = 'blktest-js-' . wp_rand( 1000, 9999 );
    $html_top .= '<div id="' . $js_diag_id . '" style="padding:10px;background:#181825;color:#a6adc8;border:1px solid #45475a;border-radius:6px;font-family:monospace;font-size:11px;line-height:1.8;margin:10px 0;max-width:800px;"></div>';
    $html_top .= '<script>(function(){';
    $html_top .= 'var p=document.getElementById("' . $js_diag_id . '");';
    $html_top .= 'function log(t,ok,d){var c=ok?"#a6e3a1":"#f38ba8";p.innerHTML+="<div style=\\"color:"+c+"\\"><b>JS: "+t+"</b> — "+d+"</div>";console.log("[BlockCloner Test]",t,d);}';
    $html_top .= 'log("jQuery",typeof jQuery!=="undefined","v"+(typeof jQuery!=="undefined"?jQuery.fn.jquery:"N/A"));';
    $html_top .= 'log("SpriteSpin",(typeof jQuery!=="undefined"&&jQuery.fn.spritespin),"plugin "+(typeof jQuery!=="undefined"&&jQuery.fn.spritespin?"carregado":"NÃO ENCONTRADO"));';
    // Check for iframes (360° blocks)
    $html_top .= 'var iframes=document.querySelectorAll("iframe[id*=blkcloner]");';
    $html_top .= 'log("Iframes 360°",iframes.length>0,iframes.length+" iframe(s) encontrado(s)");';
    // Check for blkcloner wrappers
    $html_top .= 'var wraps=document.querySelectorAll("[id*=blkcloner]");';
    $html_top .= 'log("Wrappers blkcloner",wraps.length>0,wraps.length+" elemento(s) com id blkcloner");';
    // Check computed visibility of all blkcloner elements
    $html_top .= 'wraps.forEach(function(el){var cs=getComputedStyle(el);var vis=cs.display!=="none"&&cs.visibility!=="hidden"&&parseFloat(cs.opacity)>0;var r=el.getBoundingClientRect();';
    $html_top .= 'log(el.id||el.className,vis,"display:"+cs.display+", visibility:"+cs.visibility+", opacity:"+cs.opacity+", size:"+Math.round(r.width)+"x"+Math.round(r.height)+", zIndex:"+cs.zIndex);});';
    // Check if any parent is hiding the element
    $html_top .= 'if(wraps.length>0){var el=wraps[0];var chain=[];var cur=el.parentElement;while(cur&&cur!==document.body){var cs=getComputedStyle(cur);if(cs.display==="none"||cs.visibility==="hidden"||cs.overflow==="hidden"&&cur.clientHeight<5){chain.push(cur.tagName+"#"+(cur.id||"")+" display:"+cs.display+" vis:"+cs.visibility+" overflow:"+cs.overflow+" h:"+cur.clientHeight);}cur=cur.parentElement;}';
    $html_top .= 'if(chain.length)log("Parent oculto",false,chain.join(" > "));else log("Parents",true,"nenhum parent esconde o bloco");}';
    // Check rotation overlay
    $html_top .= 'var rov=document.querySelector(".rotation-overlay");if(rov){var rcs=getComputedStyle(rov);log("rotation-overlay",true,"z:"+rcs.zIndex+", pos:"+rcs.position+", w:"+rcs.width+", display:"+rcs.display);}';
    $html_top .= '})();</script>';

    // Renderizar o bloco real abaixo do painel de diagnóstico
    if ( ! empty( $block_id ) ) {
        $html_top .= do_shortcode( '[cloned_block id="' . esc_attr( $block_id ) . '" debug="test"]' );
    }

    return $html_top;
});
