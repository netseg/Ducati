<?php
/**
 * Plugin Name:       Ducati Block Cloner
 * Plugin URI:        https://netseg.ai/block-cloner
 * Description:       Clone blocos interativos (galerias, configuradores, secções dinâmicas) de qualquer website para o seu WordPress com Elementor Pro. by Netseg.ai
 * Version:           2.1.1
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Eng. Fernando Condeço - Netseg.ai
 * Author URI:        https://netseg.ai
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ducati-block-cloner
 * Domain Path:       /languages
 *
 * @package           DucatiBlockCloner
 * @author            Eng. Fernando Condeço
 * @copyright         2024-2026 Netseg.ai - Todos os direitos reservados
 */

// Impedir acesso direto
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Evitar carregamento duplo (se Code Snippets ainda estiver ativo)
if ( defined( 'BLKCLONER_LOADED' ) ) {
    return;
}
define( 'BLKCLONER_LOADED', true );

// =============================================
// CONSTANTES DO PLUGIN
// =============================================
if ( ! defined( 'BLKCLONER_VERSION' ) ) {
    define( 'BLKCLONER_VERSION', '2.1.1' );
}
if ( ! defined( 'BLKCLONER_PLUGIN_FILE' ) ) {
    define( 'BLKCLONER_PLUGIN_FILE', __FILE__ );
}
if ( ! defined( 'BLKCLONER_PLUGIN_DIR' ) ) {
    define( 'BLKCLONER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'BLKCLONER_PLUGIN_URL' ) ) {
    define( 'BLKCLONER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'BLKCLONER_CACHE_DIR' ) ) {
    define( 'BLKCLONER_CACHE_DIR', WP_CONTENT_DIR . '/cache/block-cloner/' );
}
if ( ! defined( 'BLKCLONER_CACHE_URL' ) ) {
    define( 'BLKCLONER_CACHE_URL', content_url( 'cache/block-cloner/' ) );
}
if ( ! defined( 'BLKCLONER_OPTION_KEY' ) ) {
    define( 'BLKCLONER_OPTION_KEY', 'blkcloner_saved_blocks' );
}
if ( ! defined( 'BLKCLONER_TRANSIENT_PREFIX' ) ) {
    define( 'BLKCLONER_TRANSIENT_PREFIX', 'blkcloner_page_' );
}

// =============================================
// DESINSTALAÇÃO LIMPA
// =============================================
// A desinstalação é tratada pelo ficheiro uninstall.php
// (WordPress prioriza uninstall.php sobre register_uninstall_hook)

// =============================================
// CRIAR DIRETÓRIO DE CACHE NA ATIVAÇÃO
// =============================================
register_activation_hook( __FILE__, 'blkcloner_activate' );
function blkcloner_activate() {
    if ( ! file_exists( BLKCLONER_CACHE_DIR ) ) {
        wp_mkdir_p( BLKCLONER_CACHE_DIR );
        file_put_contents( BLKCLONER_CACHE_DIR . '.htaccess', "Options -Indexes\n" );
        file_put_contents( BLKCLONER_CACHE_DIR . 'index.php', '<?php // Silence is golden.' . "\n" );
    }
    // Executar verificação de upgrade na ativação
    blkcloner_check_upgrade();
}

// Garantir cache dir existe
if ( ! file_exists( BLKCLONER_CACHE_DIR ) ) {
    wp_mkdir_p( BLKCLONER_CACHE_DIR );
    file_put_contents( BLKCLONER_CACHE_DIR . '.htaccess', "Options -Indexes\n" );
    file_put_contents( BLKCLONER_CACHE_DIR . 'index.php', '<?php // Silence is golden.' . "\n" );
}

// =============================================
// ATUALIZAÇÃO E MIGRAÇÃO DE VERSÕES
// =============================================

/**
 * Verifica se houve atualização e executa migração.
 * Preserva todos os dados existentes (blocos, configs 360°, idioma, licença).
 * Desativa versões anteriores/duplicadas do plugin.
 */
function blkcloner_check_upgrade() {
    $stored_version = get_option( 'blkcloner_version', '' );

    // Se é a mesma versão, nada a fazer
    if ( $stored_version === BLKCLONER_VERSION ) {
        return;
    }

    $is_fresh_install = empty( $stored_version );
    $old_version      = $stored_version;

    // Procurar e desativar pastas de plugins duplicados/anteriores
    blkcloner_cleanup_old_plugins();

    // Garantir diretório de cache existe
    if ( ! file_exists( BLKCLONER_CACHE_DIR ) ) {
        wp_mkdir_p( BLKCLONER_CACHE_DIR );
        file_put_contents( BLKCLONER_CACHE_DIR . '.htaccess', "Options -Indexes\n" );
        file_put_contents( BLKCLONER_CACHE_DIR . 'index.php', '<?php // Silence is golden.' . "\n" );
    }

    // Atualizar versão na base de dados
    update_option( 'blkcloner_version', BLKCLONER_VERSION );

    // Guardar info de upgrade para mostrar aviso no admin
    if ( ! $is_fresh_install ) {
        // Atualização de versão conhecida
        set_transient( 'blkcloner_upgraded', array(
            'from' => $old_version,
            'to'   => BLKCLONER_VERSION,
        ), 3600 );
    } else {
        // Sem versão guardada — verificar se já existiam dados (versão antiga sem tracking)
        $has_blocks = get_option( 'blkcloner_saved_blocks', array() );
        if ( ! empty( $has_blocks ) ) {
            set_transient( 'blkcloner_upgraded', array(
                'from' => 'anterior',
                'to'   => BLKCLONER_VERSION,
            ), 3600 );
        }
    }
}

/**
 * Procura e desativa versões anteriores/duplicadas do plugin.
 * Não apaga ficheiros — apenas desativa para o utilizador poder eliminar manualmente.
 */
function blkcloner_cleanup_old_plugins() {
    if ( ! function_exists( 'get_plugins' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $all_plugins     = get_plugins();
    $current_basename = plugin_basename( BLKCLONER_PLUGIN_FILE );
    $old_plugins     = array();

    // Padrões para identificar versões anteriores do plugin
    $slug_patterns = array(
        'block-cloner',
        'ducati-block-cloner',
        'elementor-block-cloner',
        'blkcloner',
    );

    foreach ( $all_plugins as $plugin_file => $plugin_data ) {
        // Não tocar no plugin atual
        if ( $plugin_file === $current_basename ) {
            continue;
        }

        $plugin_slug = dirname( $plugin_file );
        $is_old      = false;

        // Verificar pelo slug da pasta
        foreach ( $slug_patterns as $pattern ) {
            if ( stripos( $plugin_slug, $pattern ) !== false ) {
                $is_old = true;
                break;
            }
        }

        // Verificar pelo nome do plugin
        if ( ! $is_old && isset( $plugin_data['Name'] ) ) {
            if ( stripos( $plugin_data['Name'], 'Block Cloner' ) !== false ||
                 stripos( $plugin_data['Name'], 'Ducati Block' ) !== false ) {
                $is_old = true;
            }
        }

        if ( $is_old ) {
            $old_plugins[] = $plugin_file;
        }
    }

    // Desativar plugins antigos encontrados
    if ( ! empty( $old_plugins ) ) {
        deactivate_plugins( $old_plugins, true );

        // Guardar lista para informar o utilizador
        set_transient( 'blkcloner_old_plugins_found', $old_plugins, 3600 );
    }
}

// Verificar upgrade no admin_init (cobre atualizações via FTP/ZIP/auto-update)
add_action( 'admin_init', 'blkcloner_check_upgrade' );

// =============================================
// AVISOS DE ATUALIZAÇÃO NO ADMIN
// =============================================
add_action( 'admin_notices', 'blkcloner_upgrade_notices' );

/**
 * Retorna o changelog HTML para uma versão específica.
 */
function blkcloner_get_changelog( $version ) {
    $logs = array(
        '2.1.1' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Dete&ccedil;&atilde;o de upgrade</strong> &mdash; WordPress deteta a nova vers&atilde;o automaticamente, desativa e permite apagar vers&otilde;es anteriores, preservando todos os blocos importados</li>'
            . '<li><strong>Corre&ccedil;&otilde;es v2.1.0</strong> &mdash; 360&deg; via srcdoc, remo&ccedil;&atilde;o de imagens na configura&ccedil;&atilde;o, op&ccedil;&atilde;o cor &uacute;nica, categoria Netseg Widget</li>'
            . '</ul>',
        '2.1.0' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Remoção de imagens na extração</strong> &mdash; Checkboxes na grelha de imagens permitem selecionar e apagar imagens desnecessárias antes de guardar, removendo-as também do JS 360° para evitar frames em branco</li>'
            . '<li><strong>Categoria Netseg Widget</strong> &mdash; Nova família "Netseg Widget" no Elementor para agrupar todos os widgets do plugin</li>'
            . '<li><strong>Widgets renomeados</strong> &mdash; Widgets agora chamam-se "Netseg Block Cloner Ducati" e "Netseg Hero Ducati"</li>'
            . '<li><strong>360° visível no frontend</strong> &mdash; Corrigido bug que impedia o SpriteSpin de aparecer na front page e nos widgets Elementor custom (CSS de visibilidade agora cobre .elementor-widget-cloned_block e .elementor-widget-cloned_block_hero)</li>'
            . '<li><strong>Fallback wp_footer melhorado</strong> &mdash; Script de inicialização de iframes agora executa sempre no frontend, não dependendo de flag global</li>'
            . '</ul>',
        '2.0.8' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix &ldquo;ID do bloco inv&aacute;lido&rdquo; ao carregar imagem no configurador</strong> &mdash; A valida&ccedil;&atilde;o do block_id no handler de upload de imagens usava regex <code>[a-f0-9]</code> (hexadecimal) mas os IDs s&atilde;o gerados com <code>wp_generate_password()</code> que produz caracteres <code>[a-z0-9]</code>. Blocos com letras g-z no ID falhavam ao carregar imagem ou submeter URL</li>'
            . '</ul>',
        '2.0.6' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix $post null na front page</strong> &mdash; Os hooks wp_enqueue_scripts e wp_head dependiam do global $post que pode ser null em front pages est&aacute;ticas com plugins de cache (WP Rocket, LiteSpeed, Autoptimize). jQuery n&atilde;o carregava e regras CSS Elementor n&atilde;o eram emitidas, tornando o bloco invis&iacute;vel</li>'
            . '<li><strong>Fallback get_queried_object()</strong> &mdash; Adicionados fallbacks get_queried_object() + get_option(&#039;page_on_front&#039;) em ambos os hooks para resolver $post mesmo quando o global n&atilde;o est&aacute; definido</li>'
            . '<li><strong>Teste de diagn&oacute;stico abrangente</strong> &mdash; Novo test-frontend-rendering.php com 80 verifica&ccedil;&otilde;es cobrindo: dete&ccedil;&atilde;o de shortcodes, CSS Elementor compat, iframe init, wp_footer fallback, $post edge cases, CSS scoping, gera&ccedil;&atilde;o JS 360&deg;, iframe document, repara&ccedil;&atilde;o de dados e simula&ccedil;&atilde;o completa de front page</li>'
            . '</ul>',
        '2.0.5' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix 360&deg; invis&iacute;vel na front page</strong> &mdash; Viewer 360&deg; aparecia em branco na p&aacute;gina publicada apesar de funcionar no editor Elementor. O script inline que preenchia o iframe era bloqueado/adiado por plugins de cache (WP Rocket, LiteSpeed, Autoptimize, Cloudflare Rocket Loader)</li>'
            . '<li><strong>wp_enqueue_scripts</strong> &mdash; Novo hook que carrega jQuery no frontend em p&aacute;ginas com shortcodes Block Cloner (verifica post_content e _elementor_data). Antes s&oacute; existia admin_enqueue_scripts</li>'
            . '<li><strong>CSS Elementor frontend</strong> &mdash; Regras CSS em wp_head que for&ccedil;am visibilidade nos containers .elementor-shortcode, .elementor-widget-shortcode e .elementor-invisible para contrariar anima&ccedil;&otilde;es de entrada e overflow:hidden</li>'
            . '<li><strong>Anti-defer no script iframe</strong> &mdash; Atributos data-cfasync, data-no-lazy, data-no-optimize, data-pagespeed-no-defer impedem plugins de cache de adiar o script cr&iacute;tico de inicializa&ccedil;&atilde;o do iframe</li>'
            . '<li><strong>Retry robusto</strong> &mdash; Init do iframe agora tenta 10 vezes com backoff exponencial (150ms a 2s) em vez de 1 tentativa de 100ms. Inclui try/catch no document.write() e fallbacks DOMContentLoaded + load</li>'
            . '<li><strong>wp_footer fallback</strong> &mdash; Script de reserva no wp_footer que re-executa inits pendentes (window._blkPending) ap&oacute;s carregamento da p&aacute;gina, incluindo integra&ccedil;&atilde;o com evento elementor/frontend/init</li>'
            . '</ul>',
        '1.2.2' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>drag-indicator z-index: 9999</strong> &mdash; CSS do .drag-indicator (s&iacute;mbolo de rota&ccedil;&atilde;o) adicionado com z-index:9999 no shortcode [cloned_block], iframe 360&deg; e preview admin &mdash; antes s&oacute; existia no [ducati_360]</li>'
            . '<li><strong>Fix imagem deformada/esticada</strong> &mdash; Removido aspect-ratio:16/9 for&ccedil;ado no .moto-container do [ducati_360] que causava esticamento vertical das imagens SpriteSpin</li>'
            . '<li><strong>Fix front page</strong> &mdash; Adicionado min-height:200px ao .moto-container + width:100%;display:block no wrapper exterior para garantir visibilidade na front page e em qualquer contexto Elementor</li>'
            . '<li><strong>overflow:hidden no .moto-container</strong> &mdash; Previne trail/ghost de imagens SpriteSpin + regras .spritespin-stage img com max-width:100%;height:auto para propor&ccedil;&atilde;o natural</li>'
            . '</ul>',
        '2.0.1' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix &ldquo;too much recursion&rdquo; no iframe 360&deg;</strong> &mdash; JS do iframe agora &eacute; regenerado a partir do bikeData extra&iacute;do em vez de usar o JS raw scraped que continha resize loops, jQuery-migrate conflicts e event handlers cascading</li>'
            . '<li><strong>Fun&ccedil;&atilde;o blkcloner_generate_clean_360_js()</strong> &mdash; Nova fun&ccedil;&atilde;o que extrai bikeData do JS guardado e gera c&oacute;digo limpo (mesmo padr&atilde;o do shortcode [ducati_360]) sem responsive:true, sem $(document).ready nesting, sem resize listeners</li>'
            . '<li><strong>Shortcode [blk-360-spritespin-render] registado</strong> &mdash; Alias para [ducati_360] &mdash; corrige diagn&oacute;stico que reportava shortcode n&atilde;o registado</li>'
            . '</ul>',
        '2.0.0' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>rotation-overlay z-index: 9999</strong> &mdash; S&iacute;mbolo de rota&ccedil;&atilde;o 360&deg; elevado para z-index:9999 em todos os contextos (shortcode, iframe, viewer inline) para garantir visibilidade sobre todos os elementos</li>'
            . '<li><strong>rotation-overlay no iframe</strong> &mdash; Adicionadas regras CSS expl&iacute;citas para .rotation-overlay dentro do iframe 360&deg; (position, z-index, flex centering, transi&ccedil;&atilde;o de opacidade)</li>'
            . '<li><strong>Diagn&oacute;stico front page refor&ccedil;ado</strong> &mdash; [cloned_block_test] agora verifica: shortcodes registados, presen&ccedil;a no Elementor data ou post_content, modo de renderiza&ccedil;&atilde;o (Elementor vs WordPress), Post ID</li>'
            . '<li><strong>Diagn&oacute;stico JS no browser</strong> &mdash; Painel JS runtime que verifica jQuery, SpriteSpin, iframes, wrappers, computed visibility, parents ocultos e rotation-overlay &mdash; resultados vis&iacute;veis no painel e na consola</li>'
            . '</ul>',
        '1.9.9' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix rotation-overlay centrado</strong> &mdash; CSS do shortcode [cloned_block] corrigido para usar top:0;left:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center (igual ao viewer 360&deg; e admin)</li>'
            . '<li><strong>Fundo transparente no iframe 360&deg;</strong> &mdash; O iframe do shortcode agora respeita background=&quot;transparent&quot; tanto no body do documento como no elemento iframe (allowtransparency)</li>'
            . '<li><strong>Fix .moto-container&gt;div no iframe</strong> &mdash; Adicionado :not(.rotation-overlay) no CSS do iframe e preview para n&atilde;o for&ccedil;ar width:100% no overlay</li>'
            . '<li><strong>Inicializa&ccedil;&atilde;o iframe robusta</strong> &mdash; Script de init usa DOMContentLoaded fallback e guard contra dupla inicializa&ccedil;&atilde;o para garantir renderiza&ccedil;&atilde;o na front page</li>'
            . '<li><strong>[cloned_block_test]</strong> &mdash; Novo shortcode de diagn&oacute;stico para front page: mostra tipo de p&aacute;gina, estado do bloco, e renderiza com debug=test</li>'
            . '</ul>',
        '1.9.8' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix arrasto/trail 360&deg; no widget</strong> &mdash; Removidas regras CSS que for&ccedil;avam visibility:visible e opacity:1 em TODAS as imagens SpriteSpin, impedindo o plugin de esconder frames inativos (causa do efeito ghost/trail)</li>'
            . '<li><strong>overflow:hidden consistente</strong> &mdash; Todos os containers (.moto-container, .spritespin-stage, .ducati-lisboa-360-wrapper) agora usam overflow:hidden tanto no shortcode como no preview</li>'
            . '<li><strong>Selector [class*=spritespin] removido</strong> &mdash; Regra gen&eacute;rica que apanhava elementos internos do SpriteSpin (frames individuais) foi substitu&iacute;da por selectores espec&iacute;ficos (.spritespin-stage, .spritespin-canvas)</li>'
            . '</ul>',
        '1.9.7' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Preview restaurado (v1.9.4)</strong> &mdash; CSS do preview reposto ao estado original sem regras canvas/spritespin-stage</li>'
            . '<li><strong>Shortcode: renderer:image + overflow:hidden</strong> &mdash; Restaurado renderer:image (como v1.9.5) com overflow:hidden para eliminar trail</li>'
            . '<li><strong>Fix ghost drag</strong> &mdash; CSS -webkit-user-drag:none nas imagens do SpriteSpin impede o browser de criar c&oacute;pias fantasma ao arrastar</li>'
            . '<li><strong>S&iacute;mbolo de rota&ccedil;&atilde;o centrado</strong> &mdash; rotation-overlay usa flexbox (width:100%;height:100%;display:flex;align-items:center;justify-content:center) para centrar perfeitamente o indicador</li>'
            . '</ul>',
        '1.9.6' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix imagens 360&deg; cortadas</strong> &mdash; Restaurado overflow:visible em todos os containers (.moto-container, .spritespin-stage, .ducati-lisboa-360-wrapper) &mdash; o overflow:hidden da v1.9.5 cortava as imagens</li>'
            . '<li><strong>Preview + shortcode + extra&ccedil;&atilde;o alinhados</strong> &mdash; CSS de overflow consistente (visible) em preview, iframe do shortcode e c&oacute;digo de extra&ccedil;&atilde;o</li>'
            . '<li><strong>Shortcode inline renderer:canvas</strong> &mdash; Shortcode [blk-360-spritespin-render] agora usa renderer:canvas (igual &agrave; extra&ccedil;&atilde;o) &mdash; elimina trail/arrasto sem cortar imagens</li>'
            . '</ul>',
        '1.9.0' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix definitivo &ldquo;too much recursion&rdquo;</strong> &mdash; JS 360&deg; regenerado a partir do bikeData extra&iacute;do; elimina TODO o c&oacute;digo original que conflitava com Elementor (resize loops, jQuery-migrate, events cascading)</li>'
            . '<li><strong>Imagens 360&deg; carregam</strong> &mdash; SpriteSpin inicializa com JS limpo sem responsive:true, sem $(document).ready nesting, sem resize listeners</li>'
            . '<li><strong>rotation-overlay centrado</strong> &mdash; CSS expl&iacute;cito position:absolute + translate(-50%,-50%) no overlay dentro de .moto-container (position:relative)</li>'
            . '<li><strong>Nomes das cores persistem</strong> &mdash; JS regenerado l&ecirc; data-name dos bot&otilde;es; click handlers sincronizam com .color-name-display</li>'
            . '<li><strong>Posi&ccedil;&atilde;o do selector grava</strong> &mdash; [cloned_block] l&ecirc; config do bloco e aplica controls_position (top/bottom/left/right) + flex-direction:column para left/right</li>'
            . '<li><strong>Configurador n&atilde;o fecha ao gravar</strong> &mdash; Mant&eacute;m-se aberto ap&oacute;s guardar</li>'
            . '</ul>',
        '1.8.2' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Fix centramento drag-indicator</strong> &mdash; Regra CSS .moto-container&gt;div for&ccedil;ava rotation-overlay a 100% largura; corrigido com :not(.rotation-overlay)</li>'
            . '<li><strong>Teste diagn&oacute;stico 360&deg;</strong> &mdash; [cloned_block id=&quot;xxx&quot; debug=&quot;test&quot;] mostra painel + bloco real com verifica&ccedil;&otilde;es runtime (jQuery, SpriteSpin, imagens, viewer)</li>'
            . '</ul>',
        '1.8.1' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Drag-indicator centrado</strong> &mdash; Indicador de rota&ccedil;&atilde;o 360&deg; centrado no viewer desde o in&iacute;cio (aspect-ratio 16/9)</li>'
            . '<li><strong>Fix apagar cores</strong> &mdash; Corrigido bug que somava bot&otilde;es de cor em vez de apagar (regex non-greedy no save_config)</li>'
            . '<li><strong>Navega&ccedil;&atilde;o configurador</strong> &mdash; Ap&oacute;s guardar configura&ccedil;&atilde;o, regressa &agrave; tab Blocos Guardados em vez de voltar ao in&iacute;cio</li>'
            . '</ul>',
        '1.8.0' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Gest&atilde;o de cores no Configurar</strong> &mdash; Deteta cores do bikeData (chave, nome, thumbnail, n&ordm; imagens 360&deg;) e apresenta-as como slots edit&aacute;veis</li>'
            . '<li><strong>Apagar/Adicionar cores</strong> &mdash; Bot&atilde;o de apagar individual por cor e bot&atilde;o de adicionar nova cor</li>'
            . '<li><strong>Persist&ecirc;ncia</strong> &mdash; Ao guardar, atualiza HTML (.color-btn) e config do bloco no wp_options</li>'
            . '</ul>',
        '1.7.9' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>360&deg; fix definitivo</strong> &mdash; Usa o JS guardado directamente (comprovado no preview) em vez de regenerar via regex</li>'
            . '<li><strong>Modo debug</strong> &mdash; [cloned_block id=&quot;xxx&quot; debug=&quot;yes&quot;] mostra diagn&oacute;stico completo (s&oacute; admin)</li>'
            . '</ul>',
        '1.7.8' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>SpriteSpin load fix</strong> &mdash; Carregamento din&acirc;mico aguarda jQuery antes de carregar SpriteSpin (fix race condition que impedia 360&deg; no frontend)</li>'
            . '<li><strong>Wrapper retry</strong> &mdash; Detec&ccedil;&atilde;o do wrapper com retry em vez de abandonar silenciosamente</li>'
            . '<li><strong>Color selectors !important</strong> &mdash; CSS dos selectores de cor com !important e fora do bloco responsive para garantir visibilidade</li>'
            . '</ul>',
        '1.7.7' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Imagem 360&deg; completa</strong> &mdash; Restaurado renderer:image + Image probe (da v1.7.3) que mostra a moto inteira sem corte</li>'
            . '<li><strong>Selectores scoped</strong> &mdash; JS usa w.find() para selectores dentro do wrapper (da v1.7.4) &mdash; funciona no frontend Elementor</li>'
            . '<li><strong>CSS selectores de cor</strong> &mdash; .color-btn, .ducati-controls-area e .ducati-selector com CSS expl&iacute;cito garantido</li>'
            . '<li><strong>CSS SpriteSpin img</strong> &mdash; width:auto !important restaurado para imagens do renderer:image</li>'
            . '</ul>',
        '1.7.6' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Imagem 360&deg; sem corte</strong> &mdash; Removido override CSS (width:auto !important) que impedia o SpriteSpin de escalar o canvas responsivamente</li>'
            . '<li><strong>Selectores de cor vis&iacute;veis</strong> &mdash; CSS expl&iacute;cito para .color-btn, .ducati-controls-area e .ducati-selector garante visibilidade independente do CSS scoped</li>'
            . '</ul>',
        '1.7.5' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>renderer:canvas</strong> &mdash; SpriteSpin usa renderer &quot;canvas&quot; (id&ecirc;ntico ao c&oacute;digo de refer&ecirc;ncia) em vez de &quot;image&quot;</li>'
            . '<li><strong>Script directo</strong> &mdash; SpriteSpin carregado via &lt;script src&gt; directo (compat&iacute;vel com Elementor) em vez de wp_enqueue_script</li>'
            . '<li><strong>Inicializa&ccedil;&atilde;o simplificada</strong> &mdash; Chamada directa a .spritespin() sem pre-load de imagem (match refer&ecirc;ncia)</li>'
            . '</ul>',
        '1.7.4' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>SpriteSpin JS scoped</strong> &mdash; Script 360&deg; regenerado com selectores scoped ao wrapper (w.find) em vez de selectores globais que falhavam no frontend</li>'
            . '<li><strong>Selectores de cor</strong> &mdash; Bot&otilde;es .color-btn agora funcionam correctamente no shortcode [cloned_block] com inicializa&ccedil;&atilde;o scoped</li>'
            . '<li><strong>Dete&ccedil;&atilde;o 360&deg; melhorada</strong> &mdash; Deteta conte&uacute;do SpriteSpin mesmo quando JS guardado est&aacute; vazio (verifica estrutura HTML)</li>'
            . '</ul>',
        '1.7.3' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>CSS custom properties</strong> &mdash; Regras :root/:html/:body com vari&aacute;veis CSS (--var) preservadas no filtro e remapeadas para o wrapper no scoping</li>'
            . '<li><strong>CSS sanitization</strong> &mdash; Removido wp_strip_all_tags() que corrompia SVG data URIs no CSS guardado</li>'
            . '<li><strong>Dete&ccedil;&atilde;o de vers&atilde;o</strong> &mdash; Tab &quot;Sobre&quot; mostra vers&atilde;o DB, dete&ccedil;&atilde;o de Code Snippets e Elementor Pro</li>'
            . '</ul>',
        '1.7.2' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>CSS scoping corrigido</strong> &mdash; Parser reescrito com extração correta do body das regras CSS (fix crítico: versões anteriores corrompiam o CSS)</li>'
            . '<li><strong>360&deg; e selectores visíveis</strong> &mdash; Imagens SpriteSpin e botões de cor agora renderizam corretamente</li>'
            . '<li><strong>SpriteSpin wait</strong> &mdash; Shortcode [ducati_360] aguarda jQuery + SpriteSpin antes de inicializar</li>'
            . '<li><strong>CSS selectores de cor</strong> &mdash; Removido override de width:auto nos .color-btn para preservar dimensões originais</li>'
            . '</ul>',
        '1.7.1' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>CSS isolamento total</strong> &mdash; Scoping melhorado: filtra selectores perigosos (body, html, :root, *), trata @font-face/@keyframes corretamente, remove @import/@charset</li>'
            . '<li><strong>Filtro CSS inteligente</strong> &mdash; @media rules só incluídas se contêm classes do bloco, parser com suporte a CSS aninhado</li>'
            . '<li><strong>Responsivo sem conflitos</strong> &mdash; Usa max-width em vez de width forçado, não estica icons pequenos</li>'
            . '<li><strong>Proxy de imagens</strong> &mdash; Fallback automático para proxy quando download de imagens falha</li>'
            . '<li><strong>Dimensões pós-extração</strong> &mdash; Sliders interativos após extrair com auto-deteção de dimensões reais</li>'
            . '</ul>',
        '1.7.0' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li><strong>Instruções por secções</strong> &mdash; Tab Implementação com 5 secções colapsáveis</li>'
            . '<li><strong>Changelog na ativação</strong> &mdash; Aviso detalhado com novidades ao atualizar</li>'
            . '<li><strong>Ativação de versão</strong> &mdash; Deteta e desativa versões antigas do plugin</li>'
            . '</ul>',
        '1.6.9' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li>CSS scoped com wrapper ID para evitar leak para a página</li>'
            . '<li>Imagens SpriteSpin excluídas do CSS responsivo</li>'
            . '<li>Posição dos selectores de cor (top/bottom/left/right) + offsets</li>'
            . '<li>Preview em tempo real no modal de configuração</li>'
            . '<li>Dimensões na área de extração</li>'
            . '</ul>',
        '1.6.8' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li>Corrigido SpriteSpin 360° a aparecer muito pequeno</li>'
            . '<li>Removido CSS conflitante nos img/canvas internos do SpriteSpin</li>'
            . '</ul>',
        '1.6.7' => '<ul style="margin:0;padding-left:18px;line-height:1.8;">'
            . '<li>Imagem 360° sem corte (100% proporcional)</li>'
            . '<li>Painel de configuração para icons de cor no rodapé</li>'
            . '<li>Galeria de imagens para seleção de icons</li>'
            . '</ul>',
    );
    return isset( $logs[ $version ] ) ? $logs[ $version ] : '';
}

/**
 * Mostra avisos no painel de administração sobre atualizações e plugins antigos.
 */
function blkcloner_upgrade_notices() {
    // Aviso de upgrade de versão
    $upgrade_info = get_transient( 'blkcloner_upgraded' );
    if ( $upgrade_info ) {
        $from = esc_html( $upgrade_info['from'] );
        $to   = esc_html( $upgrade_info['to'] );
        echo '<div class="notice notice-success is-dismissible" style="border-left-color:#00a32a;">';
        echo '<p style="font-size:14px;"><strong>Ducati Block Cloner</strong> atualizado com sucesso';
        if ( 'anterior' !== $upgrade_info['from'] ) {
            echo ' da versão <code>' . $from . '</code>';
        } else {
            echo ' de uma versão anterior';
        }
        echo ' para a versão <code>' . $to . '</code>.</p>';
        echo '<p>Todos os seus dados foram preservados: blocos guardados, configurações 360°, idioma e licença.</p>';

        // Changelog da versão
        $changelog = blkcloner_get_changelog( $to );
        if ( $changelog ) {
            echo '<details style="margin-top:8px;">';
            echo '<summary style="cursor:pointer;font-weight:600;color:#1d2327;">Ver novidades da v' . $to . '</summary>';
            echo '<div style="margin-top:8px;padding:10px 14px;background:#f0f6fc;border-radius:6px;font-size:13px;">';
            echo $changelog;
            echo '</div>';
            echo '</details>';
        }
        echo '</div>';
        delete_transient( 'blkcloner_upgraded' );
    }

    // Aviso de plugins antigos desativados
    $old_plugins = get_transient( 'blkcloner_old_plugins_found' );
    if ( $old_plugins && is_array( $old_plugins ) ) {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>⚠️ Ducati Block Cloner:</strong> Foram encontradas versões anteriores do plugin que foram <strong>desativadas automaticamente</strong>:</p>';
        echo '<ul style="list-style:disc;margin-left:20px;">';
        foreach ( $old_plugins as $plugin_file ) {
            echo '<li><code>' . esc_html( $plugin_file ) . '</code></li>';
        }
        echo '</ul>';
        echo '<p>Pode eliminar estas versões antigas com segurança na página de <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">Plugins</a>. Os seus dados foram preservados.</p>';
        echo '</div>';
        delete_transient( 'blkcloner_old_plugins_found' );
    }
}

// =============================================
// CARREGAR COMPONENTES
// =============================================
$blkcloner_files = array(
    'block-cloner-preview.php',
    'block-cloner-admin.php',
    'block-cloner-shortcode.php',
    'block-cloner-advanced.php',
);
foreach ( $blkcloner_files as $blkcloner_file ) {
    $blkcloner_path = BLKCLONER_PLUGIN_DIR . $blkcloner_file;
    if ( file_exists( $blkcloner_path ) ) {
        require_once $blkcloner_path;
    }
}

// =============================================
// LINK "SETTINGS" NA LISTA DE PLUGINS
// =============================================
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
    $settings_link = '<a href="' . admin_url( 'admin.php?page=block-cloner' ) . '">Configurações</a>';
    array_unshift( $links, $settings_link );
    return $links;
});

// =============================================
// INFORMAÇÃO NA LINHA DO PLUGIN
// =============================================
add_filter( 'plugin_row_meta', function ( $links, $file ) {
    if ( plugin_basename( __FILE__ ) === $file ) {
        $links[] = '<a href="https://netseg.ai" target="_blank">Netseg.ai</a>';
        $links[] = '<a href="mailto:info@netseg.ai">Suporte</a>';
    }
    return $links;
}, 10, 2 );
