# Block Cloner para WordPress / Elementor Pro

## Guia de Instalação

Sistema para clonar blocos interativos (como galerias, configuradores, secções dinâmicas) de qualquer website e replicá-los no seu WordPress com Elementor Pro.

---

## Pré-requisitos

- WordPress 5.8+
- Elementor Pro (recomendado)
- Plugin **Code Snippets** instalado e ativo
  - Instalar via: WordPress Admin → Plugins → Adicionar Novo → Pesquisar "Code Snippets"

---

## Instalação (3 Snippets)

### Snippet 1: Painel Admin + Motor de Scraping

1. Ir a **Snippets → Add New**
2. Título: `Block Cloner - Admin`
3. Copiar todo o conteúdo de `block-cloner-admin.php`
4. Selecionar **"Run snippet everywhere"**
5. Clicar **Save Changes and Activate**

### Snippet 2: Shortcode + Proxy de Imagens

1. Ir a **Snippets → Add New**
2. Título: `Block Cloner - Shortcode`
3. Copiar todo o conteúdo de `block-cloner-shortcode.php`
4. Selecionar **"Run snippet everywhere"**
5. Clicar **Save Changes and Activate**

### Snippet 3: Funcionalidades Avançadas (Opcional)

1. Ir a **Snippets → Add New**
2. Título: `Block Cloner - Advanced`
3. Copiar todo o conteúdo de `block-cloner-advanced.php`
4. Selecionar **"Run snippet everywhere"**
5. Clicar **Save Changes and Activate**

---

## Como Usar

### Método 1: Painel Admin (Recomendado)

1. Ir a **WordPress Admin → Block Cloner**
2. Colar a URL da página (ex: `https://www.ducati.com/ww/en/bikes/diavel/diavel-v4`)
3. Inserir o seletor CSS do bloco que quer copiar
4. Clicar **"Extrair Bloco"**
5. Verificar o preview e as imagens
6. Dar um nome e clicar **"Guardar Bloco"**
7. Copiar o shortcode gerado (ex: `[cloned_block id="blk_abc123"]`)

### Método 2: No Elementor

1. Editar a página no Elementor
2. Adicionar widget **"Shortcode"**
3. Colar: `[cloned_block id="blk_abc123"]`
4. Ou usar o widget **"Block Cloner"** (se Snippet 2 estiver ativo)

### Método 3: Scanner Visual (Snippet 3)

1. Ir a **Block Cloner** no admin
2. Usar a REST API ou o scanner visual para selecionar blocos visualmente

---

## Como Encontrar o Seletor CSS

1. Abrir a página alvo no Chrome/Firefox
2. Clicar com **botão direito** no bloco que quer copiar
3. Clicar **"Inspecionar"** (ou "Inspect")
4. No painel DevTools, ver a classe ou ID do elemento:
   - Classe: `<div class="color-picker">` → Seletor: `.color-picker`
   - ID: `<div id="configurator">` → Seletor: `#configurator`
   - Data attribute: `<div data-component="gallery">` → Seletor: `[data-component="gallery"]`

### Seletores Comuns

| Tipo de Bloco | Seletores a Experimentar |
|---|---|
| Galeria de produto | `.product-gallery`, `.hero-carousel` |
| Configurador | `.configurator`, `.product-configurator` |
| Secção genérica | `section`, `.section`, `.block` |

---

## Shortcode do Bloco Clonado

```
[cloned_block id="blk_xxxxx" max_width="100%" align="center" responsive="yes" isolate="yes" lazy="yes"]
```

| Parâmetro | Descrição | Padrão |
|---|---|---|
| `id` | ID do bloco guardado (obrigatório) | - |
| `max_width` | Largura máxima | 100% |
| `align` | Alinhamento: left, center, right | center |
| `responsive` | Adaptar a mobile | yes |
| `isolate` | Isolar CSS (scoped) | yes |
| `lazy` | Lazy loading de imagens | yes |

---

## Notas Importantes

- Alguns sites (como ducati.com) bloqueiam scraping server-side (erro 403). Nesse caso, use o Scanner Visual (Snippet 3) ou copie o HTML manualmente do DevTools.
- As imagens são descarregadas e guardadas em cache em `wp-content/cache/block-cloner/`.
- O CSS é isolado (scoped) para não afetar o resto do site.
- Blocos com JavaScript pesado (React, Vue) podem não funcionar perfeitamente - o JS client-side precisa de contexto.
- Respeite os direitos de autor e termos de serviço dos sites de origem.

---

## Resolução de Problemas

| Problema | Solução |
|---|---|
| Erro 403 ao extrair | O site bloqueia scraping. Use o Scanner Visual ou copie manualmente. |
| Imagens não aparecem | Verifique se o site permite hotlinking. O proxy de imagens deve resolver isto. |
| CSS conflita com o tema | Ative a opção "Isolar CSS" no shortcode. |
| Bloco não é interativo | O JavaScript do site original pode depender de frameworks. Adapte o JS manualmente. |
| Shortcode não funciona | Verifique se os 3 snippets estão ativos no Code Snippets. |
